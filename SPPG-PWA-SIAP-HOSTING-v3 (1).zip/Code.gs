/**
 * =========================================================================
 *  SPPG — INVENTORY & STOCK OPNAME
 *  Backend Google Apps Script
 *  Database utama: Google Spreadsheet (satu sumber data untuk semua pengguna)
 * =========================================================================
 */

// ------------------------- KONFIGURASI -------------------------
const SHEET_PRODUK     = 'Produk';
const SHEET_TRANSAKSI  = 'Transaksi';
const SHEET_OMPRENG    = 'OmprengUtuh';
const SHEET_USERS      = 'Users';      // Akun Admin & Operator (nama, password terhash, role)
const SHEET_LICENSES   = 'Licenses';   // Riwayat kode lisensi instalasi yang sudah dipakai

const ADMIN_PASSWORD      = '233445';   // Password Admin BAWAAN — hanya dipakai sebagai fallback
                                         // selama belum ada akun Admin tersimpan di sheet Users.
const OPERATOR_PASSWORD   = '223344';   // (legacy, tidak lagi dipakai setelah akun Operator per-nama aktif)
const TOKEN_DURATION_SEC  = 6 * 60 * 60; // Sesi berlaku 6 jam (admin & operator)

// ---------------------- SETUP AKUN & OTP EMAIL ----------------------
const OTP_TTL_SEC          = 5 * 60;   // Kode OTP berlaku 5 menit
const PASSWORD_SALT        = 'SPPG-Campang-3-2026'; // Salt statis untuk hashing password sederhana

// ---------------------- LISENSI INSTALASI (WhatsApp) ----------------------
const LICENSE_WA_NUMBER    = '6285609930692'; // 085609930692 dalam format internasional (tanpa + / spasi)
const PROP_LICENSE_SEQ     = 'LICENSE_SEQ';   // index urutan kode berikutnya yang didispense Admin dari LICENSE_POOL
// CATATAN: Seri kode lama "Tool121, Tool232, ..." SUDAH DINONAKTIFKAN.
// Seluruh kode lisensi kini berasal dari daftar resmi LICENSE_POOL (di bagian bawah file),
// yaitu 5.000 kode 8-digit. Setiap kode hanya berlaku 1x pemakaian.

// ---------------------- NAMA APLIKASI (bisa diganti Admin di Pengaturan) ----------------------
const PROP_APP_NAME        = 'APP_DISPLAY_NAME';
const DEFAULT_APP_NAME     = 'SPPG';

// ---------------------- KONEKSI GDRIVE / SPREADSHEET (bisa diganti Admin) ----------------------
const PROP_DRIVE_FOLDER_ID   = 'CONNECTED_DRIVE_FOLDER_ID';
const PROP_SPREADSHEET_ID    = 'CONNECTED_SPREADSHEET_ID';
const PROP_TIMESTAMP_LABEL   = 'CUSTOM_TIMESTAMP_LABEL';
const PROP_TIMESTAMP_CHANGED = 'CUSTOM_TIMESTAMP_CHANGED_AT';
const TIMESTAMP_LOCK_DAYS    = 10; // custom timestamp hanya bisa diganti setiap 10 hari

// Batas jumlah perangkat Operator yang boleh login BERSAMAAN.
const MAX_OPERATOR_DEVICES     = 6;
const OPERATOR_DEVICE_CACHE_KEY = 'operator_devices_v1';

// Batas hari peringatan "akan kadaluarsa" untuk ditampilkan di Dashboard.
const EXPIRY_WARNING_DAYS = 5;

// Format kode otomatis untuk SETIAP transaksi (Masuk/Keluar/Sampah/Koreksi).
// Kode berjalan berurutan: SPPG0001, SPPG0002, dst (minimal 4 digit, angka lebih besar
// akan otomatis memanjang tanpa dipotong). Disimpan di Script Properties agar tetap
// konsisten & tidak bentrok walau banyak pengguna menyimpan bersamaan.
const TRX_CODE_PREFIX  = 'SPPG';
const TRX_CODE_START   = 0; // nomor urut pertama yang akan dipakai adalah START + 1 -> SPPG0001
const TRX_CODE_DIGITS  = 4; // jumlah digit minimal (dengan angka 0 di depan)
const PROP_TRX_SEQ     = 'TRX_SEQ';

// Folder induk Google Drive untuk menyimpan foto bukti Barang Masuk.
// Sub-folder akan dibuat otomatis per tanggal (yyyy-MM-dd) di dalam folder ini.
const DRIVE_ROOT_FOLDER_ID = '1A38dauPwHYKtaqHXGhWyJ-dJBKif3zLT';

// Kolom sheet Transaksi (urutan HARUS sama dengan appendRow di bawah)
// ID | Timestamp | Tanggal | Operator | Jenis | NoRef | ProdukID | Jumlah | Harga | Total | Keterangan | FotoURL | Kadaluarsa
const COL_TRX_ID = 0, COL_TRX_TIMESTAMP = 1, COL_TRX_TANGGAL = 2, COL_TRX_OPERATOR = 3,
      COL_TRX_JENIS = 4, COL_TRX_NOREF = 5, COL_TRX_PRODUKID = 6, COL_TRX_JUMLAH = 7,
      COL_TRX_HARGA = 8, COL_TRX_TOTAL = 9, COL_TRX_KETERANGAN = 10, COL_TRX_FOTO = 11,
      COL_TRX_KADALUARSA = 12, COL_TRX_SUPPLIER = 13;

// NOTE: Master Barang TIDAK lagi memakai data awal (DEFAULT_PRODUCTS) yang dipaksakan
// otomatis. Sebelumnya ada bug: item wajib (BM1/BM2/BM3) selalu ditambahkan ulang oleh
// sistem walau Admin sudah menghapusnya, sehingga terlihat seolah "tidak bisa dihapus".
// Sekarang Admin bebas menambah/menghapus barang tanpa gangguan tersebut.


// ============================= WEB APP ENTRY =============================
function doGet(e) {
  // Dukung tautan aktivasi otomatis untuk Operator baru: .../exec?lisensi=KODE
  // Kode ini disisipkan ke halaman lewat template (bukan createHtmlOutputFromFile)
  // supaya JavaScript di index.html bisa langsung mengisi kolom kode lisensi.
  const tpl = HtmlService.createTemplateFromFile('index');
  tpl.initialLicenseCode = (e && e.parameter && e.parameter.lisensi) ? String(e.parameter.lisensi).trim() : '';
  return tpl.evaluate()
    .setTitle('SPPG - Inventory')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}


// ================================ AUTH ====================================
/**
 * Diverifikasi di SERVER, bukan hanya di JavaScript browser.
 * Mengembalikan token sementara yang harus dikirim kembali oleh client
 * untuk setiap aksi yang membutuhkan hak akses Admin.
 */
/**
 * Langkah 1 Login Admin: cek password. Jika akun Admin punya email tersimpan (dibuat
 * lewat Setup Akun / Google + OTP), token BELUM diberikan di sini — sistem akan
 * mengirim kode OTP ke email tersebut dan client wajib memanggil verifyAdminLoginOtp()
 * untuk menyelesaikan login (verifikasi 2 langkah: password + OTP email).
 * Jika akun belum punya email (mode lama/fallback), langsung login seperti biasa.
 */
function verifyAdminPassword(password) {
  const adminUser = findUserByRole_('ADMIN');
  let ok = false;
  if (adminUser) {
    ok = (adminUser.PasswordHash === hashPassword_(password));
  } else {
    // Belum ada akun Admin yang dibuat lewat Setup Akun -> pakai password bawaan sekali saja.
    ok = (String(password) === ADMIN_PASSWORD);
  }
  if (!ok) return { success: false, message: 'Password admin salah' };

  const email = adminUser && adminUser.Email ? String(adminUser.Email).trim() : '';
  if (email) {
    // Wajib verifikasi OTP email sebelum token diberikan.
    const otp = String(Math.floor(100000 + Math.random() * 900000));
    const loginId = Utilities.getUuid();
    CacheService.getScriptCache().put('adminlogin_' + loginId, JSON.stringify({ email: email, otp: otp, name: adminUser.Nama }), OTP_TTL_SEC);
    try {
      MailApp.sendEmail({
        to: email,
        subject: 'Kode Verifikasi Login ' + getAppName(),
        body: 'Kode verifikasi (OTP) login Admin Anda: ' + otp + '\n\nBerlaku selama 5 menit. Jangan bagikan kode ini kepada siapa pun.'
      });
    } catch (err) {
      // Jika email gagal terkirim, tetap izinkan login langsung agar Admin tidak terkunci total.
      const token = Utilities.getUuid();
      CacheService.getScriptCache().put('admin_' + token, 'valid', TOKEN_DURATION_SEC);
      return { success: true, token: token, adminName: adminUser.Nama, otpSkipped: true };
    }
    return { success: true, needsOtp: true, loginId: loginId, emailMasked: maskEmail_(email) };
  }

  const token = Utilities.getUuid();
  CacheService.getScriptCache().put('admin_' + token, 'valid', TOKEN_DURATION_SEC);
  return { success: true, token: token, adminName: adminUser ? adminUser.Nama : 'Admin SPPG' };
}

/** Langkah 2 Login Admin: verifikasi kode OTP yang dikirim ke email, lalu keluarkan token sesi. */
function verifyAdminLoginOtp(loginId, otp) {
  const raw = CacheService.getScriptCache().get('adminlogin_' + loginId);
  if (!raw) return { success: false, message: 'Kode OTP salah atau sudah kadaluarsa. Silakan login ulang.' };
  const data = JSON.parse(raw);
  if (String(otp || '').trim() !== data.otp) {
    return { success: false, message: 'Kode OTP salah.' };
  }
  CacheService.getScriptCache().remove('adminlogin_' + loginId);
  const token = Utilities.getUuid();
  CacheService.getScriptCache().put('admin_' + token, 'valid', TOKEN_DURATION_SEC);
  return { success: true, token: token, adminName: data.name };
}

/** Menyamarkan email untuk ditampilkan di layar OTP (mis. a***@gmail.com). */
function maskEmail_(email) {
  const parts = String(email).split('@');
  if (parts.length !== 2) return email;
  const user = parts[0];
  const masked = user.length <= 2 ? (user.charAt(0) + '*') : (user.charAt(0) + '*'.repeat(Math.max(1, user.length - 2)) + user.charAt(user.length - 1));
  return masked + '@' + parts[1];
}

/**
 * Login Operator — WAJIB password, dan dibatasi maksimal MAX_OPERATOR_DEVICES
 * perangkat yang aktif secara bersamaan. Setiap perangkat mengirimkan deviceId
 * unik (dibuat & disimpan di localStorage browser) supaya server bisa menghitung
 * berapa perangkat berbeda yang sedang memakai sesi Operator saat ini.
 */
function verifyOperatorPassword(name, password, deviceId) {
  const users = getUsersRows_().filter(u => u.Role === 'OPERATOR' && u.Status !== 'NONAKTIF');
  let matched = null;
  if (name) {
    matched = users.find(u => String(u.Nama) === String(name) && u.PasswordHash === hashPassword_(password));
  } else if (users.length === 0) {
    // Belum ada satupun akun Operator dibuat -> pakai password bawaan (mode transisi/legacy).
    if (String(password) === OPERATOR_PASSWORD) matched = { Nama: 'Operator' };
  }
  if (!matched) {
    return { success: false, message: 'Nama atau password operator salah' };
  }
  if (!deviceId) {
    return { success: false, message: 'Perangkat tidak terindentifikasi. Muat ulang halaman dan coba lagi.' };
  }
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const cache = CacheService.getScriptCache();
    const now = Date.now();
    let devices = [];
    try {
      const raw = cache.get(OPERATOR_DEVICE_CACHE_KEY);
      devices = raw ? JSON.parse(raw) : [];
    } catch (e) { devices = []; }

    // Buang perangkat yang sesinya sudah kadaluarsa
    devices = devices.filter(d => d && d.expiry > now);

    const idx = devices.findIndex(d => d.deviceId === deviceId);
    if (idx === -1 && devices.length >= MAX_OPERATOR_DEVICES) {
      return {
        success: false,
        message: 'Batas maksimal ' + MAX_OPERATOR_DEVICES + ' perangkat Operator yang aktif secara bersamaan sudah tercapai. Silakan coba lagi nanti atau minta perangkat lain logout terlebih dahulu.'
      };
    }

    const token = Utilities.getUuid();
    const expiry = now + (TOKEN_DURATION_SEC * 1000);
    if (idx === -1) {
      devices.push({ deviceId: deviceId, expiry: expiry });
    } else {
      devices[idx] = { deviceId: deviceId, expiry: expiry };
    }

    cache.put(OPERATOR_DEVICE_CACHE_KEY, JSON.stringify(devices), TOKEN_DURATION_SEC);
    cache.put('operator_' + token, deviceId, TOKEN_DURATION_SEC);

    return { success: true, token: token, operatorName: matched.Nama, activeDevices: devices.length, maxDevices: MAX_OPERATOR_DEVICES };
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

function isAdminToken_(token) {
  if (!token) return false;
  return CacheService.getScriptCache().get('admin_' + token) === 'valid';
}

function isOperatorToken_(token) {
  if (!token) return false;
  return !!CacheService.getScriptCache().get('operator_' + token);
}

/** Lempar error jika token admin tidak valid/kadaluarsa — dipakai di setiap fungsi admin-only. */
function requireAdmin_(token) {
  if (!isAdminToken_(token)) {
    throw new Error('Akses ditolak: sesi admin tidak valid atau sudah kadaluarsa. Silakan login ulang sebagai Admin.');
  }
}

/** Lempar error jika sesi (Admin ATAU Operator) tidak valid — dipakai untuk aksi transaksi harian. */
function requireSession_(token) {
  if (!isAdminToken_(token) && !isOperatorToken_(token)) {
    throw new Error('Akses ditolak: sesi tidak valid atau sudah kadaluarsa. Silakan login ulang.');
  }
}


// =========================== UTIL SPREADSHEET =============================
function getSS_() {
  const connectedId = PropertiesService.getScriptProperties().getProperty(PROP_SPREADSHEET_ID);
  if (connectedId) {
    try {
      return SpreadsheetApp.openById(connectedId);
    } catch (e) {
      // ID tersimpan tidak valid/tidak bisa diakses lagi -> fallback ke spreadsheet bound.
    }
  }
  return SpreadsheetApp.getActiveSpreadsheet();
}

/** Membuat sheet + header jika belum ada. Aman dipanggil berulang kali. */
function ensureSheets_() {
  const ss = getSS_();

  let produkSheet = ss.getSheetByName(SHEET_PRODUK);
  if (!produkSheet) {
    produkSheet = ss.insertSheet(SHEET_PRODUK);
    produkSheet.appendRow(['ID', 'Kode', 'Nama', 'Kategori', 'Satuan', 'MinStok', 'HargaStandar']);
    const seed = [
      [1, 'BKP-01', 'Beras Premium', 'Bahan Pokok', 'Kg', 50, 15000],
      [2, 'BKP-02', 'Minyak Goreng Sawit', 'Bahan Pokok', 'Ltr', 20, 18000],
      [3, 'BBS-01', 'Daging Ayam', 'Bahan Basah', 'Kg', 10, 35000],
      [4, 'BBS-02', 'Telur Ayam', 'Bahan Basah', 'Butir', 100, 2000],
      [5, 'BMB-01', 'Bawang Merah', 'Bumbu', 'Kg', 5, 30000]
    ];
    seed.forEach(row => produkSheet.appendRow(row));
    produkSheet.setFrozenRows(1);
  }
  // Catatan: item wajib (DEFAULT_PRODUCTS) SUDAH DIHAPUS agar Admin bisa menghapus
  // barang apa pun tanpa terus muncul kembali otomatis.

  let trxSheet = ss.getSheetByName(SHEET_TRANSAKSI);
  if (!trxSheet) {
    trxSheet = ss.insertSheet(SHEET_TRANSAKSI);
    trxSheet.appendRow(['ID', 'Timestamp', 'Tanggal', 'Operator', 'Jenis', 'NoRef', 'ProdukID', 'Jumlah', 'Harga', 'Total', 'Keterangan', 'FotoURL', 'Kadaluarsa', 'Supplier']);
    trxSheet.setFrozenRows(1);
  }
  ensureHeaderColumn_(trxSheet, 'FotoURL');     // migrasi otomatis untuk sheet lama
  ensureHeaderColumn_(trxSheet, 'Kadaluarsa');  // migrasi otomatis: kolom tanggal kadaluarsa (Barang Masuk)
  ensureHeaderColumn_(trxSheet, 'Supplier');    // migrasi otomatis: nama supplier/pemasok (Barang Masuk) — dipakai untuk Invoice FIFO

  if (!ss.getSheetByName(SHEET_OMPRENG)) {
    const sh = ss.insertSheet(SHEET_OMPRENG);
    sh.appendRow(['ID', 'Timestamp', 'Tanggal', 'Operator', 'Status', 'NamaKeterangan', 'JumlahOmpreng', 'HargaSatuan', 'Total', 'Keterangan']);
    sh.setFrozenRows(1);
  }

  if (!ss.getSheetByName(SHEET_USERS)) {
    const sh = ss.insertSheet(SHEET_USERS);
    sh.appendRow(['ID', 'Nama', 'Email', 'Role', 'PasswordHash', 'CreatedAt', 'Status']);
    sh.setFrozenRows(1);
  }

  if (!ss.getSheetByName(SHEET_LICENSES)) {
    const sh = ss.insertSheet(SHEET_LICENSES);
    sh.appendRow(['Code', 'Status', 'UsedAt', 'DeviceId']);
    sh.setFrozenRows(1);
  }
}

/** Menambahkan kolom baru di akhir header sheet jika belum ada (migrasi ringan, aman dipanggil berulang). */
function ensureHeaderColumn_(sheet, headerName) {
  const lastCol = Math.max(sheet.getLastColumn(), 1);
  const headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  if (headers.indexOf(headerName) === -1) {
    sheet.getRange(1, lastCol + 1).setValue(headerName);
  }
}

function normalizeDate_(value) {
  if (value instanceof Date && !isNaN(value.getTime())) {
    return Utilities.formatDate(value, Session.getScriptTimeZone() || 'Asia/Jakarta', 'yyyy-MM-dd');
  }
  const text = String(value == null ? '' : value).trim();
  if (!text) return '';
  // Jika sudah format ISO tanggal, pertahankan.
  const m = text.match(/^(\d{4}-\d{2}-\d{2})/);
  if (m) return m[1];
  return text;
}

function validateTransaction_(trx, allowCorrection) {
  if (!trx || typeof trx !== 'object') throw new Error('Data transaksi tidak valid.');
  const allowed = allowCorrection ? ['IN', 'OUT', 'WASTE', 'CORRECTION'] : ['IN', 'OUT', 'WASTE'];
  if (!allowed.includes(String(trx.type))) throw new Error('Jenis transaksi tidak valid.');
  if (!trx.productId) throw new Error('Barang belum dipilih.');
  if (!normalizeDate_(trx.date)) throw new Error('Tanggal transaksi wajib diisi.');
  const qty = Number(trx.qty);
  if (!isFinite(qty) || (allowCorrection ? qty === 0 : qty <= 0)) throw new Error('Jumlah transaksi tidak valid.');
  const price = Number(trx.price);
  if (!isFinite(price) || price < 0) throw new Error('Harga tidak valid.');
  if (String(trx.type) === 'IN' && !normalizeDate_(trx.expired)) {
    throw new Error('Tanggal kadaluarsa wajib diisi untuk Barang Masuk.');
  }
  if (!trx.note || !String(trx.note).trim()) {
    throw new Error('Keterangan/catatan transaksi wajib diisi.');
  }
}

/** Ubah semua baris sebuah sheet menjadi array of object berdasarkan header baris pertama. */
function sheetToObjects_(sheet) {
  const rows = sheet.getDataRange().getValues();
  if (rows.length < 2) return [];
  const headers = rows[0];
  const out = [];
  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (row.every(c => c === '' || c === null)) continue;
    const obj = {};
    headers.forEach((h, idx) => { obj[h] = row[idx]; });
    out.push(obj);
  }
  return out;
}

function generateUniqueId_() {
  return Utilities.getUuid();
}

/**
 * Mencari nomor urut TERBESAR dari kode transaksi (kolom NoRef) yang sudah ada di sheet,
 * dipakai sekali sebagai "migrasi" awal jika Script Properties belum punya nilai tersimpan
 * (misalnya setelah deploy ulang) — supaya penomoran tidak mundur/bentrok dengan data lama.
 */
function findMaxExistingTrxSeq_() {
  const sheet = getSS_().getSheetByName(SHEET_TRANSAKSI);
  if (!sheet) return TRX_CODE_START;
  const data = sheet.getDataRange().getValues();
  const re = new RegExp('^' + TRX_CODE_PREFIX + '(\\d+)$');
  let max = TRX_CODE_START;
  for (let i = 1; i < data.length; i++) {
    const ref = String(data[i][COL_TRX_NOREF] || '');
    const m = ref.match(re);
    if (m) {
      const n = parseInt(m[1], 10);
      if (isFinite(n) && n > max) max = n;
    }
  }
  return max;
}

/** Menambahkan angka 0 di depan sampai minimal TRX_CODE_DIGITS digit (mis. 1 -> "0001"). */
function padTrxSeq_(n) {
  let s = String(n);
  while (s.length < TRX_CODE_DIGITS) s = '0' + s;
  return s;
}

/**
 * Menghasilkan kode transaksi berurutan berikutnya (mis. SPPG0001, SPPG0002, ...).
 * WAJIB dipanggil di dalam LockService agar tidak ada nomor kembar saat banyak pengguna
 * menyimpan transaksi secara bersamaan.
 */
function generateTrxCode_() {
  const props = PropertiesService.getScriptProperties();
  let last = parseInt(props.getProperty(PROP_TRX_SEQ), 10);
  if (!isFinite(last)) {
    last = findMaxExistingTrxSeq_();
  }
  const next = last + 1;
  props.setProperty(PROP_TRX_SEQ, String(next));
  return TRX_CODE_PREFIX + padTrxSeq_(next);
}

/** Reset penomoran kode transaksi kembali ke awal (dipakai oleh resetAllTransactions). */
function resetTrxCodeSequence_() {
  PropertiesService.getScriptProperties().setProperty(PROP_TRX_SEQ, String(TRX_CODE_START));
}

/** Hitung stok berjalan sebuah produk langsung dari sheet Transaksi (server-side, untuk validasi). */
function computeStock_(productId) {
  const sheet = getSS_().getSheetByName(SHEET_TRANSAKSI);
  const data = sheet.getDataRange().getValues();
  let stock = 0;
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (String(row[COL_TRX_PRODUKID]) !== String(productId)) continue;
    const type = row[COL_TRX_JENIS];
    const qty = Number(row[COL_TRX_JUMLAH]) || 0;
    if (type === 'IN') stock += qty;
    else if (type === 'OUT' || type === 'WASTE') stock -= qty;
    else if (type === 'CORRECTION') stock += qty;
  }
  return Math.max(0, Math.round(stock * 100) / 100);
}


// ============================ AMBIL DATA (READ) ============================
/**
 * Mengambil SEMUA data terpusat dari Spreadsheet. Dipanggil setiap kali
 * Web App dibuka dan setiap kali perlu sinkronisasi ulang.
 */
function getData() {
  ensureSheets_();
  const ss = getSS_();

  const produkRows = sheetToObjects_(ss.getSheetByName(SHEET_PRODUK));
  const products = produkRows.map(r => ({
    id: r.ID, code: r.Kode, name: r.Nama, category: r.Kategori, unit: r.Satuan,
    minStock: Number(r.MinStok) || 0, price: Number(r.HargaStandar) || 0
  }));
  const productMap = {};
  products.forEach(p => { productMap[String(p.id)] = p; });

  const trxRows = sheetToObjects_(ss.getSheetByName(SHEET_TRANSAKSI));
  const transactions = trxRows.map(r => ({
    id: r.ID, timestamp: Number(r.Timestamp) || 0, user: r.Operator, type: r.Jenis,
    date: normalizeDate_(r.Tanggal), ref: r.NoRef, productId: r.ProdukID, qty: Number(r.Jumlah) || 0,
    price: Number(r.Harga) || 0, total: Number(r.Total) || 0, note: r.Keterangan || '',
    photoUrl: r.FotoURL || '', expired: normalizeDate_(r.Kadaluarsa) || '',
    supplier: r.Supplier || '',
    productCode: (productMap[String(r.ProdukID)] || {}).code || ''
  }));

  const ompRows = sheetToObjects_(ss.getSheetByName(SHEET_OMPRENG));
  const trayWaste = ompRows.map(r => ({
    id: r.ID, timestamp: Number(r.Timestamp) || 0, user: r.Operator, date: normalizeDate_(r.Tanggal),
    status: r.Status, type: r.NamaKeterangan, qty: Number(r.JumlahOmpreng) || 0,
    price: Number(r.HargaSatuan) || 0, total: Number(r.Total) || 0, note: r.Keterangan || ''
  }));

  return { products: products, transactions: transactions, trayWaste: trayWaste };
}

// Alias — disediakan agar sesuai konvensi penamaan fungsi backend yang umum dipakai.
function getDashboardData() { return getData(); }
function getStockData() { return getData(); }
function getReportData() { return getData(); }


// ========================= TRANSAKSI (IN / OUT / WASTE) ====================
/**
 * Menyimpan transaksi Barang Masuk / Barang Keluar / Sampah Bahan Baku / Koreksi Opname.
 * Operator dan Admin sama-sama boleh memanggil ini untuk IN/OUT.
 * Untuk WASTE, wajib token Admin (menu Sampah Bahan disembunyikan dari Operator).
 * Untuk type CORRECTION, gunakan saveOpnameCorrection() yang mewajibkan token admin.
 */
function saveTransactionInternal_(trx) {
  ensureSheets_();
  validateTransaction_(trx, true);
  trx.date = normalizeDate_(trx.date);
  trx.expired = trx.type === 'IN' ? normalizeDate_(trx.expired) : '';
  trx.user = String(trx.user || 'OPERATOR');
  trx.qty = Number(trx.qty);
  trx.price = Number(trx.price) || 0;
  trx.total = Number(trx.total) || (Math.abs(trx.qty) * trx.price);
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    if (trx.type === 'OUT' || trx.type === 'WASTE') {
      const currentStock = computeStock_(trx.productId);
      if (Number(trx.qty) > currentStock) throw new Error('Stok tidak mencukupi. Sisa stok saat ini: ' + currentStock);
    }
    // Setiap transaksi (Masuk/Keluar/Sampah/Koreksi) WAJIB memakai kode otomatis berurutan
    // (SPPG0001, SPPG0002, ...) yang dibuat di server — mengabaikan nilai ref dari client
    // agar penomoran selalu konsisten dan tidak bisa diduplikasi/dimanipulasi dari browser.
    trx.ref = generateTrxCode_();
    trx.supplier = trx.type === 'IN' ? String(trx.supplier || '').trim() : '';
    const sheet = getSS_().getSheetByName(SHEET_TRANSAKSI);
    const id = generateUniqueId_();
    sheet.appendRow([id, Date.now(), trx.date, trx.user, trx.type, trx.ref, trx.productId, trx.qty, trx.price, trx.total, trx.note || '', trx.photoUrl || '', trx.expired || '', trx.supplier || '']);
    SpreadsheetApp.flush();
    return { success: true, id: id, code: trx.ref };
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

function saveTransaction(trx, token) {
  // Endpoint publik-sesi: butuh sesi Admin ATAU Operator yang valid.
  // Sampah Bahan Baku TERMASUK menu yang boleh diakses Operator, jadi cukup sesi valid
  // (Admin ATAU Operator) — tidak lagi dibatasi khusus Admin.
  requireSession_(token);
  validateTransaction_(trx, false);
  return saveTransactionInternal_(trx);
}

/** Koreksi Stock Opname — WAJIB Admin. */
function saveOpnameCorrection(trx, token) {
  requireAdmin_(token);
  trx = Object.assign({}, trx, { type: 'CORRECTION' });
  return saveTransactionInternal_(trx);
}

/** Update sebagian data transaksi (Admin only). Disediakan untuk kebutuhan CRUD lengkap. */
function updateTransaction(id, updates, token) {
  requireAdmin_(token);
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const sheet = getSS_().getSheetByName(SHEET_TRANSAKSI);
    const data = sheet.getDataRange().getValues();
    const fieldToCol = {
      date: COL_TRX_TANGGAL, user: COL_TRX_OPERATOR, type: COL_TRX_JENIS, ref: COL_TRX_NOREF,
      productId: COL_TRX_PRODUKID, qty: COL_TRX_JUMLAH, price: COL_TRX_HARGA,
      total: COL_TRX_TOTAL, note: COL_TRX_KETERANGAN, photoUrl: COL_TRX_FOTO, expired: COL_TRX_KADALUARSA,
      supplier: COL_TRX_SUPPLIER
    };
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][COL_TRX_ID]) === String(id)) {
        Object.keys(updates).forEach(key => {
          if (fieldToCol.hasOwnProperty(key)) {
            sheet.getRange(i + 1, fieldToCol[key] + 1).setValue(updates[key]);
          }
        });
        return { success: true };
      }
    }
    throw new Error('Transaksi tidak ditemukan');
  } finally {
    lock.releaseLock();
  }
}

/** Hapus transaksi (Admin only). Dipakai oleh tombol Hapus di Riwayat Transaksi. */
function deleteTransaction(id, token) {
  requireAdmin_(token);
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const sheet = getSS_().getSheetByName(SHEET_TRANSAKSI);
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][COL_TRX_ID]) === String(id)) {
        sheet.deleteRow(i + 1);
        return { success: true };
      }
    }
    throw new Error('Transaksi tidak ditemukan');
  } finally {
    lock.releaseLock();
  }
}


/**
 * Menghapus SELURUH riwayat transaksi (Masuk/Keluar/Sampah/Koreksi) dan Ompreng Utuh,
 * lalu mengembalikan stok semua barang menjadi NOL serta mereset penomoran kode transaksi
 * kembali ke SPPG0001. WAJIB Admin. Tindakan ini permanen dan tidak dapat dibatalkan.
 */
function resetAllTransactions(token) {
  requireAdmin_(token);
  ensureSheets_();
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const ss = getSS_();

    const trxSheet = ss.getSheetByName(SHEET_TRANSAKSI);
    if (trxSheet) {
      const lastRow = trxSheet.getLastRow();
      const lastCol = Math.max(trxSheet.getLastColumn(), 1);
      if (lastRow > 1) trxSheet.getRange(2, 1, lastRow - 1, lastCol).clearContent();
    }

    const ompSheet = ss.getSheetByName(SHEET_OMPRENG);
    if (ompSheet) {
      const lastRow = ompSheet.getLastRow();
      const lastCol = Math.max(ompSheet.getLastColumn(), 1);
      if (lastRow > 1) ompSheet.getRange(2, 1, lastRow - 1, lastCol).clearContent();
    }

    resetTrxCodeSequence_();
    SpreadsheetApp.flush();
    return { success: true, message: 'Semua transaksi berhasil dihapus. Seluruh stok kembali ke nol dan penomoran kode dimulai lagi dari ' + TRX_CODE_PREFIX + padTrxSeq_(TRX_CODE_START + 1) + '.' };
  } finally {
    lock.releaseLock();
  }
}


// =========================== OMPRENG UTUH / TIDAK DIMAKAN ==================
/**
 * Mencatat SATU baris item makanan/ompreng yang kondisinya utuh namun makanannya tidak
 * dimakan/habis. Form di client sekarang terdiri dari 5 baris bahan sekaligus — client
 * memanggil fungsi ini berkali-kali (satu kali per baris bahan yang diisi).
 * Menu ini termasuk yang boleh diakses Operator, jadi cukup sesi valid (Admin ATAU Operator).
 */
function saveOmprengUtuh(data, token) {
  requireSession_(token);
  ensureSheets_();
  if (!data || !normalizeDate_(data.date)) throw new Error('Tanggal wajib diisi.');
  if (!data.status || !data.type) throw new Error('Status dan nama bahan wajib diisi.');
  data.qty = Number(data.qty);
  data.price = Number(data.price);
  if (!isFinite(data.qty) || data.qty <= 0) throw new Error('Jumlah harus lebih dari 0.');
  if (!isFinite(data.price) || data.price < 0) throw new Error('Harga tidak valid.');
  data.date = normalizeDate_(data.date);
  data.user = String(data.user || 'OPERATOR');
  data.total = Number(data.total) || data.qty * data.price;
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const sheet = getSS_().getSheetByName(SHEET_OMPRENG);
    const id = generateUniqueId_();
    const timestamp = Date.now();
    sheet.appendRow([
      id, timestamp, data.date, data.user, data.status, data.type,
      data.qty, data.price, data.total, data.note || ''
    ]);
    SpreadsheetApp.flush();
    return { success: true, id: id };
  } finally {
    lock.releaseLock();
  }
}


// =============================== MASTER BARANG ==============================
/** Tambah/Edit data master barang — WAJIB Admin. */
function saveProduct(productData, token) {
  requireAdmin_(token);
  ensureSheets_();
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const sheet = getSS_().getSheetByName(SHEET_PRODUK);
    const data = sheet.getDataRange().getValues();

    if (productData.id) {
      for (let i = 1; i < data.length; i++) {
        if (String(data[i][0]) === String(productData.id)) {
          sheet.getRange(i + 1, 1, 1, 7).setValues([[
            productData.id, productData.code, productData.name, productData.category,
            productData.unit, productData.minStock, productData.price
          ]]);
          return { success: true, id: productData.id };
        }
      }
      throw new Error('Barang tidak ditemukan');
    } else {
      for (let i = 1; i < data.length; i++) {
        if (String(data[i][1]).toUpperCase() === String(productData.code).toUpperCase()) {
          throw new Error('Kode barang sudah ada!');
        }
      }
      const id = generateUniqueId_();
      sheet.appendRow([id, productData.code, productData.name, productData.category, productData.unit, productData.minStock, productData.price]);
      return { success: true, id: id };
    }
  } finally {
    lock.releaseLock();
  }
}

/** Hapus data master barang — WAJIB Admin. Ditolak jika barang punya riwayat transaksi. */
function deleteProduct(id, token) {
  requireAdmin_(token);
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const ss = getSS_();

    const trxSheet = ss.getSheetByName(SHEET_TRANSAKSI);
    const trxData = trxSheet.getDataRange().getValues();
    for (let i = 1; i < trxData.length; i++) {
      if (String(trxData[i][COL_TRX_PRODUKID]) === String(id)) {
        throw new Error('Barang tidak dapat dihapus karena memiliki riwayat transaksi.');
      }
    }

    const sheet = ss.getSheetByName(SHEET_PRODUK);
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(id)) {
        sheet.deleteRow(i + 1);
        return { success: true };
      }
    }
    throw new Error('Barang tidak ditemukan');
  } finally {
    lock.releaseLock();
  }
}


// ===================== FOTO BUKTI BARANG MASUK (GOOGLE DRIVE) ======================
/**
 * Folder cadangan yang otomatis dibuat di Drive milik pemilik skrip jika folder induk
 * (DRIVE_ROOT_FOLDER_ID) tidak bisa diakses (ID salah, dihapus, atau izin dicabut).
 * Ini mencegah fitur upload foto berhenti total hanya karena masalah 1 folder.
 */
function getOrCreateFallbackRootFolder_() {
  const name = 'SPPG_Foto_BarangMasuk';
  const it = DriveApp.getFoldersByName(name);
  if (it.hasNext()) return it.next();
  const folder = DriveApp.createFolder(name);
  try { folder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
  return folder;
}

function getOrCreateDateFolder_(dateStr) {
  let root;
  const connectedFolderId = PropertiesService.getScriptProperties().getProperty(PROP_DRIVE_FOLDER_ID);
  try {
    root = DriveApp.getFolderById(connectedFolderId || DRIVE_ROOT_FOLDER_ID);
  } catch (e) {
    // Folder induk tidak ditemukan/tidak bisa diakses -> pakai folder cadangan otomatis.
    root = getOrCreateFallbackRootFolder_();
  }
  // Pastikan folder induk bisa diakses siapa saja yang punya link (agar SEMUA pengguna,
  // termasuk Operator tanpa akun Google Workspace yang sama, tetap bisa melihat foto).
  try { root.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}

  const tz = Session.getScriptTimeZone() || 'Asia/Jakarta';
  const folderName = normalizeDate_(dateStr) || Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd');

  const existing = root.getFoldersByName(folderName);
  const folder = existing.hasNext() ? existing.next() : root.createFolder(folderName);
  try { folder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
  return folder;
}

/**
 * Menyimpan foto bukti Barang Masuk (base64 data URL dari kamera browser, sudah dibubuhi
 * watermark nama SPPG + stempel waktu di sisi client) ke Google Drive, di dalam folder
 * yang sesuai dengan tanggal hari ini. Dipanggil dari client SEBELUM transaksi disimpan,
 * hasil URL-nya disisipkan ke kolom FotoURL transaksi terkait.
 */
function uploadFotoBarangMasuk(base64DataUrl, refCode) {
  // Fungsi ini SENGAJA tidak membutuhkan token admin — semua pengguna (Admin maupun
  // Operator) boleh langsung mengunggah foto bukti Barang Masuk ke Google Drive.
  try {
    if (!base64DataUrl) return { success: false, message: 'Data foto tidak valid.' };
    const match = String(base64DataUrl).match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
    if (!match) return { success: false, message: 'Format foto tidak dikenali.' };

    const mimeType = match[1];
    const base64Data = match[2];
    const bytes = Utilities.base64Decode(base64Data);
    const ext = (mimeType.split('/')[1] || 'jpg').replace('jpeg', 'jpg');
    const tz = Session.getScriptTimeZone() || 'Asia/Jakarta';
    const todayStr = Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd');
    const customLabel = PropertiesService.getScriptProperties().getProperty(PROP_TIMESTAMP_LABEL);
    const labelPart = customLabel ? (String(customLabel).replace(/[^a-zA-Z0-9_-]/g, '') + '_') : '';
    const fileName = `${labelPart}BarangMasuk_${refCode || 'FOTO'}_${Date.now()}.${ext}`;
    const blob = Utilities.newBlob(bytes, mimeType, fileName);

    const lock = LockService.getScriptLock();
    try {
      lock.waitLock(30000);
      const folder = getOrCreateDateFolder_(todayStr);
      const file = folder.createFile(blob);
      try {
        file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      } catch (shareErr) {
        // Jika berbagi gagal (mis. dibatasi kebijakan domain), file tetap tersimpan di Drive.
      }
      return { success: true, url: file.getUrl(), fileId: file.getId(), folder: folder.getName() };
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    // Jangan sampai kegagalan upload foto membuat seluruh transaksi gagal tersimpan —
    // client akan tetap melanjutkan simpan transaksi tanpa foto jika ini gagal.
    return { success: false, message: (err && err.message) ? err.message : String(err) };
  }
}

// ===========================================================================
//  SETUP AKUN, OTP EMAIL, MANAJEMEN OPERATOR, LISENSI, KONEKSI GDRIVE/SHEET
// ===========================================================================

function hashPassword_(pw) {
  const raw = PASSWORD_SALT + ':' + String(pw == null ? '' : pw);
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, raw, Utilities.Charset.UTF_8);
  return digest.map(b => (b < 0 ? b + 256 : b).toString(16).padStart(2, '0')).join('');
}

function getUsersSheet_() {
  ensureSheets_();
  return getSS_().getSheetByName(SHEET_USERS);
}

function getUsersRows_() {
  return sheetToObjects_(getUsersSheet_());
}

function findUserByRole_(role) {
  return getUsersRows_().find(u => u.Role === role) || null;
}

/**
 * Dipanggil saat aplikasi pertama dibuka untuk menentukan apakah Setup Akun
 * (daftar akun Admin lewat Google + OTP email + buat password) perlu ditampilkan.
 */
function getBootstrapInfo() {
  const adminUser = findUserByRole_('ADMIN');
  let email = '';
  try { email = Session.getActiveUser().getEmail() || ''; } catch (e) {}
  return {
    needsSetup: !adminUser,
    googleEmail: email
  };
}

/** Langkah 1 Setup Akun: kirim kode OTP acak 6 digit ke email pengguna (Google account). */
function sendSignupOtp(email) {
  email = String(email || '').trim();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { success: false, message: 'Alamat email tidak valid.' };
  }
  const otp = String(Math.floor(100000 + Math.random() * 900000)); // 6 digit acak
  CacheService.getScriptCache().put('otp_' + email, otp, OTP_TTL_SEC);
  try {
    MailApp.sendEmail({
      to: email,
      subject: 'Kode Verifikasi ' + getAppName(),
      body: 'Kode verifikasi (OTP) Anda: ' + otp + '\n\nBerlaku selama 5 menit. Jangan bagikan kode ini kepada siapa pun.'
    });
  } catch (err) {
    return { success: false, message: 'Gagal mengirim email OTP: ' + (err && err.message ? err.message : err) };
  }
  return { success: true, message: 'Kode OTP telah dikirim ke ' + email };
}

/** Langkah 2 Setup Akun: verifikasi OTP lalu buat akun Admin dengan password baru. */
function verifySignupOtpAndCreateAdmin(email, otp, password, confirmPassword) {
  email = String(email || '').trim();
  const cached = CacheService.getScriptCache().get('otp_' + email);
  if (!cached || cached !== String(otp || '').trim()) {
    return { success: false, message: 'Kode OTP salah atau sudah kadaluarsa.' };
  }
  if (!password || password.length < 6) {
    return { success: false, message: 'Password minimal 6 karakter.' };
  }
  if (password !== confirmPassword) {
    return { success: false, message: 'Konfirmasi password tidak sama.' };
  }
  if (findUserByRole_('ADMIN')) {
    return { success: false, message: 'Akun Admin sudah pernah dibuat sebelumnya.' };
  }
  const sheet = getUsersSheet_();
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    sheet.appendRow([generateUniqueId_(), 'Admin SPPG', email, 'ADMIN', hashPassword_(password), new Date(), 'AKTIF']);
  } finally {
    lock.releaseLock();
  }
  CacheService.getScriptCache().remove('otp_' + email);
  return { success: true, message: 'Akun Admin berhasil dibuat. Silakan login.' };
}

/** Admin mengganti password akun Admin sendiri. */
function changeAdminPassword(oldPassword, newPassword, confirmPassword, token) {
  requireAdmin_(token);
  if (!newPassword || newPassword.length < 6) throw new Error('Password baru minimal 6 karakter.');
  if (newPassword !== confirmPassword) throw new Error('Konfirmasi password baru tidak sama.');

  const sheet = getUsersSheet_();
  const rows = sheet.getDataRange().getValues();
  const headers = rows[0];
  const roleCol = headers.indexOf('Role');
  const hashCol = headers.indexOf('PasswordHash');
  for (let i = 1; i < rows.length; i++) {
    if (rows[i][roleCol] === 'ADMIN') {
      if (rows[i][hashCol] && rows[i][hashCol] !== hashPassword_(oldPassword)) {
        throw new Error('Password lama salah.');
      }
      sheet.getRange(i + 1, hashCol + 1).setValue(hashPassword_(newPassword));
      return { success: true, message: 'Password Admin berhasil diganti.' };
    }
  }
  // Belum ada baris Admin (masih pakai fallback ADMIN_PASSWORD) -> buat baris baru.
  if (String(oldPassword) !== ADMIN_PASSWORD) throw new Error('Password lama salah.');
  sheet.appendRow([generateUniqueId_(), 'Admin SPPG', '', 'ADMIN', hashPassword_(newPassword), new Date(), 'AKTIF']);
  return { success: true, message: 'Password Admin berhasil diganti.' };
}

/** Daftar nama akun Operator saja (tanpa password), untuk dropdown di layar login. */
function listOperatorNames() {
  return getUsersRows_()
    .filter(u => u.Role === 'OPERATOR' && u.Status !== 'NONAKTIF')
    .map(u => u.Nama);
}

/** Daftar operator lengkap untuk panel "Create Operator" (Admin only). */
function listOperators(token) {
  requireAdmin_(token);
  return getUsersRows_()
    .filter(u => u.Role === 'OPERATOR')
    .map(u => ({ id: u.ID, nama: u.Nama, status: u.Status || 'AKTIF', createdAt: u.CreatedAt }));
}

/**
 * Admin bebas membuat akun Operator baru dengan nama & password masing-masing.
 * Sekaligus mengeluarkan SATU kode lisensi (1x pakai) dari LICENSE_POOL dan membungkusnya
 * jadi tautan aktivasi siap-klik, supaya Operator yang baru cukup: buka tautan -> tombol
 * "Aktifkan" otomatis terisi kodenya -> login pakai nama & password di atas. Admin TIDAK
 * perlu lagi mengambil kode lisensi secara manual dari halaman Pengaturan.
 */
function createOperator(name, password, confirmPassword, token) {
  requireAdmin_(token);
  name = String(name || '').trim();
  if (!name) throw new Error('Nama operator wajib diisi.');
  if (!password || password.length < 4) throw new Error('Password minimal 4 karakter.');
  if (password !== confirmPassword) throw new Error('Konfirmasi password tidak sama.');

  const sheet = getUsersSheet_();
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const existing = getUsersRows_().find(u => u.Role === 'OPERATOR' && String(u.Nama).toLowerCase() === name.toLowerCase());
    if (existing) throw new Error('Nama operator "' + name + '" sudah dipakai.');
    sheet.appendRow([generateUniqueId_(), name, '', 'OPERATOR', hashPassword_(password), new Date(), 'AKTIF']);
  } finally {
    lock.releaseLock();
  }
  const code = dispenseLicenseCode_();
  const link = buildActivationLink_(code);
  return {
    success: true,
    message: 'Akun operator "' + name + '" berhasil dibuat.',
    licenseCode: code,
    activationLink: link
  };
}

/**
 * Admin mengganti password milik salah satu akun Operator.
 * Sekaligus menerbitkan kode lisensi BARU (1x pakai) + tautan aktivasi, supaya perangkat
 * lama otomatis "terputus" (kode lamanya tidak dipakai lagi) dan Operator wajib
 * mengaktifkan ulang aplikasinya di perangkat (baru atau sama) memakai kode yang baru ini.
 * Cocok dipakai saat Operator ganti HP, lupa password, atau perangkat lama hilang.
 */
function updateOperatorPassword(name, newPassword, confirmPassword, token) {
  requireAdmin_(token);
  if (!newPassword || newPassword.length < 4) throw new Error('Password minimal 4 karakter.');
  if (newPassword !== confirmPassword) throw new Error('Konfirmasi password tidak sama.');

  const sheet = getUsersSheet_();
  const rows = sheet.getDataRange().getValues();
  const headers = rows[0];
  const nameCol = headers.indexOf('Nama'), roleCol = headers.indexOf('Role'), hashCol = headers.indexOf('PasswordHash');
  for (let i = 1; i < rows.length; i++) {
    if (rows[i][roleCol] === 'OPERATOR' && String(rows[i][nameCol]) === String(name)) {
      sheet.getRange(i + 1, hashCol + 1).setValue(hashPassword_(newPassword));
      const code = dispenseLicenseCode_();
      const link = buildActivationLink_(code);
      return {
        success: true,
        message: 'Password operator "' + name + '" berhasil diganti.',
        licenseCode: code,
        activationLink: link
      };
    }
  }
  throw new Error('Akun operator tidak ditemukan.');
}

/** Admin menonaktifkan/menghapus akun Operator. */
function deleteOperator(name, token) {
  requireAdmin_(token);
  const sheet = getUsersSheet_();
  const rows = sheet.getDataRange().getValues();
  const headers = rows[0];
  const nameCol = headers.indexOf('Nama'), roleCol = headers.indexOf('Role');
  for (let i = 1; i < rows.length; i++) {
    if (rows[i][roleCol] === 'OPERATOR' && String(rows[i][nameCol]) === String(name)) {
      sheet.deleteRow(i + 1);
      return { success: true, message: 'Akun operator "' + name + '" dihapus.' };
    }
  }
  throw new Error('Akun operator tidak ditemukan.');
}


// -------------------------- LISENSI INSTALASI --------------------------
/**
 * Mengeluarkan (dispense) kode lisensi berikutnya dari daftar resmi LICENSE_POOL
 * yang BELUM pernah dipakai. Dipanggil oleh Admin untuk dibagikan manual via WhatsApp.
 * Dibungkus LockService agar dua permintaan Admin yang bersamaan tidak mengeluarkan kode kembar.
 */
/**
 * Fungsi internal: mengeluarkan (dispense) satu kode lisensi berikutnya dari LICENSE_POOL
 * yang belum pernah dipakai. Dipakai oleh createOperator/updateOperatorPassword untuk
 * membuat tautan aktivasi otomatis, TANPA perlu tombol "Ambil Kode Lisensi" manual lagi.
 * Dibungkus LockService agar dua permintaan bersamaan tidak mengeluarkan kode kembar.
 */
function dispenseLicenseCode_() {
  ensureSheets_();
  const pool = LICENSE_POOL;
  if (!pool || !pool.length) throw new Error('Daftar kode lisensi (LICENSE_POOL) kosong.');

  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const usedSet = getUsedLicenseSet_();
    const props = PropertiesService.getScriptProperties();
    let idx = parseInt(props.getProperty(PROP_LICENSE_SEQ), 10);
    if (!isFinite(idx) || idx < 0) idx = 0;

    // Ambil kode berikutnya dari daftar resmi yang BELUM pernah dipakai, mulai dari posisi tersimpan.
    let code = null;
    for (let step = 0; step < pool.length; step++) {
      const candidate = pool[(idx + step) % pool.length];
      if (!usedSet[candidate]) {
        code = candidate;
        props.setProperty(PROP_LICENSE_SEQ, String((idx + step + 1) % pool.length));
        break;
      }
    }
    if (!code) throw new Error('Semua kode lisensi pada daftar sudah terpakai.');
    return code;
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

/**
 * DIPERTAHANKAN untuk kompatibilitas lama — tidak lagi dipanggil dari tombol Pengaturan
 * (tombol "Ambil Kode Lisensi" sudah dihapus dari UI). Kode lisensi kini otomatis
 * dibuat & dibagikan lewat tautan aktivasi saat Admin menambah/reset akun Operator.
 */
function adminGenerateLicenseCode(token) {
  requireAdmin_(token);
  return { success: true, code: dispenseLicenseCode_() };
}

/** Membuat tautan aktivasi (berisi kode lisensi 1x-pakai) untuk dibagikan ke sebuah perangkat Operator. */
function buildActivationLink_(code) {
  let base = '';
  try { base = ScriptApp.getService().getUrl(); } catch (e) {}
  const sep = base.indexOf('?') === -1 ? '?' : '&';
  return (base || '') + sep + 'lisensi=' + encodeURIComponent(code);
}

/**
 * Jalankan fungsi ini SEKALI SAJA secara manual dari editor Apps Script (tombol ▶ Run),
 * SEBELUM deploy pertama kali / sebelum sheet Licenses punya baris apa pun. Ini adalah
 * satu-satunya cara membuat kode lisensi tanpa token Admin, karena saat itu belum ada
 * akun Admin yang bisa login untuk membuat kode via tombol "Buat Kode Baru" di Pengaturan.
 * Setelah sheet Licenses berisi minimal 1 baris, fungsi ini otomatis terkunci selamanya.
 */
function bootstrapFirstLicenseCode() {
  // Tidak diperlukan lagi. Seluruh kode lisensi kini berasal dari daftar resmi (LICENSE_POOL)
  // dan langsung berlaku 1x pakai tanpa perlu di-bootstrap. Fungsi ini sengaja dikosongkan
  // agar tidak merusak instruksi lama yang mungkin masih memanggilnya.
  Logger.log('bootstrapFirstLicenseCode: tidak diperlukan lagi. Kode lisensi memakai daftar LICENSE_POOL (siap pakai, 1x pemakaian).');
  return 'LICENSE_POOL aktif — tidak perlu bootstrap.';
}

/** Kumpulan (map) kode lisensi yang sudah berstatus USED di sheet Licenses. */
function getUsedLicenseSet_() {
  const rows = getLicenseRows_();
  const set = {};
  rows.forEach(r => { if (String(r.Status) === 'USED') set[String(r.Code)] = true; });
  return set;
}

function getLicenseRows_() {
  ensureSheets_();
  return sheetToObjects_(getSS_().getSheetByName(SHEET_LICENSES));
}

/**
 * Verifikasi kode lisensi yang diketik user di gerbang instalasi (setelah APK/PWA
 * terpasang, sebelum layar login muncul). Kode HARUS sudah pernah dibuat lewat
 * adminGenerateLicenseCode dan berstatus BELUM_DIPAKAI. Setelah dipakai, kode
 * langsung ditandai USED dan tidak dapat dipakai lagi di perangkat lain.
 */
function verifyLicenseCode(code, deviceId) {
  code = String(code || '').trim();
  if (!code) return { success: false, message: 'Kode lisensi wajib diisi.' };

  // Kode HARUS berasal dari daftar resmi (LICENSE_POOL). Seri kode lama "Tool..." TIDAK berlaku lagi.
  if (!LICENSE_POOL_SET[code]) {
    return { success: false, message: 'Kode lisensi tidak dikenali. Silakan minta kode baru via WhatsApp.' };
  }

  ensureSheets_();
  const sheet = getSS_().getSheetByName(SHEET_LICENSES);
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const rows = sheet.getDataRange().getValues();
    const headers = rows[0];
    const codeCol = headers.indexOf('Code'), statusCol = headers.indexOf('Status'),
          usedAtCol = headers.indexOf('UsedAt'), deviceCol = headers.indexOf('DeviceId');
    // Jika kode sudah pernah tercatat -> hanya boleh 1x pakai.
    for (let i = 1; i < rows.length; i++) {
      if (String(rows[i][codeCol]) === code) {
        if (rows[i][statusCol] === 'USED') {
          return { success: false, message: 'Kode ini sudah pernah dipakai untuk instalasi lain.' };
        }
        sheet.getRange(i + 1, statusCol + 1).setValue('USED');
        sheet.getRange(i + 1, usedAtCol + 1).setValue(new Date());
        sheet.getRange(i + 1, deviceCol + 1).setValue(deviceId || '');
        return { success: true, message: 'Kode valid. Selamat menggunakan aplikasi.' };
      }
    }
    // Kode valid dari daftar & belum pernah dipakai -> tandai USED sekarang (aktivasi pertama).
    sheet.appendRow([code, 'USED', new Date(), deviceId || '']);
    return { success: true, message: 'Kode valid. Selamat menggunakan aplikasi.' };
  } finally {
    lock.releaseLock();
  }
}

function getLicenseWhatsappNumber() {
  return LICENSE_WA_NUMBER;
}

/** Nama aplikasi yang tampil di login/sidebar/judul/WhatsApp. Bisa diakses tanpa login. */
function getAppName() {
  try {
    const name = PropertiesService.getScriptProperties().getProperty(PROP_APP_NAME);
    return (name && String(name).trim()) ? String(name).trim() : DEFAULT_APP_NAME;
  } catch (e) {
    return DEFAULT_APP_NAME;
  }
}

/** Admin mengganti nama aplikasi. */
function setAppName(name, token) {
  requireAdmin_(token);
  name = String(name || '').trim();
  if (!name) throw new Error('Nama aplikasi tidak boleh kosong.');
  if (name.length > 60) throw new Error('Nama aplikasi maksimal 60 karakter.');
  PropertiesService.getScriptProperties().setProperty(PROP_APP_NAME, name);
  return { success: true, message: 'Nama aplikasi berhasil diganti menjadi: ' + name, appName: name };
}


// -------------------- KONEKSI GOOGLE DRIVE / SPREADSHEET --------------------
function extractDriveFolderId_(link) {
  const m = String(link || '').match(/[-\w]{25,}/);
  return m ? m[0] : null;
}

function extractSpreadsheetId_(link) {
  const m = String(link || '').match(/\/d\/([-\w]{25,})/) || String(link || '').match(/[-\w]{25,}/);
  return m ? (m[1] || m[0]) : null;
}

/** Admin menghubungkan folder Google Drive tempat foto barang masuk akan disimpan. */
function connectGoogleDrive(link, token) {
  requireAdmin_(token);
  const id = extractDriveFolderId_(link);
  if (!id) throw new Error('Link Google Drive tidak valid.');
  let folder;
  try {
    folder = DriveApp.getFolderById(id);
    folder.getName(); // pastikan benar-benar bisa diakses (akses Editor)
  } catch (e) {
    throw new Error('Folder tidak ditemukan atau belum dibagikan dengan akses Editor ke akun ini.');
  }
  PropertiesService.getScriptProperties().setProperty(PROP_DRIVE_FOLDER_ID, id);
  return { success: true, message: 'Terhubung ke folder Drive: ' + folder.getName() };
}

/** Admin menghubungkan Google Spreadsheet sebagai database transaksi/master barang. */
function connectSpreadsheet(link, token) {
  requireAdmin_(token);
  const id = extractSpreadsheetId_(link);
  if (!id) throw new Error('Link Google Spreadsheet tidak valid.');
  let ss;
  try {
    ss = SpreadsheetApp.openById(id);
    ss.getName(); // pastikan benar-benar bisa diakses (akses Editor)
  } catch (e) {
    throw new Error('Spreadsheet tidak ditemukan atau belum dibagikan dengan akses Editor ke akun ini.');
  }
  PropertiesService.getScriptProperties().setProperty(PROP_SPREADSHEET_ID, id);
  ensureSheets_(); // siapkan sheet Produk/Transaksi/dst di spreadsheet baru jika belum ada
  return { success: true, message: 'Terhubung ke spreadsheet: ' + ss.getName() };
}

/** Info koneksi saat ini + custom timestamp, untuk ditampilkan di laman Pengaturan. */
function getConnectionSettings(token) {
  requireAdmin_(token);
  const props = PropertiesService.getScriptProperties();
  const driveId = props.getProperty(PROP_DRIVE_FOLDER_ID) || '';
  const sheetId = props.getProperty(PROP_SPREADSHEET_ID) || '';
  const label = props.getProperty(PROP_TIMESTAMP_LABEL) || '';
  const changedAt = props.getProperty(PROP_TIMESTAMP_CHANGED);

  let nextEditableAt = null, canEditNow = true;
  if (changedAt) {
    const changedDate = new Date(Number(changedAt));
    const next = new Date(changedDate.getTime() + TIMESTAMP_LOCK_DAYS * 24 * 60 * 60 * 1000);
    if (next > new Date()) { nextEditableAt = next.toISOString(); canEditNow = false; }
  }

  return {
    driveFolderId: driveId,
    driveFolderUrl: driveId ? ('https://drive.google.com/drive/folders/' + driveId) : '',
    spreadsheetId: sheetId,
    spreadsheetUrl: sheetId ? ('https://docs.google.com/spreadsheets/d/' + sheetId) : '',
    timestampLabel: label,
    canEditTimestampNow: canEditNow,
    timestampNextEditableAt: nextEditableAt,
    appName: getAppName()
  };
}

/**
 * Getter PUBLIK (tanpa token) untuk label custom timestamp — dipanggil oleh SEMUA
 * pengguna yang sudah login (Admin maupun Operator) supaya label ini juga tampil
 * sebagai teks stempel waktu di foto Barang Masuk, bukan cuma dipakai diam-diam
 * sebagai awalan nama file di Google Drive seperti sebelumnya.
 */
function getPublicTimestampLabel() {
  try {
    return PropertiesService.getScriptProperties().getProperty(PROP_TIMESTAMP_LABEL) || '';
  } catch (e) {
    return '';
  }
}

/** Ganti label "custom timestamp" (dipakai sebagai awalan nama file foto Barang Masuk). Maks 1x / 10 hari. */
function setCustomTimestampLabel(label, token) {
  requireAdmin_(token);
  label = String(label || '').trim();
  if (!label) throw new Error('Label timestamp tidak boleh kosong.');

  const props = PropertiesService.getScriptProperties();
  const changedAt = props.getProperty(PROP_TIMESTAMP_CHANGED);
  if (changedAt) {
    const changedDate = new Date(Number(changedAt));
    const nextEditable = new Date(changedDate.getTime() + TIMESTAMP_LOCK_DAYS * 24 * 60 * 60 * 1000);
    if (nextEditable > new Date()) {
      const sisaHari = Math.ceil((nextEditable.getTime() - Date.now()) / (24 * 60 * 60 * 1000));
      throw new Error('Custom timestamp hanya bisa diganti setiap ' + TIMESTAMP_LOCK_DAYS + ' hari. Coba lagi dalam ' + sisaHari + ' hari.');
    }
  }
  props.setProperty(PROP_TIMESTAMP_LABEL, label);
  props.setProperty(PROP_TIMESTAMP_CHANGED, String(Date.now()));
  return { success: true, message: 'Custom timestamp berhasil disimpan: ' + label };
}


// =========================================================================
//  DAFTAR RESMI KODE LISENSI (LICENSE_POOL)
//  5000 kode 8-digit. Setiap kode hanya berlaku 1x pemakaian.
//  Kode seri lama "Tool..." sudah dinonaktifkan total.
// =========================================================================
const LICENSE_POOL = [
  '00000562','00011833','00015353','00016340','00017835','00027420','00039213','00044394','00050008','00073479',
  '00086046','00088299','00088733','00090226','00092744','00112495','00114922','00115565','00119517','00144644',
  '00173288','00185014','00186192','00193481','00197732','00197994','00203577','00204464','00216589','00218477',
  '00218480','00223126','00227684','00230886','00232527','00234515','00239973','00246951','00247074','00248160',
  '00250189','00250587','00253658','00254784','00255762','00256287','00258555','00259846','00260759','00264233',
  '00264726','00268433','00270410','00275071','00301639','00303990','00306755','00307546','00310152','00312063',
  '00320913','00321675','00331077','00331906','00333809','00345692','00352623','00353104','00356621','00359961',
  '00366074','00366817','00374786','00374925','00382785','00386763','00389892','00392458','00393123','00393510',
  '00404033','00405007','00405551','00408443','00415744','00420094','00423986','00424990','00426134','00430685',
  '00430950','00438241','00442661','00443148','00443312','00445263','00448990','00463446','00476738','00478688',
  '00494416','00507583','00510601','00514915','00519160','00534935','00535725','00535996','00538128','00541101',
  '00541676','00541958','00543641','00545136','00558323','00565767','00566293','00567601','00582516','00587122',
  '00587550','00588407','00591484','00606779','00612929','00616484','00616656','00618790','00622468','00624644',
  '00624647','00626529','00634967','00637634','00674354','00675727','00680628','00683309','00692500','00693884',
  '00694334','00697038','00716878','00720195','00730148','00732879','00737160','00747476','00750831','00754491',
  '00755477','00762387','00766258','00776666','00777726','00781057','00784438','00791143','00791232','00803557',
  '00812414','00812613','00815141','00819467','00821757','00827080','00833335','00836006','00836426','00839010',
  '00854116','00855708','00869017','00870639','00875537','00875569','00876253','00881457','00883230','00883288',
  '00885624','00885886','00887979','00896983','00898280','00920929','00932540','00937227','00949239','00973257',
  '00978383','00979164','00980168','00988825','00989776','01004083','01007088','01019190','01025229','01033291',
  '01037091','01037417','01039247','01048973','01064412','01081856','01082772','01083463','01101311','01105199',
  '01108141','01113740','01116585','01123992','01124893','01125983','01135056','01137491','01141844','01146013',
  '01146248','01154753','01156528','01162330','01164974','01167110','01179497','01188131','01190102','01199745',
  '01209960','01212042','01212367','01217097','01228248','01232400','01234316','01239208','01245005','01257633',
  '01267078','01268904','01284325','01288066','01290429','01296290','01298927','01312979','01315779','01328249',
  '01329258','01331579','01334353','01360828','01365981','01372985','01374692','01387516','01388382','01394135',
  '01395183','01404719','01427669','01434572','01437142','01438102','01442686','01449613','01465322','01469201',
  '01469758','01501783','01508406','01509806','01515272','01517048','01517722','01523001','01537701','01539468',
  '01548152','01562310','01568407','01570366','01570543','01587378','01592390','01593545','01593632','01596048',
  '01599430','01602937','01603745','01604118','01613307','01614763','01618554','01624029','01636529','01649437',
  '01652195','01652423','01658430','01669275','01678012','01692944','01694073','01694236','01694401','01704704',
  '01714343','01716917','01730382','01733080','01733398','01735503','01736992','01739485','01741673','01743882',
  '01743963','01744859','01745471','01745791','01746419','01750392','01750737','01764481','01767165','01767933',
  '01769299','01774074','01778517','01780944','01794949','01804229','01804385','01813253','01813521','01814095',
  '01814978','01815287','01816923','01819244','01836637','01844131','01844140','01846552','01847893','01849164',
  '01852740','01857555','01863435','01877493','01894384','01895567','01896353','01907029','01908602','01911633',
  '01921821','01923925','01935765','01938867','01954226','01961740','01965883','01970691','01974071','01974608',
  '01985421','01990346','01992558','01998479','02005451','02008471','02008969','02009112','02011333','02016437',
  '02020298','02026648','02032816','02032941','02040330','02044549','02046172','02048762','02050175','02061494',
  '02066176','02067861','02072211','02085071','02092450','02096348','02101379','02104720','02107064','02112158',
  '02118800','02118865','02123469','02124420','02125364','02138038','02138841','02155309','02160376','02160819',
  '02163957','02172031','02179886','02185637','02190265','02190880','02194877','02197642','02198132','02201254',
  '02208395','02219071','02222637','02227387','02242687','02243150','02244341','02255926','02257337','02261793',
  '02279990','02282845','02283276','02283850','02288995','02313586','02317125','02319600','02322909','02331235',
  '02331872','02335179','02335600','02342236','02350987','02351836','02357918','02361907','02362742','02365562',
  '02366429','02370004','02371028','02372928','02383741','02388174','02388391','02394212','02394527','02407114',
  '02413018','02414338','02415386','02425691','02435435','02436257','02437379','02437733','02440870','02443201',
  '02444449','02447035','02452338','02453392','02454106','02454688','02455412','02456846','02458076','02465632',
  '02477743','02478597','02482794','02482919','02483281','02485373','02488132','02488521','02511614','02519010',
  '02527471','02541561','02542035','02542735','02543197','02544248','02546726','02549082','02549308','02556817',
  '02565826','02565875','02567407','02572395','02575943','02580498','02585103','02587207','02595912','02596682',
  '02597420','02600286','02603184','02608779','02609767','02617744','02620841','02624730','02631782','02633578',
  '02645027','02646976','02647357','02656516','02659158','02661069','02668349','02678914','02679126','02681243',
  '02689678','02695756','02701383','02705431','02709904','02712468','02720232','02723031','02723589','02738718',
  '02739182','02742494','02742666','02746362','02751296','02758684','02767521','02774018','02776958','02783219',
  '02784851','02787255','02792287','02794840','02800872','02804568','02808298','02812904','02815232','02817440',
  '02820667','02822653','02837621','02842604','02856222','02863356','02863484','02866605','02867699','02870177',
  '02871587','02882148','02883004','02885381','02888520','02899747','02907732','02912503','02915093','02924645',
  '02934794','02937417','02938477','02944197','02945118','02952190','02956273','02957693','02958544','02967765',
  '02968068','02979393','02982857','02998312','02998335','03003716','03006127','03031952','03038713','03044452',
  '03049969','03054204','03058086','03061054','03071332','03076327','03078171','03092404','03097804','03098127',
  '03105111','03105628','03110372','03117724','03119452','03132249','03143891','03146222','03149712','03149767',
  '03155777','03157416','03159408','03160160','03170677','03172481','03188205','03196546','03205253','03206773',
  '03217496','03218958','03222005','03227245','03236981','03242562','03248243','03251202','03252712','03256232',
  '03275183','03278515','03278854','03288364','03288722','03296279','03296807','03303142','03304494','03306290',
  '03316044','03318636','03321469','03327465','03327958','03334053','03335821','03340128','03340282','03349464',
  '03349633','03350925','03357303','03362464','03390283','03394360','03403914','03405308','03407696','03411718',
  '03429888','03434906','03444638','03445724','03454930','03459985','03469712','03469747','03473733','03474127',
  '03486971','03487916','03493426','03494196','03499363','03507188','03508904','03516803','03519971','03520052',
  '03521129','03531645','03533055','03534431','03545909','03549481','03550719','03574924','03581217','03582182',
  '03587420','03590734','03593616','03596318','03598836','03602192','03602472','03611025','03619972','03623468',
  '03623842','03623995','03624051','03627938','03639792','03654732','03659201','03665071','03666067','03667347',
  '03667891','03668558','03670456','03681382','03686722','03690695','03699007','03699517','03705412','03711926',
  '03721639','03723970','03725013','03729757','03735283','03735565','03747717','03757305','03760841','03766358',
  '03767506','03768569','03773279','03774811','03780961','03798280','03801008','03816925','03818780','03819478',
  '03822256','03822741','03822963','03828722','03833899','03834827','03839283','03840183','03846968','03854342',
  '03855929','03868398','03869829','03869890','03873126','03883051','03885932','03887317','03894784','03896638',
  '03897907','03899034','03899528','03903053','03903520','03906385','03907217','03926374','03934619','03940625',
  '03942825','03955566','03955663','03956873','03959508','03960093','03971633','03972451','03972621','03974078',
  '03979632','03994654','04004087','04006680','04007154','04010581','04017665','04025820','04028939','04039222',
  '04062182','04063397','04077528','04083462','04084100','04085434','04086390','04087714','04091615','04092927',
  '04095405','04097141','04110049','04111700','04120840','04126640','04130045','04131887','04137372','04137998',
  '04139671','04141298','04147521','04150609','04163070','04164341','04166881','04185499','04189874','04198583',
  '04199345','04200785','04209572','04212152','04218969','04227547','04230527','04251207','04258560','04258597',
  '04268167','04275329','04276018','04299430','04302736','04305987','04307534','04308816','04310169','04315732',
  '04318327','04320341','04324934','04329076','04343324','04359416','04365044','04365269','04377076','04388522',
  '04398909','04399063','04404995','04407347','04424215','04425972','04428094','04434159','04436557','04441703',
  '04459103','04462824','04470573','04477071','04484013','04485387','04485689','04489384','04495857','04495931',
  '04499554','04500752','04501409','04505524','04506971','04507154','04508946','04511787','04522227','04522359',
  '04533629','04545710','04545745','04548333','04549910','04557814','04558275','04558609','04564242','04564970',
  '04568333','04572697','04580154','04580360','04586146','04586778','04587982','04591101','04605090','04612776',
  '04616195','04625073','04639514','04650756','04656321','04656452','04664229','04677805','04689294','04699245',
  '04705406','04709244','04709586','04714694','04722846','04724635','04732618','04734017','04734196','04736734',
  '04762101','04764655','04765347','04766360','04766424','04766836','04775665','04779375','04790009','04790916',
  '04810116','04819242','04821502','04823800','04823896','04825402','04827905','04829210','04833145','04837879',
  '04840096','04842469','04846003','04861309','04864559','04870910','04877153','04883182','04903165','04914211',
  '04934997','04936966','04941257','04946375','04949019','04952284','04952436','04954310','04962444','04963486',
  '04983702','04992419','04995142','04997553','05000967','05002175','05018977','05019826','05021128','05027645',
  '05031756','05031904','05033118','05034844','05044027','05044262','05045225','05058769','05068719','05071920',
  '05072733','05074040','05075556','05075561','05087085','05088242','05099004','05108736','05109724','05111940',
  '05116924','05118213','05126556','05129610','05130533','05131528','05133041','05134360','05134421','05136267',
  '05137485','05138628','05141584','05146790','05151984','05154818','05165217','05178578','05182656','05183748',
  '05186280','05187190','05188772','05190187','05204654','05212001','05218108','05220933','05228676','05259099',
  '05272007','05274232','05275340','05276390','05287523','05291720','05294669','05302622','05304612','05305969',
  '05310088','05313629','05318591','05318812','05319947','05320114','05326393','05330322','05336571','05346302',
  '05347196','05348642','05358328','05361418','05361904','05376171','05392159','05394405','05397280','05402874',
  '05406387','05413866','05415523','05415953','05417593','05421213','05428692','05432059','05436364','05444306',
  '05445536','05446506','05454308','05463376','05473670','05473918','05481326','05491864','05496546','05507460',
  '05515033','05519314','05530790','05531054','05531628','05542129','05545284','05552177','05565853','05569193',
  '05578175','05582636','05583996','05591804','05599360','05601316','05606263','05617102','05617590','05640885',
  '05645396','05645522','05659205','05660360','05663056','05672945','05684072','05687336','05697138','05703590',
  '05713887','05722420','05722853','05729437','05730247','05730983','05731149','05736202','05746394','05749040',
  '05754822','05756786','05757206','05763345','05763546','05782351','05786944','05794803','05804742','05806675',
  '05807518','05809983','05816868','05818651','05831794','05845652','05848865','05858017','05864337','05865776',
  '05866773','05871895','05873538','05879114','05880233','05882559','05886280','05895856','05903551','05909762',
  '05916006','05927974','05931088','05933710','05945618','05945850','05951914','05956011','05963840','05981867',
  '05982694','05983940','05999398','06004282','06006315','06008615','06009592','06011810','06017320','06023140',
  '06026720','06032854','06034785','06037105','06040616','06051265','06053898','06054493','06057813','06060899',
  '06080801','06098423','06098930','06110015','06117132','06117589','06123839','06126799','06127988','06137326',
  '06138972','06152977','06153835','06157864','06166478','06172796','06182300','06185361','06186622','06198643',
  '06207047','06207574','06207692','06212928','06213135','06213782','06215746','06216039','06217789','06220912',
  '06228631','06238639','06246132','06251820','06251997','06252674','06259301','06260522','06289208','06297890',
  '06299853','06308157','06314725','06315942','06317068','06317954','06320536','06321708','06332172','06336124',
  '06337814','06339161','06346717','06349046','06352769','06357423','06359737','06361614','06372089','06377702',
  '06381769','06382054','06389068','06390906','06392160','06401858','06403182','06404953','06405652','06406492',
  '06409299','06409803','06415804','06416771','06418980','06420800','06427401','06429719','06441288','06445511',
  '06446465','06447811','06475126','06475437','06480929','06482211','06490138','06493341','06495500','06496155',
  '06496497','06503849','06506782','06508603','06511009','06516966','06521184','06530550','06530574','06532945',
  '06545628','06546586','06548234','06549105','06550408','06559085','06559170','06568424','06571084','06586934',
  '06588414','06594572','06600928','06610980','06611356','06626978','06629099','06639412','06639533','06646107',
  '06651641','06664616','06685277','06685720','06691354','06702033','06703253','06734540','06734991','06736712',
  '06740218','06742002','06746671','06751768','06755431','06760350','06760573','06760963','06771531','06772660',
  '06779083','06785789','06785811','06787792','06799618','06801196','06802498','06817831','06820135','06835794',
  '06842061','06842901','06844564','06846640','06848250','06850721','06853214','06872618','06875231','06884453',
  '06893447','06895092','06896760','06922409','06922472','06923803','06925328','06929318','06929400','06938264',
  '06938704','06938961','06944182','06954743','06958708','06964002','06964104','06966472','06966732','06967536',
  '06971878','06975140','06979646','06980828','06983113','06988775','06989315','06999595','07004751','07007453',
  '07013681','07015119','07023103','07039864','07052568','07058448','07070461','07071435','07083169','07084732',
  '07092383','07103318','07106901','07113704','07122650','07132625','07135803','07151034','07151362','07152394',
  '07177791','07181331','07187447','07197810','07198287','07204824','07207365','07218234','07220216','07221295',
  '07228399','07248216','07256070','07259491','07259558','07261448','07266871','07268433','07269102','07270742',
  '07273534','07273602','07274196','07275110','07275514','07277728','07280203','07287706','07293389','07298806',
  '07308065','07313495','07319307','07335436','07345979','07346527','07347885','07349090','07349361','07351479',
  '07362299','07368249','07376425','07384654','07385943','07402517','07409267','07419626','07420861','07426150',
  '07438049','07448974','07456875','07460432','07465862','07475619','07484872','07485275','07493552','07494487',
  '07494603','07496630','07497892','07504829','07505938','07508028','07514199','07519586','07521504','07528960',
  '07535232','07554895','07570946','07576322','07583767','07593525','07604732','07618329','07624171','07632518',
  '07638042','07642118','07652640','07657955','07660826','07661460','07662215','07668452','07668800','07670437',
  '07682322','07684233','07689960','07694456','07704870','07718914','07731626','07732084','07743415','07749721',
  '07755694','07760827','07763916','07767579','07769378','07780232','07781769','07784520','07798532','07808859',
  '07809527','07811073','07833319','07833335','07834642','07837292','07840391','07843977','07844324','07847060',
  '07862610','07867084','07882207','07882824','07884646','07891437','07896244','07896517','07901934','07912603',
  '07914254','07919333','07920689','07930524','07937762','07946602','07950951','07954859','07961248','07963802',
  '07966425','07969232','07982999','07987049','07994388','07997584','08010826','08012051','08012149','08013055',
  '08013705','08020628','08027925','08046442','08046591','08052443','08055070','08055492','08056735','08066717',
  '08078994','08079820','08088585','08092679','08093789','08099123','08102454','08108744','08109982','08111702',
  '08124997','08125709','08142028','08143421','08146416','08149411','08151476','08152845','08154161','08157005',
  '08160676','08163910','08164579','08165690','08169917','08180768','08183259','08186942','08188047','08194379',
  '08197437','08199833','08208916','08216813','08224257','08229471','08238431','08239870','08241940','08245237',
  '08250941','08259613','08262968','08271564','08281327','08288080','08288754','08295240','08296924','08298232',
  '08299408','08304701','08311783','08314159','08322536','08324038','08334056','08335848','08336386','08342357',
  '08349883','08371761','08375341','08376038','08376305','08384895','08387880','08391573','08395527','08396214',
  '08400614','08415439','08415478','08419317','08426247','08428849','08434567','08436418','08437416','08439219',
  '08441374','08444799','08460486','08461047','08480207','08483912','08486409','08489295','08499984','08507092',
  '08507274','08511573','08513011','08515783','08520950','08547713','08548102','08550671','08555020','08559185',
  '08566084','08569810','08573176','08576769','08583670','08587106','08591963','08593029','08600781','08600819',
  '08606249','08618218','08619135','08625506','08626371','08637224','08638332','08644586','08644938','08647310',
  '08652285','08655225','08659790','08670876','08671849','08675278','08675735','08680737','08689904','08708589',
  '08714557','08725338','08727295','08727580','08731565','08732800','08734255','08747947','08747996','08755635',
  '08758593','08766651','08796624','08798653','08803139','08815435','08824053','08826112','08830685','08834171',
  '08837090','08846288','08850475','08853956','08863735','08866025','08868915','08881301','08882783','08884431',
  '08907328','08918894','08921750','08928295','08942133','08953753','08954324','08958076','08959208','08959884',
  '08967552','08973941','08973998','08989349','08990704','08991449','08991959','08993924','09004453','09008395',
  '09009115','09011176','09012305','09012576','09016450','09016870','09019382','09024899','09026034','09026527',
  '09037912','09056403','09069426','09075414','09075985','09083481','09092118','09105203','09112791','09128241',
  '09130220','09146183','09150076','09153055','09153195','09158124','09161880','09177820','09187295','09187486',
  '09187624','09188361','09209165','09215325','09217095','09217282','09222020','09225032','09225863','09225891',
  '09229314','09238434','09244114','09251191','09253073','09257195','09263707','09267831','09270827','09277599',
  '09279563','09287166','09290133','09290250','09292258','09299971','09307419','09311570','09314336','09318062',
  '09318284','09319270','09335280','09336619','09339229','09346173','09353904','09360102','09366263','09366632',
  '09373129','09373183','09373962','09376218','09380856','09381295','09384090','09398986','09404897','09414702',
  '09418959','09421666','09427306','09428856','09432763','09441108','09441590','09449916','09450846','09452996',
  '09455069','09463883','09481888','09487807','09488509','09489900','09491540','09498165','09501166','09504669',
  '09523118','09528785','09533282','09535255','09546487','09548106','09566155','09571203','09576893','09580121',
  '09587845','09590223','09594555','09614527','09616010','09616153','09621429','09622138','09634166','09639354',
  '09643321','09647874','09664132','09664452','09672687','09673883','09677170','09679996','09686414','09687824',
  '09690687','09700911','09704430','09710672','09712574','09714999','09715101','09716067','09717216','09719180',
  '09727755','09732629','09734853','09737769','09754194','09755896','09756530','09772610','09787012','09790058',
  '09790548','09792317','09796010','09801881','09802700','09806982','09817390','09817760','09819965','09821798',
  '09828039','09832036','09832348','09834719','09835695','09842843','09844108','09845736','09854850','09857124',
  '09857793','09860218','09873013','09873656','09874108','09876003','09880281','09890017','09890265','09896798',
  '09901806','09905928','09912540','09931371','09931962','09932448','09934934','09937243','09945610','09945912',
  '09951987','09954719','09955910','09956338','09957907','09961225','09962423','09963434','09969123','09979427',
  '09987639','09994952','09995527','10003803','10006067','10011678','10020536','10026405','10034640','10039248',
  '10043286','10043911','10057288','10074335','10083492','10105593','10109316','10114126','10120214','10130526',
  '10130568','10136098','10137103','10145694','10147739','10149800','10151619','10155801','10156040','10163392',
  '10167290','10170713','10171005','10174223','10177310','10189723','10191864','10194267','10195591','10200600',
  '10222681','10231140','10234873','10238830','10255284','10255727','10260170','10263238','10269883','10280935',
  '10284382','10286224','10287922','10287930','10288959','10296585','10318068','10319425','10319715','10323337',
  '10325063','10340503','10348287','10350646','10354836','10380839','10389560','10392391','10395286','10395672',
  '10399320','10406449','10414536','10432021','10445711','10446142','10451125','10451737','10460205','10462602',
  '10463459','10464517','10473025','10480763','10495283','10498594','10500069','10515468','10534224','10540461',
  '10550055','10552840','10553992','10555757','10555978','10564502','10567611','10582140','10583613','10594071',
  '10602000','10613124','10624487','10630160','10634737','10637904','10641425','10650081','10660844','10673167',
  '10684512','10696173','10702005','10729310','10736905','10737246','10739544','10762056','10765712','10777502',
  '10780291','10788394','10789916','10793002','10800360','10812324','10815659','10815886','10835955','10837202',
  '10837778','10840264','10840625','10845189','10867249','10869325','10871166','10877136','10883144','10890552',
  '10893755','10894471','10901073','10902547','10906200','10914134','10919922','10921176','10922152','10924949',
  '10925071','10925605','10926835','10934034','10935048','10940062','10942267','10948852','10950021','10960432',
  '10962645','10963323','10964508','10965989','10967159','10978605','10985991','10988220','10990688','11005700',
  '11007666','11008472','11010823','11018731','11018878','11021644','11034987','11044047','11046964','11048534',
  '11051914','11058170','11060752','11069268','11069699','11069951','11076366','11078121','11082624','11085869',
  '11090283','11096446','11100106','11106575','11113186','11123932','11125251','11135981','11136031','11137014',
  '11137527','11139191','11140769','11143908','11151849','11154811','11161025','11166623','11169831','11172950',
  '11180640','11180653','11186535','11190655','11192745','11193598','11198903','11215805','11217778','11220225',
  '11231594','11234106','11246694','11247866','11255247','11268581','11270525','11271139','11272660','11280902',
  '11284351','11300205','11303431','11307816','11310594','11321656','11322259','11322558','11326936','11332099',
  '11332206','11338350','11340923','11343711','11348136','11352553','11363606','11363612','11366914','11378203',
  '11380149','11380902','11386937','11400080','11400996','11408112','11409690','11412279','11413261','11419127',
  '11421461','11424182','11434323','11439013','11442852','11447985','11452696','11463250','11464669','11468250',
  '11473221','11480075','11481581','11482545','11482924','11490449','11497956','11502064','11507970','11510522',
  '11516006','11519241','11519834','11520240','11522237','11527172','11547801','11552635','11562755','11566032',
  '11570931','11577830','11583625','11589122','11600128','11602687','11611598','11616056','11618123','11622139',
  '11623149','11626627','11656313','11656572','11657580','11662294','11664349','11666042','11667182','11674881',
  '11676301','11676561','11684691','11687606','11690540','11692368','11695453','11696550','11708309','11717924',
  '11728712','11729187','11735413','11737075','11739821','11746533','11746844','11747984','11752207','11753660',
  '11754763','11755707','11759993','11760502','11762989','11763698','11767527','11774947','11778001','11781551',
  '11788968','11794690','11795039','11796071','11807969','11814028','11825107','11830752','11833241','11837927',
  '11846861','11846996','11861021','11870188','11873006','11881025','11884112','11890807','11892072','11898461',
  '11906579','11907901','11910743','11911706','11915108','11921017','11921585','11932783','11933150','11954066',
  '11955060','11966484','11971876','11983550','11983989','11993123','11994682','11996832','12005656','12026189',
  '12026745','12033284','12035599','12036726','12037722','12038205','12039688','12043244','12043783','12047984',
  '12049161','12049783','12057773','12057979','12061116','12065500','12081062','12083487','12088377','12091798',
  '12105479','12108433','12110924','12134701','12142462','12142670','12143528','12148725','12148784','12153095',
  '12153765','12155918','12156841','12159073','12168955','12177626','12179083','12186977','12203133','12211522',
  '12213738','12217230','12220489','12232125','12248944','12252183','12253274','12257969','12272826','12272956',
  '12276566','12276607','12277763','12286782','12291060','12293612','12301894','12303889','12311925','12316630',
  '12326868','12327146','12335600','12338829','12340370','12343537','12348655','12349789','12352699','12369406',
  '12370513','12371729','12379209','12379431','12384821','12386029','12388384','12390670','12395452','12397151',
  '12400004','12409219','12425536','12425744','12428020','12444270','12445975','12452124','12454222','12462434',
  '12463408','12469115','12475169','12476683','12510305','12520458','12537699','12541546','12549817','12550281',
  '12551278','12551950','12557976','12564113','12579790','12580935','12587320','12592689','12599589','12604555',
  '12608900','12617040','12617170','12623495','12627880','12632720','12638365','12638986','12641089','12641448',
  '12642080','12645613','12655112','12658053','12673871','12674884','12677353','12692291','12694495','12696972',
  '12699630','12703347','12704623','12706132','12710622','12713720','12715741','12720160','12720327','12724453',
  '12724749','12730440','12733471','12735475','12742313','12743584','12754236','12757828','12769637','12771598',
  '12782099','12785476','12785644','12786745','12787171','12788608','12790043','12794086','12804958','12806316',
  '12810468','12815865','12816660','12817208','12817644','12820400','12825008','12825885','12827296','12832307',
  '12838799','12840746','12843217','12846979','12850780','12859893','12863812','12868867','12880176','12880939',
  '12887040','12892726','12899244','12931911','12939762','12942008','12944081','12951658','12952350','12955039',
  '12956782','12958236','12963173','12964218','12967640','12980426','12986615','12988182','12993320','12995425',
  '13000863','13005023','13011886','13035387','13040000','13048273','13049414','13063383','13063634','13071502',
  '13074775','13076931','13077957','13078773','13091400','13098634','13114329','13116713','13118883','13121325',
  '13127368','13136227','13145302','13145384','13147518','13155298','13159657','13173078','13179921','13193617',
  '13207542','13213363','13220590','13233586','13237079','13237577','13240248','13250809','13253636','13262995',
  '13268620','13270147','13270482','13280283','13291101','13294140','13311250','13314535','13319300','13321589',
  '13324396','13332804','13336056','13336483','13340044','13341619','13342007','13342564','13345022','13348368',
  '13357670','13357711','13358388','13360407','13363227','13364349','13378332','13380531','13383789','13398322',
  '13403459','13403931','13413347','13414836','13415545','13416318','13421280','13429569','13430874','13434898',
  '13435602','13440550','13441224','13442091','13444042','13446751','13449418','13475751','13476248','13480596',
  '13480776','13482918','13490091','13493168','13500654','13502868','13505040','13507688','13507908','13514724',
  '13518078','13519171','13525962','13531633','13534807','13536854','13539614','13539693','13557123','13561296',
  '13561436','13577795','13584079','13599864','13600703','13602246','13605718','13608983','13612591','13616671',
  '13624868','13635612','13643418','13647769','13656730','13659212','13669479','13669508','13669677','13676142',
  '13676477','13677542','13679100','13680837','13683902','13690350','13692645','13694024','13695743','13696835',
  '13700232','13700602','13715711','13717177','13723699','13727832','13732525','13743631','13744419','13745591',
  '13750721','13752518','13762269','13768444','13768521','13769899','13779929','13796210','13801143','13807245',
  '13813735','13817114','13824547','13827509','13829020','13843577','13847049','13856791','13859914','13860195',
  '13861654','13865765','13884238','13890185','13896613','13899672','13901137','13901888','13912861','13913143',
  '13914084','13916360','13919373','13922640','13923100','13924113','13925206','13926001','13932202','13935589',
  '13939371','13941928','13945575','13947823','13948980','13971608','13974572','13975474','13988482','13989657',
  '13990245','13998499','14003128','14017875','14019891','14022291','14024697','14027574','14036478','14044193',
  '14051537','14058062','14066492','14078337','14082934','14088576','14093779','14096507','14104667','14129288',
  '14132021','14133406','14137225','14140313','14143715','14158321','14158596','14160099','14164385','14169901',
  '14179003','14182631','14182999','14184373','14188065','14203186','14205731','14227117','14248125','14248294',
  '14256429','14261699','14265607','14271561','14278037','14288095','14290683','14297172','14309627','14315033',
  '14319587','14321293','14323640','14326381','14344726','14347610','14349234','14353873','14389113','14394877',
  '14394912','14395474','14396411','14420916','14422510','14428559','14435483','14443429','14443431','14443527',
  '14458406','14465017','14474767','14475336','14478822','14484308','14488705','14497443','14500499','14501916',
  '14527158','14528503','14529276','14534150','14535625','14540992','14546145','14552358','14552390','14555443',
  '14557985','14560807','14562639','14564365','14567583','14583500','14585582','14590959','14591968','14596432',
  '14600396','14601358','14602795','14604630','14608729','14610022','14617663','14619992','14623986','14625022',
  '14627547','14633574','14640058','14641992','14646786','14674398','14686820','14689898','14690303','14690659',
  '14700027','14707968','14708815','14720589','14723730','14731502','14733449','14734485','14738388','14756777',
  '14757010','14759310','14765252','14775664','14783517','14790862','14799565','14801190','14803131','14805072',
  '14805848','14806586','14809941','14810815','14812043','14815791','14834008','14839715','14843452','14851455',
  '14854718','14859530','14860116','14863706','14869380','14877204','14882339','14883939','14888215','14892960',
  '14896945','14909241','14910242','14914742','14917616','14921685','14926005','14926017','14927247','14939266',
  '14941530','14947788','14958867','14965461','14966626','14966651','14968066','14969582','14983875','14984294',
  '14988265','14988519','14990469','14991646','15000348','15004611','15007450','15007895','15011962','15013241',
  '15014636','15018898','15018930','15019127','15029980','15030928','15033090','15035674','15038737','15042278',
  '15047067','15047599','15050051','15050991','15051632','15055188','15064209','15065407','15072950','15073199',
  '15073306','15073861','15075954','15080734','15081964','15084185','15093522','15093930','15094733','15097760',
  '15110629','15112972','15119936','15131375','15131696','15135107','15136028','15139236','15148638','15155906',
  '15157227','15165977','15170292','15174602','15183174','15184665','15200138','15201665','15202045','15208425',
  '15209501','15212585','15213735','15215513','15220987','15224623','15241993','15250258','15253118','15255705',
  '15256678','15257143','15274057','15282392','15284336','15284420','15291082','15293567','15303061','15310783',
  '15323243','15336763','15338911','15349186','15349404','15354982','15357809','15358010','15359600','15364083',
  '15366177','15368489','15368703','15370090','15378332','15381897','15383786','15384509','15385170','15387008',
  '15392791','15395891','15405284','15407701','15409190','15415317','15421539','15424126','15429547','15435594',
  '15436347','15438832','15447369','15449505','15451648','15453402','15455633','15458381','15459855','15462910',
  '15473609','15473924','15474701','15483549','15489000','15489485','15491643','15499372','15511418','15532039',
  '15544356','15546285','15550236','15558936','15569298','15576489','15579378','15580535','15580620','15598633',
  '15601609','15607867','15609592','15622643','15639388','15646381','15646397','15658951','15660666','15670339',
  '15684892','15684981','15688587','15699624','15711320','15716564','15721919','15723251','15723453','15724051',
  '15726253','15727261','15742216','15760220','15767501','15768759','15768985','15770100','15771512','15776185',
  '15776352','15776716','15782332','15782757','15789772','15793182','15796326','15826620','15832144','15835283',
  '15835746','15840832','15841333','15852947','15859202','15860437','15861767','15861895','15862622','15862899',
  '15864049','15867313','15869896','15871076','15875550','15882115','15895696','15897213','15903907','15907848',
  '15908359','15911231','15917692','15924971','15929586','15929846','15929851','15930578','15936682','15938822',
  '15945067','15950261','15960543','15964561','15966239','15966369','15976601','15980777','15988364','15988739',
  '15994386','16000986','16002686','16008122','16009076','16010012','16011190','16024517','16024686','16024934',
  '16030270','16033700','16046367','16050060','16054553','16054619','16060149','16064011','16081545','16087568',
  '16093459','16097039','16099393','16103121','16109113','16111932','16114569','16116798','16118348','16119171',
  '16127156','16130652','16132334','16134816','16144146','16145492','16148079','16160825','16162119','16162811',
  '16166169','16169200','16172445','16174484','16175666','16182369','16183731','16183768','16185735','16188314',
  '16191754','16193435','16197713','16198073','16198927','16204678','16207146','16217844','16230224','16238890',
  '16256150','16259111','16259363','16264659','16265146','16270141','16276739','16284634','16285168','16291306',
  '16295481','16306743','16308784','16309603','16312807','16320186','16325342','16326726','16327431','16332246',
  '16349765','16350870','16355939','16357257','16360455','16363216','16365245','16367651','16371314','16383243',
  '16386858','16391443','16393926','16403318','16405731','16409679','16410680','16414440','16415334','16422240',
  '16422589','16425638','16428628','16431613','16433284','16442601','16448410','16450102','16450226','16459521',
  '16473138','16479819','16489245','16490373','16497114','16498631','16499475','16500940','16515814','16522108',
  '16522171','16524880','16525851','16527604','16528644','16536732','16539099','16548630','16549817','16551175',
  '16555018','16559444','16560117','16572074','16573778','16575322','16576156','16578154','16579397','16580038',
  '16581064','16585792','16588098','16589382','16592499','16595962','16598282','16627132','16630359','16639685',
  '16640959','16642928','16649554','16659688','16669149','16669287','16676029','16682773','16694063','16699071',
  '16706397','16706814','16708106','16708171','16708283','16721063','16728387','16728918','16729086','16730803',
  '16736417','16739290','16741049','16744933','16745667','16754386','16754479','16755600','16761925','16775237',
  '16780938','16783514','16785307','16789690','16798899','16804289','16805358','16805359','16819386','16825690',
  '16826374','16832285','16832476','16832710','16835156','16836092','16841959','16853524','16858420','16861340',
  '16861866','16867394','16878054','16882055','16889731','16902284','16904608','16915555','16923628','16923668',
  '16928375','16930344','16935543','16954358','16960586','16968718','16977410','16979247','16983000','16986542',
  '16990314','17005004','17007481','17015430','17017614','17022133','17043185','17055593','17064312','17068774',
  '17072668','17078715','17081006','17093669','17094776','17105119','17107274','17110365','17112896','17113767',
  '17124624','17133869','17136807','17140893','17141934','17149851','17157843','17161046','17165083','17165519',
  '17166438','17168716','17197595','17207915','17209511','17209733','17213252','17216736','17221174','17221666',
  '17223386','17229246','17246060','17247426','17251216','17251446','17251983','17255156','17260434','17262229',
  '17264227','17267612','17275872','17280972','17282589','17284179','17285154','17286947','17288227','17299719',
  '17309148','17317454','17322014','17335202','17343688','17346146','17352684','17356663','17357821','17360716',
  '17364726','17365701','17371838','17377102','17377838','17383640','17389050','17400851','17404425','17406601',
  '17416255','17417902','17424204','17437196','17438411','17439920','17447564','17451472','17463111','17464276',
  '17466583','17468547','17473578','17487488','17488768','17491759','17494250','17496620','17499054','17501711',
  '17504651','17514646','17519334','17526631','17527059','17529067','17529272','17531295','17533331','17534852',
  '17535029','17535492','17536040','17547886','17550520','17556023','17565138','17570890','17580232','17580848',
  '17581129','17581573','17587432','17588474','17588866','17594651','17597168','17600897','17604158','17609477',
  '17610720','17614894','17619612','17628741','17630396','17631956','17632175','17636562','17639988','17647147',
  '17651416','17663168','17664939','17672105','17673527','17679738','17680969','17683667','17688262','17690856',
  '17690886','17694403','17696307','17700436','17716702','17724346','17738479','17743700','17747704','17747958',
  '17753324','17756929','17761720','17765076','17769048','17770669','17772991','17776018','17776581','17780241',
  '17780577','17780992','17785292','17787920','17789339','17799005','17800649','17811700','17819734','17821026',
  '17824876','17825127','17828997','17834742','17845766','17851100','17854475','17866794','17867423','17874034',
  '17881437','17883595','17893783','17917123','17925734','17937389','17941876','17947292','17955637','17964450',
  '17964755','17974011','17977225','17989399','17993066','17994100','17997039','17997619','17997705','18002428',
  '18002583','18004592','18007420','18014735','18016894','18028528','18030632','18033132','18033479','18040164',
  '18044499','18047870','18054525','18057442','18061573','18067273','18080680','18081023','18086022','18088484',
  '18091533','18104425','18113348','18116654','18136902','18139557','18140611','18143669','18148656','18149308',
  '18153437','18153609','18154933','18163991','18168155','18171580','18171900','18186096','18197240','18198916',
  '18210938','18212148','18212198','18218047','18218481','18221112','18223905','18242232','18244573','18248837',
  '18249478','18258535','18259077','18263123','18267060','18279826','18279918','18283232','18283289','18283611',
  '18285496','18285843','18287641','18288939','18291803','18291861','18295168','18306815','18310378','18316977',
  '18321323','18323730','18324285','18326599','18327276','18329609','18334212','18336687','18338742','18350163',
  '18351836','18365382','18373788','18376597','18377590','18387704','18394666','18399084','18399973','18399986',
  '18401334','18404243','18408937','18416225','18416292','18418645','18426833','18439597','18447785','18447859',
  '18448068','18450821','18451948','18452597','18454635','18456598','18457292','18459795','18466425','18488973',
  '18491479','18493787','18500546','18504580','18505559','18515920','18518547','18529985','18534142','18545854',
  '18552839','18554781','18560415','18564703','18567810','18571590','18574381','18582103','18584414','18599335',
  '18601251','18603260','18619207','18622840','18623613','18626048','18627887','18630569','18636296','18637194',
  '18641836','18643766','18651756','18661017','18669520','18673239','18677638','18688538','18690736','18692742',
  '18709089','18717980','18731179','18739733','18750726','18753196','18756438','18757761','18759311','18760812',
  '18761032','18772422','18774134','18778610','18780150','18781105','18799430','18803303','18807904','18807979',
  '18811923','18812326','18814334','18816924','18819805','18827331','18829370','18830989','18838403','18842512',
  '18845622','18846807','18846988','18856150','18862591','18871667','18874784','18874820','18884115','18886790',
  '18892199','18894763','18898793','18899409','18902384','18909978','18912047','18915494','18919339','18919390',
  '18922428','18930197','18937120','18940585','18945577','18952345','18953770','18955896','18961700','18968857',
  '18969319','18975934','18978221','18984251','18987056','18998776','19002683','19008906','19012347','19021397',
  '19029502','19042786','19045156','19047808','19053143','19063782','19064416','19064770','19068823','19081960',
  '19088737','19094057','19102137','19112575','19113725','19118929','19130022','19141494','19142220','19147173',
  '19150032','19158927','19159994','19172221','19178943','19179129','19188353','19192105','19197956','19201835',
  '19211096','19213558','19229956','19231232','19235062','19237864','19238532','19245141','19248174','19248677',
  '19261097','19264199','19264495','19267305','19269567','19271868','19275361','19277074','19280200','19282345',
  '19282378','19290027','19295016','19304152','19313091','19313690','19314269','19314772','19322378','19340368',
  '19345508','19354017','19354854','19372032','19378554','19397747','19398694','19404444','19409173','19409333',
  '19417297','19420933','19423469','19439707','19453354','19458845','19461586','19468870','19478794','19483515',
  '19488724','19498778','19511128','19512174','19514691','19525118','19525551','19530965','19531587','19544938',
  '19545597','19553715','19560829','19580350','19581712','19582565','19597809','19602542','19604295','19605095',
  '19622420','19641615','19641974','19645372','19647955','19648386','19649409','19657041','19657412','19664412',
  '19665046','19667422','19668422','19673595','19675138','19677381','19687159','19688496','19696930','19724198',
  '19725451','19726480','19735667','19740838','19742564','19755151','19757294','19758182','19758255','19774723',
  '19779371','19785406','19790265','19792874','19797683','19802272','19809980','19811066','19822024','19829547',
  '19836920','19845297','19850868','19852534','19854408','19859114','19859882','19860046','19869968','19875852',
  '19877523','19894277','19895549','19899150','19907049','19907674','19912951','19913702','19932880','19933361',
  '19939348','19940980','19949498','19951164','19951171','19955426','19958232','19965105','19975691','19984017',
  '19987568','19993074','19995296','19997368','19998275','20001120','20007721','20014758','20027388','20030143',
  '20031781','20034033','20050987','20074045','20075667','20076761','20079723','20084339','20091700','20091943',
  '20098694','20105186','20111178','20114577','20117448','20129566','20129636','20148618','20153134','20156542',
  '20159382','20163409','20168670','20175096','20178275','20180456','20180898','20182415','20191865','20195088',
  '20206543','20211764','20214893','20215115','20215900','20225363','20233283','20235692','20238122','20243451',
  '20245822','20246755','20248656','20254267','20255984','20256296','20259748','20259898','20263764','20264397',
  '20273230','20293774','20296081','20296116','20298204','20306264','20306722','20315259','20323980','20337154',
  '20359913','20361025','20365201','20367821','20370722','20381946','20383802','20397516','20404157','20404169',
  '20405704','20405860','20414534','20426054','20441841','20442393','20460749','20462303','20473295','20477713',
  '20482312','20482759','20489705','20492976','20494978','20495205','20499618','20501800','20504428','20504679',
  '20505033','20541314','20542264','20547259','20551165','20554950','20555500','20558177','20567817','20569089',
  '20584852','20586522','20587441','20593564','20595207','20602092','20602992','20605917','20610202','20613239',
  '20621775','20622369','20625180','20636681','20637325','20637869','20639683','20651511','20651947','20652672',
  '20652904','20653956','20658441','20659969','20662488','20664821','20670449','20670961','20672197','20685125',
  '20690040','20700318','20701296','20709628','20711530','20713753','20724102','20727662','20736243','20743813',
  '20745428','20747375','20763606','20765567','20770262','20779429','20792748','20793269','20794477','20799854',
  '20803206','20803635','20809547','20814494','20815870','20821394','20823398','20831219','20834212','20834969',
  '20836620','20837625','20840844','20847314','20862783','20872780','20873861','20877354','20892480','20905245',
  '20911680','20916225','20927603','20927638','20929001','20937900','20938228','20938912','20947321','20948515',
  '20950035','20974116','20975181','20982212','20984974','20987721','20988526','20995340','21009811','21015730',
  '21018937','21025172','21030900','21031687','21033247','21058112','21065599','21085480','21094462','21095375',
  '21102106','21102150','21104020','21107954','21119652','21122830','21136822','21142302','21144874','21150758',
  '21150796','21155799','21162351','21169692','21171823','21174748','21186155','21208552','21215407','21224527',
  '21229252','21233410','21238922','21240005','21246707','21248910','21253922','21258295','21259490','21280175',
  '21289984','21308361','21308994','21311819','21313108','21316791','21317053','21319151','21319675','21331741',
  '21337915','21340274','21352872','21353052','21357581','21359366','21366619','21376242','21393237','21401542',
  '21403914','21409714','21414716','21417301','21417598','21421684','21423983','21424402','21430283','21432001',
  '21438595','21444222','21448598','21452400','21454786','21463821','21464832','21473096','21477163','21478674',
  '21483609','21487441','21495919','21497817','21500581','21503189','21507257','21510307','21512789','21513703',
  '21514572','21517698','21523179','21558807','21563802','21566722','21568748','21570920','21570999','21574425',
  '21588873','21589675','21592244','21592658','21597265','21605329','21611207','21612151','21614982','21615657',
  '21618229','21622520','21629186','21629942','21637727','21637896','21651684','21654792','21661279','21664674',
  '21679526','21681744','21689169','21691589','21698515','21709254','21713219','21714088','21714434','21719792',
  '21732529','21738175','21741986','21743205','21749243','21751766','21767374','21771986','21787932','21797283',
  '21801577','21802849','21807293','21809520','21810849','21811722','21820700','21826522','21847212','21854669',
  '21860670','21866105','21870496','21871586','21872445','21872654','21886478','21887403','21900226','21904024',
  '21917768','21919422','21921773','21927958','21935954','21938622','21938927','21943263','21944200','21953262',
  '21959798','21959887','21984041','22002989','22007567','22007980','22009862','22013441','22036851','22041276',
  '22043528','22053057','22063438','22067808','22071474','22079675','22080501','22083516','22087403','22089686',
  '22092240','22103729','22104309','22111943','22122408','22122425','22124157','22133808','22136345','22149877',
  '22150950','22153643','22154890','22155232','22156227','22157820','22158440','22169457','22169934','22173628',
  '22177729','22183417','22184561','22187439','22191490','22192865','22193440','22197533','22212227','22213101',
  '22224344','22233056','22237928','22254229','22258923','22262398','22286902','22287713','22289971','22293376',
  '22293491','22299586','22300990','22301812','22303198','22308514','22310315','22317814','22319955','22321622',
  '22323059','22324183','22326181','22332188','22333780','22340301','22344461','22347179','22347863','22353772',
  '22358333','22359380','22385054','22393059','22394448','22396327','22396530','22399255','22404598','22405301',
  '22412611','22416635','22416675','22419881','22427907','22430475','22432618','22443934','22454229','22455085',
  '22455374','22458664','22459006','22459146','22459176','22460081','22463879','22471180','22476068','22477156',
  '22478694','22479315','22481287','22491355','22510097','22517132','22526732','22529086','22544932','22553803',
  '22557816','22568907','22571575','22577800','22580908','22582893','22582987','22589405','22589964','22594872',
  '22605085','22606045','22606418','22612441','22616964','22622018','22622643','22628836','22631152','22638837',
  '22644255','22649640','22654608','22657718','22664675','22678199','22687796','22690556','22693576','22714980',
  '22716760','22717450','22736977','22737790','22738600','22738916','22740662','22771814','22772493','22784399',
  '22790082','22802387','22813666','22814755','22815355','22818668','22821862','22825496','22830408','22834599',
  '22837687','22838746','22844642','22844740','22855254','22857558','22861393','22862238','22864894','22866114',
  '22869428','22875723','22878830','22889713','22897644','22901900','22911093','22926143','22930348','22937136',
  '22938409','22938556','22950451','22957725','22957757','22960088','22961171','22961411','22961795','22972298',
  '22974528','22978389','22989197','22991805','22992243','22993327','22998301','23011690','23015925','23033338',
  '23040313','23045218','23059890','23066198','23072593','23077693','23078961','23079414','23080686','23085105',
  '23095198','23096817','23099055','23100398','23102472','23105854','23108484','23114287','23117111','23117518',
  '23122633','23125036','23127656','23132967','23157537','23168016','23174209','23177045','23178482','23181947',
  '23182918','23184171','23184638','23187218','23192602','23193293','23194530','23198519','23199346','23202725',
  '23209570','23211411','23216878','23226483','23230645','23236426','23241760','23246001','23247497','23248629',
  '23248668','23256817','23273624','23278742','23281529','23292214','23293540','23295779','23297370','23315467',
  '23319534','23325743','23331673','23335587','23349152','23350128','23352495','23352682','23358198','23358987',
  '23360539','23365537','23369289','23381246','23382962','23385951','23386416','23390706','23392959','23398919',
  '23402090','23403854','23405620','23411552','23414354','23417982','23432853','23434980','23440155','23456461',
  '23457250','23458420','23460732','23463346','23470307','23477926','23482225','23486860','23491544','23494781',
  '23500652','23503747','23505121','23506652','23508541','23509560','23511681','23512697','23513494','23519335',
  '23521907','23530309','23531214','23538180','23541147','23544580','23546055','23547476','23548262','23548405',
  '23550541','23550559','23556287','23564059','23566274','23569823','23572268','23572898','23583608','23584754',
  '23586528','23591861','23598056','23599819','23601634','23610050','23615407','23623667','23625262','23634448',
  '23636402','23643266','23649125','23655238','23655927','23668367','23672494','23672593','23677074','23681373',
  '23690615','23700846','23702670','23707955','23716154','23720380','23723569','23724947','23726660','23734218',
  '23747879','23752807','23753775','23764916','23769808','23797252','23798368','23801475','23803398','23803580',
  '23804215','23807690','23807802','23809743','23819921','23821184','23821805','23823075','23823127','23829143',
  '23832441','23836360','23843308','23846126','23846838','23848811','23851014','23853590','23854201','23858161',
  '23859202','23863664','23866434','23866701','23879772','23880045','23894710','23900521','23902401','23902414',
  '23903999','23907315','23909700','23912454','23917245','23919984','23922355','23925242','23932930','23932941',
  '23938100','23939350','23942308','23943517','23952581','23954873','23971619','23974563','23976001','23978578',
  '23988411','23996402','23998068','24000079','24004052','24006811','24009732','24011773','24011903','24012969',
  '24013154','24019401','24022155','24029386','24033079','24035662','24045563','24049424','24054503','24054934',
  '24061023','24061666','24065345','24067933','24081183','24085720','24093213','24097974','24107473','24114197',
  '24115297','24118748','24123436','24127530','24144858','24149819','24157032','24167012','24169298','24175021',
  '24178447','24181594','24193104','24194014','24200679','24206928','24208120','24210428','24216021','24216588',
  '24224807','24225091','24225633','24235077','24239134','24246868','24250179','24250689','24256005','24256195',
  '24270610','24284807','24300782','24308382','24310684','24310891','24322659','24329266','24331234','24335247',
  '24343429','24348410','24352136','24352563','24353626','24354596','24358162','24362801','24370220','24372915',
  '24376646','24377937','24378490','24385118','24386161','24387369','24393323','24421282','24425769','24430219',
  '24431204','24438975','24460292','24466557','24477579','24480129','24485460','24486238','24488277','24492340',
  '24494368','24513275','24514110','24517167','24528763','24530707','24535472','24535686','24543368','24550219',
  '24552477','24556877','24565374','24567843','24567915','24583373','24586377','24599031','24618632','24619059',
  '24625244','24625692','24626662','24627807','24628639','24639273','24641033','24641958','24650492','24657473',
  '24659144','24661626','24662361','24664339','24670485','24674280','24675013','24685239','24685688','24689031',
  '24693600','24697380','24701655','24713420','24717315','24717580','24718486','24721885','24728587','24730121',
  '24732332','24740084','24742810','24753977','24768737','24769806','24775168','24801831','24812238','24830755',
  '24839217','24848008','24849489','24852738','24857221','24859347','24861574','24862810','24875651','24878480',
  '24885027','24889170','24889933','24890419','24891344','24893616','24893712','24899171','24902288','24904373',
  '24921483','24923005','24931235','24934496','24941994','24946281','24946568','24957576','24965564','24966737',
  '24979225','24988239','24992135','24994422','25007921','25018145','25020908','25025514','25033563','25051471',
  '25060107','25060350','25072677','25077686','25078250','25078656','25085238','25090102','25091085','25092813',
  '25094905','25099819','25102108','25108396','25115014','25116448','25120141','25121603','25127404','25130122',
  '25131068','25134654','25136536','25149463','25157616','25159669','25168448','25178551','25180222','25182681',
  '25184623','25192354','25195693','25201581','25204254','25207764','25208611','25213878','25214599','25226330',
  '25227608','25231693','25236666','25242596','25245245','25250350','25251023','25258689','25262725','25264512',
  '25265499','25271892','25277767','25281681','25284247','25293983','25301469','25304860','25308623','25316783',
  '25322624','25326338','25329120','25332036','25336320','25353286','25362817','25363759','25376857','25382331',
  '25384281','25389912','25393562','25398355','25399951','25405656','25405951','25408682','25409986','25410263',
  '25417721','25418880','25424863','25429007','25432188','25439509','25443330','25448124','25449348','25451717',
  '25454941','25455929','25462964','25480589','25484358','25484875','25488016','25490528','25491527','25506032',
  '25507011','25508597','25517969','25529167','25532983','25540165','25541765','25544682','25564282','25575336',
  '25584496','25584726','25587154','25597933','25601356','25603187','25611154','25611429','25628501','25632886',
  '25637189','25652565','25656388','25657500','25657982','25661419','25670628','25674418','25683531','25683673',
  '25684343','25693714','25705464','25706101','25707989','25708205','25708459','25717902','25722159','25727026',
  '25730043','25730444','25742148','25750167','25753393','25756865','25760204','25773305','25777978','25790744',
  '25795948','25797058','25800707','25817401','25817945','25822192','25824230','25829999','25832298','25836192',
  '25842125','25842493','25842784','25857964','25859858','25861029','25863867','25868510','25875135','25876073',
  '25884930','25895304','25896231','25896896','25897661','25899857','25907464','25911755','25915557','25916440',
  '25922397','25924584','25930189','25941857','25947218','25970522','25979420','25979551','25980740','25982273',
  '25991630','25992223','25993136','26005746','26016295','26017347','26018590','26021965','26022697','26024674',
  '26025233','26034110','26040442','26053998','26054489','26077453','26092910','26093729','26102813','26105310',
  '26107679','26112174','26125359','26130144','26132823','26133204','26133476','26138627','26140459','26140725',
  '26150133','26152506','26157921','26165465','26173736','26175688','26176703','26182116','26188297','26198470',
  '26214649','26216154','26220182','26222696','26231298','26249915','26251109','26253443','26254891','26254971',
  '26262940','26277031','26281039','26290934','26295813','26302104','26304168','26306422','26307298','26308415',
  '26311074','26311413','26312460','26317679','26320927','26322990','26333005','26344526','26347122','26356026',
  '26359426','26359851','26368681','26375499','26385711','26389818','26390384','26394848','26396678','26396992',
  '26402326','26405670','26406250','26412734','26415332','26415880','26416975','26417228','26417879','26419634',
  '26422099','26427536','26429519','26430101','26433746','26435154','26439324','26443156','26459076','26462994',
  '26472587','26473067','26490640','26495251','26507504','26508788','26509665','26513271','26519319','26519592',
  '26521578','26525706','26527820','26534602','26534699','26540277','26545706','26550919','26555228','26555875',
  '26559360','26562510','26567754','26572233','26575488','26578957','26586346','26594791','26595349','26609297',
  '26611034','26615179','26622339','26627284','26639697','26645022','26666599','26667787','26669100','26671197',
  '26674231','26675956','26676104','26676970','26679504','26680372','26688827','26693227','26697825','26699236',
  '26707917','26712095','26712522','26720859','26723048','26728109','26735880','26744379','26746030','26751860',
  '26753682','26762458','26762977','26766927','26769093','26775876','26779322','26781511','26787629','26790908',
  '26796461','26799128','26800073','26801962','26805920','26808597','26821070','26821614','26828699','26840129',
  '26842778','26844852','26846347','26848642','26849634','26853942','26854988','26864849','26865647','26865797',
  '26872123','26873025','26875082','26886704','26894033','26903570','26920197','26927322','26931429','26934811',
  '26934835','26937510','26942269','26949802','26952691','26954931','26958911','26961911','26979811','26980915',
  '26982467','26988838','26991575','26994324','27000996','27006652','27010195','27017107','27017700','27020438',
  '27023113','27038345','27040208','27045834','27054711','27056009','27057961','27059460','27062562','27064732',
  '27090330','27096408','27104236','27106438','27109841','27124029','27130444','27142383','27142571','27145920',
  '27151043','27152087','27154666','27160107','27165336','27165720','27165857','27169902','27172656','27175128',
  '27175837','27183050','27183609','27191853','27192047','27193861','27199824','27202148','27209800','27211666',
  '27212164','27214154','27218065','27221077','27225028','27226773','27228568','27236778','27244476','27252555',
  '27257527','27259972','27263983','27267519','27269857','27273389','27281698','27287421','27292567','27293097',
  '27293119','27307952','27322120','27325175','27329140','27336733','27338786','27346014','27346449','27349521',
  '27352467','27352511','27353068','27354614','27363338','27364487','27364692','27365524','27369288','27377037',
  '27388315','27395567','27396850','27411722','27417911','27421801','27424701','27446106','27448894','27449481',
  '27459448','27476476','27478795','27481951','27490294','27493324','27502167','27502490','27503275','27510230',
  '27511661','27527434','27535127','27548781','27556029','27564991','27577592','27577988','27581629','27583393',
  '27591473','27596385','27600261','27602342','27603747','27604189','27606831','27613979','27616646','27617654',
  '27618348','27625373','27626437','27627038','27630564','27632315','27634914','27644862','27654106','27654520',
  '27660251','27661859','27663503','27673894','27674005','27681310','27685230','27690435','27690933','27692835',
  '27701426','27701485','27703295','27705586','27706810','27708557','27712103','27715662','27716201','27716364',
  '27721457','27731250','27731583','27732450','27736333','27741055','27742780','27756754','27757416','27760487',
  '27760650','27766030','27766088','27767968','27773725','27775868','27790316','27797076','27797418','27798076',
  '27800879','27802089','27803581','27809723','27810802','27815449','27819230','27830699','27836275','27841554',
  '27845179','27846310','27850601','27863655','27865731','27873945','27874504','27884293','27887142','27887983',
  '27889202','27894527','27898280','27913420','27926168','27927938','27933396','27934867','27936547','27936656',
  '27937339','27938637','27938889','27945530','27947435','27949652','27958535','27959507','27960866','27962077',
  '27966284','27968014','27969607','27971999','27982112','27986392','27993584','27994666','27995405','27997529',
  '27998959','28000863','28003798','28007649','28008717','28009094','28010061','28013718','28015212','28032067',
  '28034794','28043321','28046325','28048936','28049848','28056924','28060218','28061120','28063818','28064638',
  '28071350','28083188','28085037','28094477','28099033','28103895','28105156','28106963','28112490','28120629',
  '28122172','28128987','28129593','28130968','28136300','28137605','28139603','28146022','28146105','28146358',
  '28166614','28170042','28177647','28180383','28180770','28185886','28200968','28203348','28206937','28208628',
  '28212407','28216541','28217650','28218059','28223163','28223526','28224233','28230574','28230769','28243774',
  '28245516','28246589','28251202','28254901','28256245','28265959','28266022','28268232','28273137','28285615',
  '28289775','28302491','28303714','28309901','28316728','28320273','28325620','28339888','28351477','28359811',
  '28361132','28362333','28365844','28366413','28370280','28381882','28384338','28387718','28389939','28390455',
  '28397710','28404919','28412029','28412633','28414614','28414895','28416097','28417195','28418803','28423646',
  '28426105','28430413','28432881','28440046','28440982','28443824','28448193','28451296','28452636','28454945',
  '28459669','28466380','28466804','28470396','28479746','28485139','28491691','28493439','28494920','28505889',
  '28507496','28510058','28517126','28524940','28528724','28529364','28530706','28535499','28539607','28551513',
  '28553322','28560228','28562888','28563352','28571560','28574358','28595925','28603431','28613744','28624021',
  '28631577','28632880','28636710','28638332','28638394','28639554','28639814','28640242','28643190','28650539',
  '28651189','28656279','28657805','28658074','28662794','28666406','28671223','28672200','28682294','28686577',
  '28690599','28697174','28702599','28708444','28708806','28718878','28719189','28726899','28729801','28737040',
  '28751980','28759422','28760077','28767256','28774611','28779224','28779914','28780369','28787343','28789209',
  '28801295','28811203','28813052','28813311','28815924','28820285','28830059','28845636','28858053','28861303',
  '28861531','28864450','28868499','28884875','28885036','28894490','28896853','28912891','28927749','28936013',
  '28949997','28954453','28959182','28962236','28975478','28983439','28984096','28992755','28993251','29008530',
  '29010760','29017346','29030975','29032832','29033240','29040671','29042863','29043160','29045637','29048707',
  '29048914','29049189','29060463','29061575','29066693','29070661','29072726','29079351','29082550','29085327',
  '29092381','29099885','29102620','29103009','29107074','29107090','29110792','29111958','29118714','29119026',
  '29119993','29122005','29123582','29124177','29130906','29136658','29143476','29150893','29158555','29161952',
  '29164606','29171728','29179817','29184409','29191410','29194673','29198146','29203487','29210738','29214390',
  '29219479','29224774','29226409','29229249','29229353','29232297','29234767','29235658','29237307','29249243',
  '29249899','29256539','29259074','29260807','29260823','29263619','29272281','29276151','29280992','29281140',
  '29289062','29293557','29300826','29304798','29310925','29314065','29316994','29324382','29330863','29332106',
  '29339111','29342798','29348923','29368732','29374073','29376410','29379620','29386096','29394825','29400307',
  '29421875','29425046','29429039','29432148','29435842','29439845','29448635','29449165','29451595','29454902',
  '29457333','29470781','29485083','29492645','29496947','29499885','29500474','29502241','29509271','29512911',
  '29515359','29535639','29537979','29543532','29545266','29546404','29549367','29549688','29549825','29550727',
  '29551792','29557516','29563200','29566706','29572850','29573142','29575928','29578478','29581055','29583265',
  '29585894','29589857','29601081','29604173','29608303','29614271','29615035','29627507','29650717','29657304',
  '29660401','29661190','29666486','29666886','29668360','29670267','29682621','29692828','29694253','29704817',
  '29708438','29708828','29710469','29715763','29729091','29740442','29746719','29748663','29765612','29768190',
  '29772415','29773898','29778827','29789280','29799724','29804765','29806123','29806690','29807181','29807241',
  '29809206','29809314','29821100','29821375','29828302','29830590','29849448','29858092','29858398','29862237',
  '29862457','29865963','29869145','29871879','29883291','29885579','29885721','29892896','29896477','29903264',
  '29924441','29932796','29938386','29939364','29939741','29941591','29942394','29945963','29948743','29950097',
  '29951404','29951605','29961219','29964917','29966565','29967855','29979628','29981960','29983886','29984998',
  '29994817','29996916','29998278','30014947','30015059','30015275','30015392','30016073','30016615','30022671',
  '30026469','30026611','30027529','30028193','30034318','30042894','30044146','30048039','30050899','30053255',
  '30058884','30062482','30081858','30085516','30089526','30101884','30106744','30108981','30111454','30114183',
  '30114749','30122753','30124277','30125147','30132469','30134046','30134288','30134499','30135331','30158409',
  '30160227','30165004','30172253','30177598','30178747','30187028','30191346','30196749','30198252','30218736',
  '30224573','30227358','30233383','30234049','30234484','30238880','30240761','30240881','30244500','30245310',
  '30249258','30262750','30266945','30267011','30269271','30270280','30272844','30278698','30280971','30281256',
  '30293180','30298519','30299831','30300549','30301174','30303985','30308118','30313896','30315691','30320294',
  '30324202','30325723','30343010','30344556','30346329','30367706','30379568','30385086','30387230','30388455',
  '30396624','30398702','30401933','30405016','30413875','30426686','30427591','30440334','30446668','30448575',
  '30451499','30458450','30458738','30460666','30464280','30468257','30469182','30473764','30477111','30477914',
  '30478489','30481590','30482075','30500387','30516344','30519711','30523758','30530013','30531290','30532236',
  '30532941','30541843','30543703','30561900','30568268','30590607','30593299','30597570','30603831','30605482',
  '30605832','30608787','30620232','30626950','30638855','30643760','30655215','30655308','30656819','30656959',
  '30660681','30662903','30665409','30668788','30671435','30681101','30698208','30703402','30705770','30710641',
  '30713333','30713893','30714311','30714560','30716061','30718900','30719183','30730781','30737713','30739956',
  '30741132','30750887','30751871','30755627','30756141','30762446','30780990','30793050','30797095','30802193',
  '30803575','30804333','30804615','30806074','30814089','30824819','30828349','30829083','30835357','30844260',
  '30848363','30850425','30852702','30861511','30861524','30862297','30863594','30865449','30866709','30868535',
  '30878574','30878873','30879112','30879374','30884364','30889754','30892937','30906975','30913862','30921842',
  '30926610','30934817','30937587','30940454','30946196','30946571','30950645','30953720','30970438','30978120',
  '30986288','30990714','31002717','31003807','31018985','31019899','31024142','31034684','31044344','31046588',
  '31047682','31053235','31053333','31054044','31061137','31066870','31070738','31077190','31078893','31081939',
  '31082343','31082554','31083552','31083661','31085196','31094717','31097901','31099285','31113124','31118191',
  '31119038','31122364','31125360','31140332','31145160','31145202','31148610','31151111','31167773','31167775',
  '31167927','31173903','31174524','31177052','31178707','31178924','31184214','31187358','31196844','31196994',
  '31202513','31207771','31208836','31211701','31212847','31214041','31216073','31229323','31243861','31261192',
  '31262919','31268687','31282015','31287794','31289681','31300301','31301848','31305135','31308757','31309991',
  '31313731','31327076','31332809','31333514','31343127','31346809','31349730','31352028','31352762','31355006',
  '31370137','31373543','31382774','31387739','31389657','31389984','31393188','31399212','31403092','31404166',
  '31407229','31413281','31413291','31417492','31420137','31429768','31432846','31440894','31441241','31442054',
  '31446986','31451129','31454507','31454948','31457259','31474944','31477081','31484817','31489295','31490300',
  '31499554','31507493','31520347','31522016','31527091','31528748','31529995','31533492','31553189','31559056',
  '31568987','31569338','31571100','31578134','31582842','31586092','31588499','31590198','31610628','31613763',
  '31613975','31627161','31629280','31641449','31644398','31660302','31661201','31666117','31667680','31670646',
  '31671214','31674408','31692807','31703899','31714605','31716664','31717053','31717560','31725934','31726162',
  '31728898','31731975','31732327','31752521','31753159','31759037','31766842','31767937','31769172','31773192',
  '31773513','31776019','31778075','31780868','31783722','31784449','31794258','31794676','31802532','31803092',
  '31805899','31807604','31813585','31817684','31818802','31828877','31831317','31835590','31846364','31848346',
  '31849135','31858805','31858824','31865100','31867471','31872642','31873167','31875066','31879017','31879529',
  '31880137','31903632','31908811','31914478','31916044','31918457','31920412','31923761','31942681','31950979',
  '31955289','31956110','31956485','31958715','31966616','31968740','31971768','31982849','31984256','31984337',
  '31994772','31994988','31995301','31996953','31998107','31999593','31999752','32005523','32016286','32017882',
  '32032809','32046619','32052480','32056938','32058972','32060894','32062292','32071014','32074760','32075225',
  '32077060','32079958','32084605','32085085','32089709','32090428','32091215','32095528','32097786','32099232',
  '32104805','32107563','32116662','32123481','32124685','32138162','32154433','32160351','32161601','32167055',
  '32168860','32173227','32175268','32194167','32197226','32198657','32201625','32207291','32210004','32211397',
  '32214187','32215686','32219891','32220482','32221877','32224150','32224942','32227592','32231349','32235268',
  '32238240','32240988','32243916','32245200','32246515','32246741','32247962','32249564','32253800','32264223',
  '32276612','32280027','32283444','32287052','32288803','32288879','32292612','32295662','32297243','32305608',
  '32319726','32331965','32332266','32336370','32337082','32342021','32346171','32385682','32389235','32391174',
  '32398923','32402087','32410226','32413634','32416138','32424549','32428634','32438587','32439422','32447550',
  '32450842','32455952','32461410','32468390','32474305','32482224','32495672','32496905','32498521','32502383',
  '32505389','32507256','32507274','32508274','32513910','32516818','32525183','32540967','32549006','32554415',
  '32560079','32561525','32580563','32584365','32585345','32590744','32604165','32608669','32609842','32614670',
  '32634219','32639741','32651665','32653302','32662211','32666560','32673960','32684025','32685228','32686638',
  '32704077','32707663','32714530','32723838','32746651','32748579','32750314','32750707','32752584','32754046',
  '32756544','32756898','32759138','32768841','32779293','32786703','32795542','32795868','32805872','32809562',
  '32820071','32820400','32823825','32831116','32832006','32836654','32837105','32840878','32842362','32842953',
  '32844891','32849653','32850015','32850685','32866040','32872115','32884252','32890943','32894977','32896264',
  '32899347','32900708','32905746','32911693','32914928','32915577','32921925','32932163','32933384','32944945',
  '32945485','32951890','32952507','32956163','32960356','32969503','32969957','32978084','32978327','32989609',
  '32992996','32995241','33001210','33003417','33003492','33020773','33033621','33038461','33040339','33041110',
  '33050885','33066527','33066902','33067856','33071892','33078466','33098395','33109372','33116096','33122234',
  '33122687','33123118','33126537','33132317','33134834','33138242','33143023','33151200','33159654','33164264',
  '33170495','33172393','33175029','33175540','33177648','33179937','33182260','33182953','33191619','33205808',
  '33206373','33206595','33212383','33215231','33218096','33227863','33229856','33234430','33235235','33237671',
  '33238920','33240478','33243528','33250900','33256150','33278767','33283768','33287235','33288298','33289474',
  '33310755','33313653','33326173','33326607','33334457','33345669','33351819','33353599','33365318','33375930',
  '33382029','33386907','33390823','33392986','33394236','33401595','33410608','33417468','33424296','33427062',
  '33440957','33443627','33451269','33452009','33452077','33456765','33457994','33461282','33461877','33463082',
  '33469341','33487673','33488557','33521424','33521845','33526940','33537936','33539097','33546655','33551531',
  '33554039','33558662','33566034','33567076','33567252','33568698','33572976','33574753','33577457','33581850',
  '33584898','33592845','33598491','33605878','33607979','33608543','33615696','33622496','33624835','33626291',
  '33627553','33633185','33635820','33641172','33650461','33660752','33661087','33661538','33674472','33678258',
  '33682855','33683499','33693698','33697301','33702818','33709435','33718203','33726484','33747682','33749905',
  '33752173','33755907','33761335','33762910','33764251','33766127','33776649','33784049','33785270','33787928',
  '33787958','33794281','33795587','33797064','33797697','33804320','33816843','33833969','33841618','33854428',
  '33855149','33855178','33864738','33867266','33869398','33871814','33872176','33878027','33879704','33887115',
  '33893427','33894871','33897822','33898900','33899070','33902394','33918641','33924066','33930889','33932492',
  '33939071','33951279','33954531','33955375','33958431','33959539','33963913','33971203','33975081','33975836',
  '33976561','33982965','33985200','33989036','33989452','33995001','33997440','34000443','34007110','34007835',
  '34012872','34014490','34014904','34023318','34041999','34044019','34047500','34055570','34062226','34066330',
  '34078068','34085567','34093208','34100115','34104207','34110221','34112635','34113064','34120906','34123727',
  '34139089','34139694','34141781','34142248','34142349','34142822','34148385','34153431','34154449','34161932',
  '34165310','34166692','34170211','34171706','34172931','34184850','34187117','34188506','34190955','34191145',
  '34192264','34194208','34194281','34195816','34199411','34208968','34210955','34215715','34218593','34219507',
  '34221047','34238489','34240080','34243085','34243361','34247408','34250254','34263540','34267079','34273591',
  '34275010','34279293','34288076','34301115','34303458','34304677','34307334','34311065','34312547','34316597',
  '34322829','34326564','34328502','34330487','34332699','34336950','34346269','34350425','34351694','34351772',
  '34357514','34359578','34360415','34363112','34363786','34370593','34375693','34384677','34386068','34390447',
  '34391474','34394193','34397337','34399413','34404076','34406861','34408956','34418615','34418699','34426870',
  '34427975','34428730','34429302','34437945','34441171','34448068','34454208','34456679','34457951','34461512',
  '34468667','34471368','34471393','34483377','34488883','34488886','34498186','34502463','34509260','34509779',
  '34519756','34527239','34530027','34532116','34543253','34548784','34549714','34553660','34558844','34569815',
  '34602089','34604979','34606072','34616175','34618220','34621834','34634418','34636963','34638037','34641807',
  '34642852','34646118','34647732','34657627','34673642','34675814','34676820','34678322','34697746','34700796',
  '34706993','34710326','34712333','34712526','34720085','34721217','34721462','34724837','34742715','34744264',
  '34745604','34757426','34758651','34765078','34769794','34770199','34774311','34777306','34777399','34780644',
  '34784471','34786753','34792682','34792918','34795034','34797506','34798423','34801822','34804467','34826713',
  '34834786','34837137','34839216','34841917','34844293','34844768','34845474','34847456','34847798','34849841',
  '34857023','34859117','34870562','34872601','34875110','34880347','34886247','34886708','34894193','34898195',
  '34905279','34923325','34923855','34929587','34929649','34945070','34947638','34950259','34957193','34963198',
  '34964129','34965494','34970138','34978048','34980088','34980727','34982906','34989235','34989670','34997661',
  '35009418','35014455','35015061','35024500','35024836','35034282','35036887','35042635','35042740','35048114',
  '35051254','35054373','35057774','35064223','35069719','35072403','35079973','35080739','35083891','35089823',
  '35092652','35094479','35098056','35101581','35104877','35106714','35113601','35119638','35124478','35130044',
  '35130983','35132278','35136953','35138021','35139284','35139506','35140661','35148744','35153225','35155426',
  '35166471','35167401','35172931','35173598','35182093','35189848','35194452','35198273','35205657','35206504',
  '35234635','35234957','35235665','35244211','35252698','35253812','35257614','35262921','35267329','35267353',
  '35272207','35277843','35289530','35291675','35300305','35302885','35304714','35313051','35314493','35320347',
  '35322508','35323250','35324534','35329124','35330587','35330613','35334509','35336910','35337618','35338331',
  '35342868','35343778','35344814','35346733','35351094','35355340','35358050','35358467','35358987','35360878',
  '35365292','35365620','35365899','35366870','35374032','35375662','35383835','35388543','35388680','35388770',
  '35392623','35393185','35397221','35401847','35411326','35434344','35442702','35459773','35459924','35469734',
  '35470230','35478189','35492537','35496964','35500090','35500435','35512604','35518265','35526255','35530153',
  '35543046','35549444','35553715','35561047','35569098','35585697','35585961','35586829','35587178','35590794',
  '35595210','35601945','35602911','35604333','35605125','35613434','35613681','35624481','35625573','35626976',
  '35639457','35639670','35646661','35650948','35655776','35657581','35664659','35668994','35680535','35684362',
  '35700250','35707421','35713808','35718114','35720520','35724601','35725031','35725523','35727777','35736068',
  '35744444','35747263','35747688','35749900','35757525','35768610','35773317','35784639','35804793','35806915',
  '35819173','35831490','35833239','35845589','35846562','35846705','35847057','35851774','35855171','35857844',
  '35874573','35882732','35886437','35888104','35894930','35896885','35904385','35904826','35905440','35907137',
  '35909094','35915861','35919508','35924853','35925168','35935631','35936066','35968031','35973523','35974186',
  '35980573','35983112','35984456','35984695','35986376','35991829','35992078','35992703','35996052','35997045',
  '36006887','36019916','36027131','36028333','36037091','36037734','36044113','36049023','36058644','36076283',
  '36078730','36084171','36086575','36086707','36102465','36108259','36116868','36117854','36120519','36123279',
  '36126178','36138198','36142462','36142931','36146663','36171338','36177780','36185621','36192895','36198435',
  '36204203','36207517','36223110','36223955','36229197','36229450','36234904','36236456','36239281','36260183',
  '36265371','36265787','36288926','36298201','36304315','36312690','36313425','36342650','36372906','36375927',
  '36378469','36387606','36391796','36405477','36414112','36418404','36419879','36425517','36427111','36437516',
  '36443311','36462498','36477740','36489624','36493134','36500570','36505441','36507082','36509793','36522385',
  '36535815','36546100','36547946','36549772','36550959','36551112','36553038','36557768','36572221','36574412',
  '36577244','36579027','36586489','36595095','36600906','36601811','36602746','36604717','36610340','36619184',
  '36628911','36631525','36634487','36639834','36640216','36644839','36648569','36653561','36660605','36664252',
  '36664509','36671160','36673733','36679298','36686193','36687969','36693164','36704213','36704460','36705916',
  '36728394','36729033','36731190','36744386','36747401','36761025','36767883','36772142','36777463','36779006',
  '36782566','36784328','36785184','36790814','36792426','36804707','36809603','36812110','36816396','36816476',
  '36819953','36822951','36828339','36837680','36839233','36847557','36850817','36853581','36857486','36862390',
  '36864171','36865067','36866530','36868892','36879567','36879844','36884393','36894957','36898103','36904047',
  '36909330','36909964','36912453','36914542','36914639','36915609','36922837','36936781','36937932','36938832',
  '36951890','36955454','36964076','36967797','36969360','36975861','36981224','36984748','36986972','37000412',
  '37001901','37003867','37011954','37011963','37013583','37024685','37027915','37035296','37038751','37044078',
  '37044751','37044945','37051983','37056962','37067311','37085136','37096082','37096448','37106987','37108656',
  '37125395','37126456','37139163','37140248','37142051','37144241','37151188','37168230','37170234','37174307',
  '37174416','37184397','37187473','37193018','37201322','37201866','37204661','37208422','37210870','37211412',
  '37213365','37225101','37232855','37234557','37238290','37242231','37255513','37255986','37257731','37263648',
  '37263771','37264504','37265115','37265143','37266040','37266957','37270574','37271075','37272348','37273219',
  '37284468','37286783','37290002','37299371','37315832','37320736','37321229','37322402','37325235','37329183',
  '37346180','37349408','37350238','37353345','37354200','37359048','37366088','37370819','37372132','37376842',
  '37387319','37392991','37394236','37399599','37405400','37409273','37412947','37413400','37413673','37420717',
  '37423803','37440486','37442198','37442729','37463451','37464994','37465566','37476784','37488637','37491022',
  '37495626','37499973','37507809','37512696','37521262','37529354','37544016','37555872','37560143','37561262',
  '37563398','37564253','37564590','37568772','37572256','37575824','37580435','37580793','37583746','37584323',
  '37591985','37593453','37599059','37600189','37606592','37620346','37622877','37623659','37624587','37638904',
  '37639241','37644399','37650691','37659981','37662575','37680261','37686057','37686504','37687676','37687678',
  '37697754','37705230','37711665','37718461','37720479','37726785','37729944','37736385','37740325','37742180',
  '37743809','37747197','37756761','37766692','37778871','37779055','37779924','37785391','37787940','37788109',
  '37795954','37804388','37816194','37816814','37837503','37839211','37840769','37843494','37845130','37845293',
  '37869606','37869981','37878780','37894670','37897483','37898387','37901439','37917994','37924386','37924810',
  '37925960','37926225','37928959','37929324','37941118','37942715','37952724','37957382','37972036','37972277',
  '37973220','37975549','37977385','37980306','37992443','38002087','38003750','38014128','38017329','38023352',
  '38040747','38042791','38048957','38062710','38064323','38064696','38077092','38081680','38101479','38108659',
  '38113605','38118254','38121577','38128649','38130131','38134984','38142962','38145046','38147329','38154049',
  '38166192','38168104','38171473','38183442','38186023','38193600','38195885','38216944','38221305','38222953',
  '38224219','38243906','38248271','38248457','38267019','38274637','38281480','38282228','38282548','38285867',
  '38286183','38286768','38294383','38296281','38305436','38310944','38311487','38313650','38317125','38328476',
  '38331267','38338234','38338738','38345237','38348722','38352181','38365018','38375844','38381476','38382359',
  '38382465','38383009','38385451','38392087','38408020','38410389','38415627','38422170','38424277','38424425',
  '38424905','38425803','38427818','38432563','38434585','38435751','38438552','38446688','38448268','38449766',
  '38450969','38453639','38465216','38466932','38480987','38488373','38505077','38505682','38509933','38523236',
  '38523814','38523856','38524144','38535637','38538861','38539519','38541757','38543499','38546842','38550453',
  '38550596','38572544','38575123','38576753','38589372','38591913','38594292','38594614','38595548','38603609',
  '38607907','38610538','38614841','38619019','38623939','38631208','38634091','38635979','38640807','38644430',
  '38645979','38649064','38649950','38654021','38657427','38661595','38662769','38666344','38673966','38675284',
  '38679228','38681805','38685383','38686774','38697172','38698539','38699223','38704044','38707280','38710848',
  '38713008','38718799','38720997','38722181','38722472','38724033','38724954','38734280','38734469','38739830',
  '38741341','38758136','38763554','38766755','38771112','38777623','38782589','38784222','38794993','38797642',
  '38803217','38804590','38814121','38816041','38817431','38821070','38829891','38839992','38849336','38850052',
  '38851458','38856534','38857851','38861755','38864343','38870531','38874745','38877290','38882940','38883159',
  '38889194','38904500','38912146','38920670','38940381','38943856','38963405','38964880','38976684','38987294',
  '38992172','38999738','39000829','39003035','39011175','39011839','39013956','39015978','39017306','39018700',
  '39022455','39025053','39028248','39034529','39043406','39048732','39049006','39057213','39062124','39075286',
  '39078057','39083648','39084198','39084914','39087937','39089794','39098305','39101177','39101774','39106705',
  '39111140','39111278','39113149','39119906','39122758','39123862','39128156','39128302','39131914','39133804',
  '39133974','39138896','39139180','39147094','39157840','39163590','39167725','39168238','39177990','39181289',
  '39191782','39196576','39197231','39197929','39204535','39205218','39208185','39209040','39209994','39210980',
  '39212799','39212863','39225128','39226787','39228200','39228809','39228918','39229035','39239933','39244839',
  '39256556','39264941','39271454','39272795','39283432','39283553','39289935','39295211','39295593','39298924',
  '39300448','39300793','39309657','39311616','39319819','39320673','39324713','39331233','39333743','39342311',
  '39343499','39343960','39345760','39363852','39371217','39373760','39379237','39385541','39387844','39400464',
  '39416425','39423547','39430121','39437642','39439723','39461426','39463859','39485404','39489479','39490632',
  '39491113','39491700','39495378','39507437','39509532','39516103','39517040','39519699','39538550','39540138',
  '39552133','39560828','39562450','39563589','39565734','39566664','39574618','39575929','39580209','39580760',
  '39582237','39584056','39586891','39591106','39594769','39606661','39610857','39612106','39614351','39615085',
  '39626969','39627996','39630928','39633523','39638308','39641574','39652664','39656949','39659791','39666607',
  '39676929','39677701','39679688','39681190','39684482','39703877','39706116','39710721','39722786','39722915',
  '39726461','39728978','39730596','39731849','39733025','39736784','39746354','39769273','39769732','39770995',
  '39777048','39783057','39788032','39792571','39799082','39801652','39811772','39818230','39819689','39825321',
  '39825515','39829387','39830180','39830607','39833510','39835385','39836666','39836777','39838935','39838997',
  '39839569','39855816','39861934','39870122','39871765','39873018','39895130','39895968','39903441','39906354',
  '39919458','39919979','39920001','39922229','39926197','39934514','39938813','39941679','39944617','39944818',
  '39945537','39946620','39949036','39967405','39969114','39980319','39981365','39985445','39985525','39991505',
  '40001632','40008836','40020671','40026677','40030444','40030863','40031455','40036787','40043295','40047230',
  '40061211','40064593','40078882','40079834','40083476','40085885','40088632','40091468','40092604','40104288',
  '40108778','40110393','40114212','40115549','40118617','40119100','40119292','40124108','40128183','40132488',
  '40139326','40144512','40149853','40152138','40163036','40167717','40171881','40189071','40190525','40190808',
  '40198206','40202518','40205926','40220134','40226629','40239290','40266193','40276309','40292136','40294006',
  '40327223','40332507','40333387','40333414','40336719','40341522','40341887','40342109','40343599','40343819',
  '40352317','40355867','40362038','40370470','40383453','40389661','40389999','40393205','40395572','40396981',
  '40397269','40397568','40401063','40405511','40411785','40415257','40418362','40422577','40424065','40431240',
  '40434767','40449066','40453274','40475718','40482767','40484524','40488448','40490072','40495533','40498740',
  '40506476','40512272','40520296','40522830','40530765','40531502','40545059','40550696','40553052','40558907',
  '40561044','40562138','40565530','40568107','40571956','40574898','40579474','40583833','40594302','40601940',
  '40610256','40610382','40611586','40613008','40618667','40620051','40622230','40623683','40630587','40632466',
  '40633268','40640044','40642841','40652560','40659623','40664320','40673279','40677007','40680592','40682342',
  '40683693','40687820','40690403','40697449','40698532','40698544','40706548','40711320','40716771','40721768',
  '40722795','40724989','40726761','40731542','40741836','40741971','40742208','40748189','40753471','40754263',
  '40771946','40785226','40787106','40792526','40797574','40802852','40805601','40808283','40812557','40829835',
  '40832682','40835032','40838653','40839939','40856254','40861000','40865350','40868880','40872439','40873004',
  '40875294','40889072','40898133','40899940','40907136','40909496','40909531','40911242','40912900','40921372',
  '40927267','40935051','40958116','40968820','40973484','40996423','40999340','40999765','41010980','41011171',
  '41014155','41014658','41017115','41017268','41018674','41028453','41039002','41042971','41046106','41051774',
  '41052887','41074306','41074613','41075970','41083629','41088181','41100039','41110791','41114700','41116062',
  '41117814','41125495','41128454','41139022','41146904','41149598','41157052','41161430','41161954','41162256',
  '41163569','41163865','41166067','41170042','41170774','41178101','41185673','41201948','41210128','41212481',
  '41213305','41227951','41240746','41241195','41241260','41242558','41245175','41247971','41253175','41260655',
  '41264809','41288889','41289521','41289821','41297273','41304767','41305474','41307358','41315710','41321400',
  '41321410','41324026','41326498','41337465','41338634','41352972','41365124','41369554','41369744','41371710',
  '41374814','41381529','41386022','41386042','41387720','41388331','41408497','41422054','41426934','41427379',
  '41430200','41432714','41433263','41436186','41438451','41441650','41441831','41442633','41451261','41451640',
  '41454020','41458167','41461363','41461860','41463374','41468156','41475448','41478382','41488150','41488491',
  '41491443','41498172','41500553','41501038','41506773','41508615','41511414','41517728','41520260','41521511',
  '41526971','41531935','41535042','41549704','41559547','41569988','41570120','41571850','41576008','41580999',
  '41589461','41596091','41598616','41599010','41617672','41623917','41648868','41653798','41654204','41655550',
  '41662700','41673476','41674025','41684784','41687037','41690257','41695642','41696470','41710748','41711917',
  '41716687','41718545','41732960','41734215','41735766','41737147','41742361','41743977','41748162','41753174',
  '41759508','41763052','41767109','41773971','41776452','41779258','41785527','41786524','41800767','41803223',
  '41805420','41814222','41817889','41819985','41828552','41838086','41839091','41840625','41857057','41863456',
  '41872681','41873037','41878367','41879708','41885976','41897174','41898928','41909622','41919718','41920218',
  '41928210','41934706','41954295','41954678','41955093','41956636','41965504','41966220','41967601','41967732',
  '41968829','41971821','41977584','41982452','41989142','41990023','41992493','41996440','42000682','42000970',
  '42007533','42007543','42012348','42015861','42016053','42020363','42021218','42022227','42040442','42045631',
  '42046546','42047186','42063103','42067618','42072096','42079244','42080898','42086238','42090825','42102159',
  '42106996','42107684','42108264','42125671','42126080','42132425','42133470','42139087','42139096','42140759',
  '42141859','42154135','42156300','42166102','42180474','42183281','42197369','42198614','42201101','42202305',
  '42203068','42217384','42220113','42223539','42227634','42236628','42239104','42239697','42240305','42252998',
  '42253778','42258652','42262520','42269282','42283274','42284885','42294765','42296170','42296171','42302174',
  '42304951','42306540','42311749','42315683','42323855','42325098','42330380','42336470','42339518','42339601',
  '42361794','42368230','42368368','42369105','42371471','42372918','42379200','42379280','42381086','42381541',
  '42383265','42392203','42392522','42398809','42399552','42403159','42404780','42405061','42410063','42420461',
  '42422331','42423049','42446297','42446416','42449337','42450277','42467722','42468621','42471969','42477140',
  '42479149','42481080','42482877','42490203','42503024','42503434','42510635','42513900','42518483','42526166',
  '42536792','42540086','42540225','42542970','42543548','42551272','42565776','42582725','42583960','42584498',
  '42585102','42585447','42590072','42603380','42603797','42605646','42608100','42608561','42620668','42621456',
  '42621677','42628984','42633179','42634725','42634866','42636769','42641542','42642202','42646144','42653466',
  '42657126','42660107','42661824','42665314','42667177','42668929','42672258','42677487','42678126','42682161',
  '42698929','42700556','42704612','42705035','42715115','42716947','42724301','42731022','42741548','42746823',
  '42749273','42757509','42759921','42766500','42767501','42769092','42769315','42769530','42770712','42777474',
  '42778948','42781936','42790179','42791903','42792646','42795745','42796805','42801450','42801914','42802002',
  '42805351','42812930','42814990','42821704','42828735','42830840','42842457','42844405','42849998','42853949',
  '42856567','42870668','42871540','42873327','42885916','42886611','42894661','42901103','42902051','42902340',
  '42904644','42926331','42927531','42941689','42943036','42948326','42951043','42959066','42959397','42963035',
  '42976552','42977974','42984276','42989204','42997812','43000235','43004548','43006575','43008563','43008734',
  '43009133','43017474','43020742','43022166','43039825','43047583','43048579','43050202','43069961','43080541',
  '43081214','43081474','43095151','43107826','43125623','43129515','43139337','43144299','43151197','43152849',
  '43153814','43153974','43155491','43157718','43158626','43167267','43174058','43175662','43182179','43183307',
  '43185817','43185850','43192721','43198150','43202383','43210615','43212229','43215701','43218575','43235864',
  '43242496','43244024','43250765','43250855','43260752','43276728','43277273','43284257','43284324','43292306',
  '43293345','43300477','43302463','43309064','43322780','43323296','43323829','43328050','43329037','43330687',
  '43333778','43340229','43348060','43365981','43371191','43372567','43380025','43386044','43399868','43406440',
  '43409762','43411863','43421325','43424617','43429452','43433902','43437070','43443473','43444394','43453478',
  '43458223','43458751','43464472','43464732','43483189','43484010','43486023','43491972','43492299','43492845',
  '43496903','43497714','43503477','43509342','43529966','43534845','43540765','43544287','43548077','43549173',
  '43552643','43556349','43562344','43563450','43566125','43567725','43569497','43575479','43576977','43590124',
  '43595552','43596680','43599410','43614551','43616192','43617032','43627381','43628193','43630085','43637888',
  '43644409','43644464','43648934','43649213','43649762','43662080','43663251','43673731','43674009','43677417',
  '43680084','43680211','43696063','43707083','43707626','43708588','43709302','43712201','43713002','43722352',
  '43724303','43726365','43727162','43727328','43727793','43741719','43748015','43755065','43755568','43763614',
  '43765530','43771755','43779280','43779722','43783580','43804937','43810671','43812664','43814696','43817275',
  '43819704','43834278','43839383','43840929','43845026','43850106','43853280','43854098','43856360','43861371',
  '43869907','43873028','43882896','43892249','43897147','43906149','43922310','43926722','43929035','43929336',
  '43929550','43930561','43932035','43934351','43935787','43947522','43951523','43960994','43972456','43974098',
  '43975507','43976818','43988419','43993053','43998780','43999923','44010716','44012392','44012628','44016961',
  '44018954','44032883','44050073','44051241','44051587','44066693','44072517','44080819','44086072','44087968',
  '44088633','44090765','44095685','44097943','44100904','44101697','44102390','44107565','44107962','44119445',
  '44121833','44131943','44146905','44148683','44152318','44157249','44158274','44159004','44160004','44162909',
  '44165645','44168257','44169372','44201318','44202761','44205161','44206135','44211493','44227124','44236835',
  '44239764','44253963','44255456','44263237','44266774','44270358','44270646','44276461','44276966','44280691',
  '44288522','44290049','44303328','44305415','44310786','44313831','44315827','44320094','44338251','44349160',
  '44350857','44354408','44356858','44365857','44366211','44367561','44373062','44382388','44388864','44392768',
  '44395798','44397299','44413232','44423457','44429958','44439100','44442583','44450506','44450967','44458416',
  '44462561','44464300','44479359','44481899','44482896','44486389','44491065','44494199','44500072','44502210',
  '44510765','44521488','44528002','44534278','44536547','44537710','44539410','44551255','44551724','44563496',
  '44587116','44593597','44596192','44605095','44608749','44613127','44619760','44628108','44641393','44646352',
  '44647511','44659334','44663132','44668357','44668543','44677846','44692021','44696196','44697593','44697667',
  '44721052','44721729','44725030','44726123','44727154','44728251','44730794','44737533','44742256','44747818',
  '44750008','44765369','44765929','44768754','44771526','44772139','44774854','44776109','44779165','44779405',
  '44783927','44785684','44785825','44790485','44799288','44802361','44804447','44806103','44829188','44855050',
  '44866185','44867430','44868135','44870668','44876291','44880308','44881306','44891179','44900676','44907762',
  '44908279','44909759','44910420','44920561','44922953','44925744','44930634','44931429','44946089','44956748',
  '44957025','44960548','44962866','44963301','44964849','44969757','44974480','44979895','44981415','44981757',
  '44986016','44991861','44992837','44993389','44994303','45004643','45018104','45020213','45020618','45038586',
  '45043985','45049562','45066268','45079831','45081458','45082782','45089509','45096611','45097353','45099234',
  '45100309','45100918','45101997','45105988','45109022','45122260','45122784','45124141','45139817','45141804',
  '45146946','45158685','45159384','45161333','45165596','45170104','45170944','45172081','45172623','45176516',
  '45177365','45184465','45189396','45192590','45193075','45195515','45198653','45205336','45209780','45211719',
  '45215063','45216633','45221471','45221971','45222574','45224771','45228336','45232619','45242948','45244623',
  '45252523','45254817','45255775','45259333','45270349','45272054','45292998','45293634','45299329','45299837',
  '45300780','45311572','45314488','45322653','45331375','45335043','45335187','45338749','45351957','45363172',
  '45367829','45369095','45370660','45373561','45380562','45388611','45389361','45395171','45395216','45399447',
  '45404611','45409380','45410211','45414886','45421648','45423852','45432607','45446569','45452847','45464978',
  '45469188','45472354','45474218','45479177','45488434','45489745','45494273','45514628','45515238','45521721',
  '45526710','45537145','45538145','45558913','45575669','45581604','45599245','45599315','45605392','45608623',
  '45613155','45614147','45618912','45619006','45622173','45624940','45626399','45630024','45630195','45631500',
  '45633151','45636250','45648617','45649947','45659149','45691593','45695073','45696279','45703395','45714809',
  '45718223','45719572','45735255','45738450','45739230','45740684','45747208','45759097','45773271','45775984',
  '45779577','45782728','45786594','45787613','45794688','45804596','45820571','45823500','45825268','45834176',
  '45837608','45843871','45847925','45852677','45873171','45881298','45886077','45888988','45893579','45896106',
  '45898934','45904294','45907424','45919642','45926507','45935914','45950606','45970749','45974655','45975456',
  '45976561','45980464','45982982','45988621','45994642','45996483','45997612','46009731','46011039','46013020',
  '46013911','46014115','46014861','46018032','46020933','46022580','46023477','46036362','46046795','46056913',
  '46067919','46073170','46078022','46082808','46090564','46104530','46115382','46116129','46118001','46120919',
  '46135654','46139583','46139871','46165074','46174194','46175519','46185620','46199981','46202870','46203455',
  '46221552','46224444','46235040','46238811','46239320','46239897','46253041','46257834','46258363','46262473',
  '46267101','46267190','46270960','46273222','46286603','46311558','46320165','46321244','46324540','46325320',
  '46328321','46340201','46344483','46354833','46355082','46360127','46364773','46365406','46368643','46385184',
  '46388113','46390578','46395514','46397351','46399685','46403924','46408698','46414642','46438682','46440912',
  '46441962','46442051','46444116','46446463','46447878','46450303','46454461','46455123','46460932','46465832',
  '46469802','46473196','46479418','46479905','46498328','46501202','46502425','46502698','46517298','46517606',
  '46524682','46531030','46531915','46532231','46538650','46543114','46550814','46558600','46564024','46573537',
  '46581670','46582844','46584212','46586786','46588816','46592360','46596149','46602783','46605533','46607611',
  '46608536','46615882','46617577','46619069','46623243','46624673','46628683','46631030','46634440','46640029',
  '46644886','46648142','46659704','46666439','46669169','46669853','46670702','46671276','46683019','46688602',
  '46690732','46698237','46700288','46705349','46716855','46720506','46722396','46734003','46735328','46739517',
  '46749342','46754920','46759342','46763484','46770951','46780118','46785843','46790983','46794823','46795479',
  '46796642','46806684','46813438','46816578','46835932','46837805','46844656','46847230','46847498','46853015',
  '46859074','46859977','46861185','46867479','46873621','46882663','46892546','46897548','46901494','46901529',
  '46901782','46902509','46903890','46905050','46918557','46930375','46935634','46945761','46950191','46956660',
  '46956769','46961836','46963372','46963708','46965504','46967812','46986921','46987358','46987994','46990915',
  '46993553','46993836','46995388','46995467','46999156','47001967','47002965','47003060','47003108','47010070',
  '47011928','47012020','47014860','47021814','47026970','47028064','47037852','47049818','47050177','47051631',
  '47052624','47054496','47062358','47063531','47068323','47069351','47070755','47080135','47080464','47096235',
  '47099584','47103940','47108264','47108808','47112722','47117350','47121876','47123256','47132852','47138193',
  '47147511','47154585','47155281','47173545','47175514','47175796','47191641','47193425','47194572','47199958',
  '47203407','47210510','47214915','47222029','47223439','47236053','47239187','47240103','47255252','47256326',
  '47257676','47259406','47265914','47266729','47278070','47280946','47282257','47288456','47292228','47292790',
  '47295463','47310795','47313368','47320223','47320961','47326732','47329215','47333452','47341261','47346457',
  '47347933','47356585','47359445','47362833','47365100','47365735','47368992','47375901','47388445','47394263',
  '47401654','47415931','47427701','47434337','47435193','47436739','47457568','47458870','47461343','47463780',
  '47464048','47464574','47473016','47482226','47486130','47489872','47493061','47504116','47515097','47515815',
  '47521713','47523690','47524778','47532318','47539139','47542012','47542635','47544401','47558647','47561617',
  '47563407','47572650','47582416','47583616','47586583','47605173','47607234','47610657','47610990','47618435',
  '47623121','47623622','47623911','47634205','47634451','47636309','47638084','47649256','47654627','47654650',
  '47656284','47656648','47657301','47661968','47676852','47680965','47691938','47694252','47698991','47704283',
  '47708394','47719532','47721391','47727249','47735869','47748390','47752254','47767640','47781453','47782537',
  '47783170','47783286','47787549','47788375','47790141','47791189','47796399','47799024','47803404','47804202',
  '47806331','47808396','47811009','47820341','47820371','47823961','47824394','47825487','47829478','47854225',
  '47855104','47860117','47860721','47876471','47879730','47882019','47883147','47889474','47896684','47898836',
  '47907268','47909530','47913506','47915194','47925657','47927981','47933054','47936392','47944681','47947786',
  '47952270','47957884','47958171','47958568','47958845','47960191','47975337','47985135','47988585','48003527',
  '48004905','48008505','48012260','48014887','48027959','48028191','48033722','48039346','48047573','48054673',
  '48070333','48072634','48072826','48080001','48080730','48081469','48085849','48087803','48100034','48106598',
  '48108797','48112252','48116562','48122127','48124559','48129186','48133409','48137415','48143116','48143799',
  '48149250','48149857','48151811','48154520','48160581','48163474','48165030','48167475','48169394','48172481',
  '48172598','48173174','48186496','48194032','48197082','48197849','48200431','48205465','48207233','48210175',
  '48212243','48212968','48218761','48225381','48227961','48233653','48242212','48244926','48246768','48252019',
  '48258005','48260542','48262959','48263844','48266455','48269336','48273897','48278274','48281140','48284588',
  '48293089','48298886','48312103','48313202','48323461','48328241','48342410','48356239','48356332','48360651',
  '48366424','48377644','48393018','48411269','48413682','48419229','48421263','48422758','48424157','48424612',
  '48424789','48430699','48431294','48454261','48458038','48461724','48463337','48466514','48466670','48468651',
  '48475947','48476796','48480886','48485074','48490137','48494203','48506886','48515175','48517957','48521221',
  '48524783','48538346','48544688','48545249','48563815','48565112','48565245','48567043','48568575','48568680',
  '48576900','48582409','48587398','48591050','48596995','48602396','48605465','48605546','48612845','48613829',
  '48615702','48616403','48617977','48618942','48622804','48630566','48630676','48640759','48641963','48647584',
  '48648097','48649936','48650926','48652951','48654798','48656897','48668574','48677175','48678384','48678552',
  '48679013','48681925','48683169','48688402','48690240','48701389','48711464','48718691','48719333','48727808',
  '48728974','48729115','48736815','48740105','48744075','48744235','48745622','48749531','48751907','48756032',
  '48756586','48757890','48759064','48770263','48775982','48782753','48783146','48789458','48800808','48808635',
  '48815078','48820513','48823868','48824578','48829071','48846706','48847284','48849922','48855381','48866425',
  '48869453','48871791','48874783','48878714','48879483','48881126','48884001','48892121','48898618','48902071',
  '48902610','48907981','48910550','48917252','48920150','48933045','48933454','48935205','48937020','48942936',
  '48944300','48945016','48945168','48953839','48959056','48959971','48962970','48970124','48976945','48989371',
  '48994670','48996343','49010209','49012571','49012727','49016637','49018670','49035832','49036722','49036853',
  '49041021','49041225','49042322','49043452','49046534','49068254','49069649','49071236','49076645','49083519',
  '49089887','49092648','49100309','49104787','49106365','49119668','49123084','49123235','49132269','49136028',
  '49138460','49142030','49152780','49156970','49160758','49162812','49169764','49176153','49176262','49179569',
  '49179689','49181533','49196294','49197241','49206751','49221883','49238431','49257635','49260794','49260795',
  '49267541','49269529','49270630','49272599','49276948','49278055','49280836','49281813','49283917','49285901',
  '49291675','49304196','49312487','49314316','49319879','49323474','49324441','49324884','49342077','49350844',
  '49352102','49359517','49369946','49370099','49377130','49378371','49380121','49382674','49384271','49386509',
  '49387898','49391330','49392369','49393685','49394604','49395594','49401423','49402346','49403745','49424697',
  '49434658','49436069','49447807','49453364','49461485','49466241','49466631','49470629','49471593','49474274',
  '49478275','49484734','49486256','49489811','49492015','49493890','49493967','49494350','49499590','49513123',
  '49519562','49524761','49540080','49541352','49543549','49545973','49546813','49549317','49555127','49576964',
  '49590026','49594371','49595267','49602949','49615788','49619932','49635249','49635309','49637052','49660219',
  '49664791','49665005','49669887','49669965','49672487','49684034','49689250','49689752','49694314','49697354',
  '49704720','49705083','49706154','49718624','49724577','49724884','49725497','49727236','49736747','49737818',
  '49749080','49749128','49752759','49755882','49757094','49769131','49769352','49773848','49773962','49776138',
  '49783183','49785945','49803654','49806260','49822019','49824783','49834287','49838787','49842386','49871687',
  '49872137','49878711','49883523','49889021','49889130','49891521','49896052','49899562','49912158','49914288',
  '49917396','49918438','49920852','49922570','49924282','49926819','49927054','49931735','49933699','49937422',
  '49945240','49948701','49950696','49955467','49961088','49962091','49962652','49975267','49983918','49984334',
  '50003669','50014692','50015881','50015893','50017800','50018442','50020892','50021051','50021188','50026164',
  '50032264','50033615','50035622','50044960','50048593','50052258','50053713','50054923','50056557','50062139',
  '50067041','50067853','50069878','50082807','50083452','50084868','50088105','50091426','50094271','50099086',
  '50101449','50102755','50107340','50114053','50114178','50118130','50119434','50124957','50125853','50127649',
  '50138302','50143662','50146846','50152327','50153304','50178428','50179441','50180571','50186976','50189340',
  '50196165','50206177','50210500','50211151','50211836','50214451','50219055','50220201','50223546','50225266',
  '50226756','50231027','50235190','50237854','50238855','50241961','50245287','50262266','50263336','50265043',
  '50269890','50272505','50279392','50279564','50289148','50292158','50301431','50302104','50304064','50304924',
  '50306140','50313011','50317132','50324530','50335361','50337313','50357971','50365087','50366997','50367831',
  '50368043','50371862','50377799','50378966','50385134','50387576','50388239','50389354','50389364','50394606',
  '50394898','50398763','50405475','50411735','50413148','50413175','50413804','50427705','50429716','50431649',
  '50434585','50441353','50443413','50445821','50451572','50454675','50460286','50463889','50465751','50470488',
  '50477114','50483139','50504876','50507500','50508116','50520181','50523610','50531812','50536454','50546599',
  '50555191','50556709','50562991','50569113','50577132','50590316','50592979','50606077','50607683','50609749',
  '50612394','50624795','50635433','50637751','50644427','50649462','50649505','50651774','50652732','50656492',
  '50659125','50660115','50661231','50661945','50664040','50679767','50683621','50683672','50700383','50704128',
  '50716520','50726198','50729147','50735935','50736008','50738578','50742001','50749527','50750164','50750706',
  '50752806','50764796','50767220','50769579','50770117','50774726','50775881','50783520','50806395','50809077',
  '50809096','50812116','50816360','50825052','50837377','50842378','50845717','50859254','50861165','50866559',
  '50873899','50873955','50876901','50878731','50885655','50893858','50895292','50898685','50902603','50908692',
  '50910850','50932662','50932944','50939169','50945114','50953015','50957766','50964094','50965104','50965917',
  '50967477','50970804','50980663','50988770','50989905','50999668','51005870','51006387','51016235','51017785',
  '51018055','51024978','51032296','51034328','51035812','51037692','51044819','51045692','51046723','51049354',
  '51050354','51055757','51056020','51060461','51067368','51069476','51072415','51075064','51081886','51083481',
  '51086617','51098024','51102921','51109203','51114350','51117372','51118493','51128571','51132349','51139399',
  '51145351','51150414','51151274','51155612','51155814','51157911','51159962','51174297','51180038','51196114',
  '51197208','51202087','51202350','51210747','51210949','51216288','51219479','51225172','51233014','51239897',
  '51240923','51244076','51248371','51248954','51253770','51260084','51261864','51262720','51266607','51269360',
  '51273752','51275085','51276000','51279583','51280226','51290022','51293395','51293906','51298225','51300342',
  '51301942','51311210','51312637','51326215','51331971','51334411','51344138','51350030','51357626','51359751',
  '51361942','51368233','51374441','51377388','51382750','51384164','51384809','51391383','51392137','51397559',
  '51399230','51399637','51402489','51406038','51406083','51411264','51411291','51415750','51420556','51423182',
  '51432994','51434630','51437124','51458806','51459880','51464270','51466556','51470926','51488211','51489384',
  '51490158','51499903','51501408','51502551','51505212','51508180','51512873','51515982','51516819','51517311',
  '51518453','51520994','51525530','51531404','51537010','51538246','51550897','51557253','51561785','51567621',
  '51568170','51580467','51581530','51586437','51594727','51594971','51598828','51599310','51603074','51604080',
  '51604572','51605213','51614449','51633751','51639143','51641279','51650582','51652604','51654643','51656557',
  '51658101','51669509','51678521','51680542','51681653','51682146','51687580','51689358','51708099','51721428',
  '51730451','51730767','51732244','51732307','51742451','51747588','51750489','51756823','51763348','51764470',
  '51768756','51776583','51787934','51789811','51790210','51793336','51793836','51799327','51800882','51817941',
  '51818125','51820259','51822298','51823100','51824955','51826239','51831247','51831695','51835878','51837229',
  '51837695','51847261','51849399','51854109','51858680','51863366','51870382','51876810','51881933','51883271',
  '51885840','51886247','51898498','51899676','51913335','51919607','51919858','51921727','51924679','51946366',
  '51951372','51955347','51972724','51974370','51978330','51978573','51979403','51995046','51996589','52004884',
  '52014284','52018175','52019870','52022686','52036701','52040755','52041697','52043512','52052858','52059195',
  '52063287','52063623','52074437','52083675','52084847','52092905','52095048','52102963','52103670','52104011',
  '52107765','52109723','52113397','52121969','52124111','52130948','52137070','52150376','52155635','52157017',
  '52165317','52171118','52171730','52172993','52173430','52177060','52186130','52198920','52199741','52206958',
  '52207831','52211085','52213790','52230285','52233838','52235590','52238738','52247414','52250171','52252340',
  '52261029','52266055','52269208','52272844','52295793','52300795','52301444','52302255','52303364','52348259',
  '52358158','52367360','52369822','52381458','52391180','52396023','52405467','52407359','52413812','52413882',
  '52420834','52421644','52423392','52436906','52440616','52447074','52456208','52456451','52466294','52476153',
  '52483238','52484105','52485612','52487342','52490032','52496215','52500817','52504996','52506005','52508071',
  '52510335','52516370','52517215','52518233','52520167','52526647','52527551','52528187','52541183','52543271',
  '52546551','52546662','52552303','52577639','52590523','52590992','52591144','52592370','52592818','52595984',
  '52600367','52600914','52601103','52602729','52612000','52614581','52617118','52619306','52620541','52620653',
  '52621422','52624159','52635635','52649924','52652018','52653026','52653694','52659677','52661898','52667307',
  '52674264','52677307','52681207','52696253','52697101','52697197','52704787','52711726','52711969','52713903',
  '52714960','52718476','52728536','52736553','52742537','52744861','52745041','52750750','52753390','52756376',
  '52760598','52774930','52782602','52790189','52792065','52795602','52796860','52799840','52800704','52810420',
  '52827825','52829283','52829502','52831347','52834662','52837620','52840768','52851730','52863874','52869231',
  '52877906','52879804','52880199','52882375','52890000','52898003','52898946','52907982','52909911','52913195',
  '52913421','52914859','52917546','52923891','52929170','52931618','52932116','52936177','52940911','52944273',
  '52945765','52949093','52960293','52969956','52972840','52975319','52977309','52980030','52980680','52981689',
  '52988652','52990025','52991663','52997192','52997697','52998169','52999733','53013027','53015502','53015914',
  '53016656','53017298','53019164','53029260','53033448','53034530','53035045','53040287','53051131','53062186',
  '53063614','53078599','53084322','53087226','53089933','53096817','53098215','53107236','53113520','53114359',
  '53125856','53126220','53128089','53133044','53134521','53141846','53146243','53164433','53166861','53167488',
  '53170355','53190728','53195845','53199724','53200382','53201471','53205122','53208212','53227888','53234918',
  '53238734','53241835','53244661','53247127','53254061','53264167','53275027','53275151','53281798','53293143',
  '53294875','53300904','53302556','53304632','53309368','53318972','53319689','53321421','53321820','53326831',
  '53330061','53330862','53332732','53339362','53344148','53348168','53350126','53352438','53357105','53361812',
  '53367553','53367595','53368232','53374756','53378853','53381176','53383309','53387121','53389343','53391767',
  '53392279','53395698','53402274','53421971','53426164','53432192','53450135','53451302','53454447','53456135',
  '53469455','53473297','53482220','53488576','53488868','53489795','53493479','53513859','53531482','53540148',
  '53542544','53545646','53545716','53546960','53557332','53557745','53563013','53563850','53567368','53576550',
  '53577214','53579863','53581180','53581893','53584392','53585640','53598278','53599652','53600985','53601406',
  '53604786','53605989','53613975','53614561','53625915','53631522','53635878','53638213','53638448','53638896',
  '53650849','53655713','53659947','53664261','53667616','53683762','53687696','53712619','53714367','53715406',
  '53730581','53740126','53746252','53748979','53751097','53762477','53770733','53772492','53775088','53778802',
  '53781197','53798621','53802583','53811414','53815435','53818674','53821106','53824300','53824434','53824593',
  '53826055','53834303','53839191','53844657','53852152','53853322','53853644','53857076','53858738','53863881',
  '53867899','53870549','53885255','53886561','53886999','53889405','53894255','53902997','53904929','53924239',
  '53940166','53943221','53947903','53954610','53961913','53962412','53970411','53984213','53991187','53994295',
  '53996370','54003153','54007114','54015067','54016083','54017861','54018788','54034305','54036355','54039823',
  '54049136','54056426','54079592','54100693','54104012','54105726','54109717','54110123','54112781','54122460',
  '54132799','54139094','54140513','54141591','54142211','54146843','54151393','54154401','54163297','54174535',
  '54175701','54178350','54179960','54183255','54184096','54186072','54188579','54191285','54197925','54202697',
  '54214919','54216958','54221106','54224898','54227927','54257333','54259485','54266827','54267615','54280727',
  '54283330','54284773','54288596','54288841','54290527','54295690','54302608','54305208','54306599','54318054',
  '54330896','54352216','54352587','54352635','54352731','54359968','54360386','54368927','54371943','54375837',
  '54378538','54384049','54385272','54387128','54395039','54396391','54404520','54408528','54415605','54416829',
  '54422785','54428650','54428856','54442491','54450614','54463652','54473192','54477435','54484030','54486354',
  '54491667','54492395','54494250','54505644','54505939','54506607','54506655','54516298','54517518','54519955',
  '54525920','54528748','54535824','54552064','54563968','54566172','54569288','54572184','54575364','54582129',
  '54585110','54593658','54598204','54601534','54603143','54616744','54616866','54617813','54622349','54623614',
  '54624394','54642285','54653311','54654406','54657035','54661896','54675779','54688901','54703177','54706756',
  '54711505','54713666','54719758','54725069','54733815','54734428','54735410','54737985','54745414','54753901',
  '54755343','54762176','54764063','54767392','54779962','54782560','54784005','54787797','54788251','54789625',
  '54793023','54793658','54805273','54808084','54808914','54811310','54814444','54817821','54821553','54829142',
  '54832779','54840529','54841563','54855522','54857112','54858195','54866727','54867095','54880443','54888277',
  '54890071','54895384','54909520','54912235','54922773','54940680','54942332','54949274','54950190','54951300',
  '54957838','54958441','54961500','54963797','54968912','54969727','54970109','54985229','54986486','54990842',
  '54991241','54992924','55005195','55005922','55008873','55012277','55013925','55015677','55020805','55023795',
  '55026110','55030432','55037494','55039960','55042319','55043329','55047073','55062712','55067200','55070577',
  '55076277','55076747','55090617','55094211','55102031','55111962','55112567','55114942','55119363','55120247',
  '55123910','55124178','55128476','55145573','55151729','55153544','55158714','55165201','55170177','55173711',
  '55183972','55186251','55186633','55190644','55190659','55194846','55195157','55196676','55197703','55213651',
  '55226266','55226430','55231838','55236168','55250794','55251156','55257066','55257685','55269613','55270641',
  '55274327','55276252','55276914','55284541','55294314','55300672','55310546','55310614','55312460','55315971',
  '55333192','55342446','55354039','55360940','55361180','55365650','55382344','55387399','55389848','55393597',
  '55394245','55396206','55397139','55398186','55399510','55401754','55410574','55412395','55413524','55416694',
  '55418260','55419638','55423770','55425593','55428261','55432255','55433799','55437295','55442531','55442715',
  '55445051','55455855','55463295','55463743','55464862','55465067','55466216','55468223','55471308','55473294',
  '55482394','55490223','55490798','55493787','55496019','55507358','55507828','55508361','55518122','55524608',
  '55526122','55528696','55535051','55539539','55539802','55540744','55542618','55547281','55547363','55547463',
  '55548280','55553123','55561407','55563972','55566665','55567198','55569986','55576842','55596625','55608257',
  '55608733','55614652','55616253','55624673','55628264','55636632','55641554','55651354','55655967','55662287',
  '55663800','55670245','55673234','55675494','55685477','55689246','55697153','55697555','55705960','55707898',
  '55709472','55711934','55718484','55720859','55728385','55730343','55738336','55742928','55745691','55746948',
  '55758016','55759587','55760643','55761172','55761957','55764850','55766436','55767910','55773198','55780320',
  '55786459','55795719','55798631','55800278','55806922','55807445','55812516','55818701','55821857','55828769',
  '55831442','55839944','55844360','55851915','55860384','55872611','55882299','55883082','55885812','55886083',
  '55886370','55891696','55892931','55896633','55902850','55904609','55907136','55909644','55911315','55915402',
  '55924388','55930213','55931385','55934033','55938976','55942726','55951551','55952777','55952839','55957508',
  '55960232','55968703','55976573','55978459','55983234','55986751','55990404','56005551','56008182','56015409',
  '56017808','56019318','56028066','56029832','56031231','56032855','56033872','56034970','56035594','56044629',
  '56047173','56049156','56063346','56064779','56068216','56069827','56072272','56074736','56082412','56084173',
  '56086327','56089030','56098592','56102069','56105600','56113965','56115055','56126868','56127309','56138965',
  '56149381','56150665','56153791','56155627','56158680','56159938','56160697','56161731','56164427','56169162',
  '56172835','56174652','56175982','56181318','56187691','56193995','56194754','56202376','56215392','56222426',
  '56222744','56223284','56229551','56233290','56233475','56238276','56248107','56255449','56258331','56258491',
  '56262942','56285554','56288001','56292697','56294481','56303289','56309526','56315026','56322669','56327124',
  '56342327','56349047','56350898','56352073','56352607','56356651','56361644','56379965','56383423','56385191',
  '56387121','56391806','56396933','56398108','56403795','56406477','56420457','56421460','56421990','56433469',
  '56440191','56447728','56450740','56450920','56456286','56456666','56456873','56459850','56463508','56466466',
  '56468564','56476513','56486389','56490884','56492617','56502008','56511437','56523612','56529396','56562212',
  '56572267','56575094','56586489','56594178','56610221','56611301','56612786','56616132','56618423','56623278',
  '56625278','56632102','56632392','56638754','56639675','56647669','56650432','56660958','56661967','56677687',
  '56682572','56691510','56691938','56693625','56694078','56696254','56700553','56702335','56709978','56710863',
  '56711359','56711593','56713761','56714919','56716455','56718739','56721756','56722604','56722692','56724214',
  '56728788','56729391','56734792','56741477','56741748','56750583','56752997','56754074','56758637','56758846',
  '56763087','56771769','56774111','56778797','56786440','56786577','56790629','56792507','56797921','56799905',
  '56809569','56817523','56819287','56825386','56829389','56832177','56834546','56837091','56839926','56842214',
  '56843365','56844661','56844832','56847569','56847587','56850198','56854460','56857873','56866164','56872117',
  '56879258','56888559','56893053','56904004','56907826','56912306','56920840','56924716','56928131','56928476',
  '56953259','56961888','56962214','56964477','56975734','56978088','56996167','56999492','57006724','57007713',
  '57008310','57017375','57021127','57024146','57024242','57025492','57025772','57027632','57031081','57038845',
  '57040006','57050230','57054434','57063316','57070802','57071292','57072423','57085354','57091527','57093740',
  '57096369','57103090','57105797','57107621','57113666','57115825','57118048','57123696','57125741','57138180',
  '57138656','57141576','57144106','57147569','57156221','57163339','57166200','57171770','57178616','57181114',
  '57187669','57197105','57210930','57219842','57220519','57220578','57222388','57226877','57230308','57233492',
  '57235902','57247939','57251606','57253476','57262118','57264878','57265046','57266467','57269987','57281980',
  '57296214','57296232','57298916','57319310','57325288','57339912','57343630','57354288','57355319','57357891',
  '57360202','57370364','57371001','57372219','57378814','57379340','57394893','57410766','57418780','57438223',
  '57439942','57441235','57443832','57447463','57449459','57455320','57457563','57457630','57463223','57467653',
  '57473856','57477845','57479626','57480043','57482649','57483160','57485558','57493341','57503707','57517899',
  '57518403','57522842','57524318','57528319','57529046','57535048','57550711','57563978','57574979','57576925',
  '57576994','57577746','57577757','57594344','57596547','57607096','57607213','57611709','57613490','57615249',
  '57616224','57629223','57636620','57638952','57642542','57643614','57644398','57655430','57662976','57676342',
  '57695572','57695695','57698929','57704392','57706221','57721734','57726595','57730571','57748154','57752462',
  '57754358','57759174','57762090','57772272','57780572','57786098','57796007','57796647','57802662','57803461',
  '57808502','57814419','57816383','57818267','57823639','57826971','57828134','57830334','57831362','57833704',
  '57836995','57844930','57847767','57848651','57868219','57873443','57875395','57898595','57902716','57910405',
  '57910494','57917334','57920210','57921038','57925581','57933598','57937481','57943728','57954068','57960529',
  '57963353','57967934','57968171','57971786','57987597','57995898','58001454','58014695','58015883','58019441',
  '58020543','58022988','58031003','58053255','58057064','58064086','58064530','58069529','58071734','58075523',
  '58079114','58080206','58081115','58095850','58102270','58104606','58109448','58116194','58119814','58120825',
  '58123001','58133170','58141244','58154850','58156789','58157126','58157810','58160480','58161446','58162132',
  '58165773','58173949','58177570','58177738','58182607','58183484','58194550','58197008','58197476','58197542',
  '58209088','58210350','58219662','58226240','58231411','58233925','58242383','58256910','58268255','58273920',
  '58277265','58287057','58289414','58295703','58298129','58312383','58328159','58333691','58338982','58347531',
  '58354138','58361262','58366298','58393542','58394689','58396054','58398624','58399036','58409221','58410603',
  '58416643','58420942','58423295','58436322','58442082','58444344','58460411','58464759','58470002','58472963',
  '58484284','58485253','58487587','58498341','58502332','58505892','58519844','58520152','58522160','58526247',
  '58527699','58528126','58528314','58532504','58532564','58536222','58540895','58546621','58557122','58557280',
  '58566291','58575189','58583114','58583291','58585165','58590016','58600769','58608564','58610186','58613646',
  '58622484','58626050','58628939','58629770','58633910','58639775','58654228','58668371','58668421','58686009',
  '58688060','58688659','58698951','58703782','58721326','58725524','58734154','58739311','58740935','58757839',
  '58759546','58761392','58765472','58767083','58767918','58775004','58777060','58790008','58790333','58790411',
  '58806272','58807255','58840987','58844622','58848334','58849867','58851550','58862884','58867255','58867273',
  '58867679','58870705','58872543','58873466','58873707','58875652','58875811','58878516','58881450','58882881',
  '58883191','58887045','58887225','58896828','58897470','58900988','58901926','58908918','58911250','58911718',
  '58912994','58920899','58933055','58933626','58938047','58940217','58946858','58946980','58947107','58958845',
  '58960103','58965366','58974660','58979879','58981778','58995823','59001885','59005915','59007393','59007572',
  '59009849','59010757','59012026','59018474','59021185','59023690','59035675','59047037','59050479','59052555',
  '59055358','59063361','59065140','59071724','59072327','59072638','59078919','59083624','59083703','59084990',
  '59085653','59085764','59093677','59094076','59097723','59098340','59104874','59107693','59108800','59118687',
  '59129426','59133074','59138391','59138429','59138717','59139172','59146540','59153551','59153932','59160580',
  '59172216','59172863','59175822','59179589','59188231','59190916','59202722','59203240','59206979','59207007',
  '59209489','59214967','59219121','59222372','59229285','59229734','59242775','59244964','59252225','59263558',
  '59264204','59284337','59302875','59308463','59311584','59316143','59316564','59332267','59337968','59340198',
  '59347668','59348407','59350564','59351468','59351640','59352266','59355141','59356916','59369590','59379189',
  '59390430','59390883','59394356','59394382','59400176','59402195','59404776','59410402','59416984','59417086',
  '59419388','59428353','59434172','59445531','59450682','59450751','59451475','59452048','59456784','59463213',
  '59470510','59472221','59484025','59494542','59497198','59504741','59508189','59515316','59521738','59522932',
  '59527389','59529462','59533221','59533448','59533791','59534623','59536720','59540376','59547839','59548409',
  '59552725','59553236','59554721','59556495','59559126','59568615','59570922','59571635','59574969','59580858',
  '59585752','59590770','59591243','59594598','59594978','59608969','59610289','59613787','59622666','59625233',
  '59640333','59645666','59649695','59653128','59657939','59664116','59667335','59680288','59688863','59696526',
  '59699655','59701912','59703279','59704578','59708778','59709490','59710828','59712563','59712764','59717189',
  '59719922','59721714','59726102','59727894','59730874','59734257','59739222','59741977','59744641','59751234',
  '59753157','59754045','59757256','59757472','59773548','59774770','59777751','59784495','59787626','59796700',
  '59806730','59819777','59826183','59834455','59837284','59840059','59844429','59845691','59847106','59850772',
  '59855553','59864141','59865496','59866748','59869360','59874764','59875735','59878173','59880622','59882014',
  '59884451','59885415','59885520','59886051','59893206','59898863','59916161','59917861','59922346','59925880',
  '59935024','59936384','59937242','59942661','59944008','59945385','59948432','59954154','59955616','59956441',
  '59963922','59973661','59977035','59980437','59986717','59994017','59999298','60000302','60002180','60002568',
  '60008910','60010023','60011554','60013945','60016699','60025765','60033006','60040541','60042667','60044558',
  '60056393','60059808','60069029','60070059','60071550','60076555','60079647','60082225','60082994','60087049',
  '60087113','60088036','60101739','60108928','60110577','60112498','60117788','60122798','60123632','60124957',
  '60125833','60130035','60130704','60136656','60137518','60153947','60159989','60166183','60175091','60180642',
  '60183374','60184002','60191450','60194810','60194843','60201651','60203584','60206454','60210557','60213417',
  '60215291','60225386','60236151','60242060','60247450','60250618','60256240','60258613','60263494','60298312',
  '60299812','60302611','60304406','60307514','60308580','60311887','60316140','60325666','60335025','60345022',
  '60345499','60347556','60355497','60371884','60387480','60396163','60408148','60413471','60414642','60416848',
  '60420452','60422413','60422578','60425417','60425441','60435747','60436184','60447637','60456137','60456208',
  '60466763','60480389','60482454','60484397','60486159','60487070','60496250','60516291','60516827','60518604',
  '60553598','60555698','60563902','60569642','60580406','60581431','60583671','60584660','60594727','60612208',
  '60616145','60629194','60635608','60636077','60638854','60639064','60654514','60657394','60659678','60664787',
  '60667752','60679664','60695467','60708199','60714517','60725764','60731611','60733358','60736343','60744750',
  '60753536','60754455','60756035','60756327','60761900','60765243','60783432','60783993','60785588','60787318',
  '60788902','60792080','60796478','60800451','60803576','60825153','60829534','60834353','60838733','60839503',
  '60847049','60848824','60857072','60868638','60870922','60879369','60889974','60899931','60902086','60903697',
  '60912518','60914217','60915630','60919845','60934569','60935356','60940873','60944938','60949058','60949997',
  '60951127','60953421','60967303','60969365','60969908','60972628','60974679','60977491','60977581','60978338',
  '60997038','60998978','61009602','61019176','61024620','61029574','61031676','61031897','61034723','61042200',
  '61042623','61046555','61056272','61058753','61065273','61075759','61083031','61086193','61088099','61088918',
  '61095929','61100363','61114777','61119816','61121398','61135495','61141339','61147298','61147884','61157995',
  '61160767','61165049','61167372','61168998','61183361','61186475','61192073','61195501','61205291','61210872',
  '61211790','61212696','61217021','61235785','61241453','61246255','61249559','61254109','61262441','61267148',
  '61270514','61274360','61284787','61285822','61287020','61289191','61294058','61294321','61294494','61294784',
  '61295909','61335469','61338959','61339285','61347800','61348009','61355630','61357386','61370713','61389662',
  '61396296','61400865','61419906','61423913','61428828','61438719','61451483','61454809','61466805','61469293',
  '61469369','61470225','61470252','61472352','61473522','61480303','61480937','61481241','61494345','61501867',
  '61503038','61512456','61523712','61525794','61546981','61558666','61568888','61575751','61578434','61582354',
  '61589003','61590628','61597957','61603070','61611632','61611665','61612904','61619436','61621186','61629757',
  '61631513','61652241','61655301','61656627','61658643','61660818','61664241','61664742','61673128','61683850',
  '61686716','61687814','61688001','61688737','61698442','61699681','61699995','61702125','61702786','61703204',
  '61706298','61710867','61712049','61717567','61723142','61726142','61735133','61745753','61748662','61750011',
  '61752017','61754481','61755461','61760267','61766100','61766149','61772301','61779535','61780377','61781403',
  '61783486','61789590','61794368','61797098','61808056','61812330','61812519','61816629','61822492','61825655',
  '61833900','61841057','61845146','61854996','61860388','61867931','61872398','61874502','61881855','61885249',
  '61890131','61894282','61901385','61904169','61904973','61921149','61928019','61930064','61942175','61945269',
  '61951890','61952759','61953057','61955403','61960283','61963311','61967932','61982910','61997448','62001600',
  '62009900','62019915','62020714','62022370','62022876','62029009','62030410','62041569','62049870','62052792',
  '62059276','62062283','62066189','62067358','62073913','62086116','62086704','62087062','62093929','62105948',
  '62112424','62113892','62118460','62119714','62122912','62130963','62133231','62136300','62139780','62141262',
  '62141560','62144173','62148511','62160176','62161086','62161996','62163313','62166256','62168587','62168706',
  '62171414','62175085','62177244','62185646','62197964','62210092','62211036','62212656','62215248','62220050',
  '62223082','62225381','62227048','62229539','62231719','62235889','62245631','62249998','62250758','62254505',
  '62256434','62266574','62274857','62282065','62285691','62288791','62289220','62300622','62300981','62309890',
  '62311573','62311606','62312398','62321023','62324743','62326811','62330417','62330899','62334178','62336215',
  '62337835','62340037','62340083','62342312','62345454','62354018','62354132','62359230','62364233','62368711',
  '62370276','62370816','62374929','62377559','62387585','62388628','62395481','62397296','62402063','62403479',
  '62406690','62410129','62410517','62415717','62421743','62427194','62441742','62444438','62455518','62455708',
  '62456179','62458078','62458249','62465412','62471961','62481215','62481461','62482677','62485864','62486027',
  '62490207','62494268','62496389','62501850','62504631','62508665','62509164','62530417','62531415','62532265',
  '62538613','62543406','62567421','62568325','62568519','62584772','62586795','62601627','62620306','62629154',
  '62633242','62646037','62651044','62654523','62666334','62676453','62685018','62690522','62690972','62692666',
  '62694193','62700836','62706812','62728124','62733173','62734886','62734923','62742424','62745934','62749246',
  '62752363','62754633','62767020','62770440','62775465','62780030','62781179','62784244','62789166','62797637',
  '62809676','62810951','62811087','62818122','62828275','62829015','62829494','62842332','62844808','62847642',
  '62851214','62853353','62865317','62868143','62881883','62884374','62885833','62885896','62891542','62899868',
  '62900822','62903686','62906365','62914399','62917771','62918580','62924953','62956201','62956208','62960193',
  '62963181','62974166','62984542','62985916','62996546','63006702','63017719','63017847','63018707','63026908',
  '63027281','63028261','63031384','63037274','63040423','63040679','63050789','63058069','63064391','63069598',
  '63072065','63077666','63080863','63083615','63086606','63088645','63089200','63096943','63104425','63112715',
  '63116705','63116769','63119174','63130081','63159367','63161524','63163306','63172348','63179529','63181365',
  '63185950','63188280','63189639','63195144','63197258','63201012','63207477','63209696','63230974','63240981',
  '63242702','63243299','63243924','63245781','63247854','63261481','63269192','63269339','63283015','63283594',
  '63290922','63293469','63300093','63300982','63305903','63309311','63314753','63319626','63325278','63325343',
  '63329501','63334879','63337059','63352073','63358362','63363657','63376095','63377770','63382944','63388440',
  '63392807','63403650','63403748','63403899','63409916','63430923','63437196','63439884','63444618','63445626',
  '63447853','63451243','63461859','63479821','63483782','63487238','63488838','63489873','63490041','63491998',
  '63495513','63498683','63503973','63518867','63520173','63522483','63538479','63547272','63554244','63560059',
  '63560415','63567411','63572458','63572543','63582150','63583096','63594345','63594950','63597066','63606327',
  '63607769','63611996','63613086','63618100','63620247','63621930','63624285','63639901','63640219','63640341',
  '63642264','63653618','63656209','63664835','63666967','63670544','63682622','63683754','63692687','63694306',
  '63696946','63701882','63702619','63706477','63710497','63714685','63715773','63728495','63732278','63734817',
  '63739634','63743759','63752771','63754267','63760928','63805384','63808604','63811960','63819267','63820307',
  '63825508','63844233','63856440','63857380','63858017','63858813','63863494','63865188','63866453','63867600',
  '63886207','63886818','63890881','63902814','63906185','63906275','63907038','63919191','63925464','63926940',
  '63945046','63955683','63960552','63966350','63967687','63968506','63975129','63983051','63991116','64002967',
  '64006458','64009409','64009692','64012511','64014805','64015974','64020639','64027519','64029777','64036633',
  '64046039','64047069','64063675','64063911','64102191','64107322','64111019','64112193','64115905','64116473',
  '64118238','64119025','64132668','64141368','64155087','64166235','64175334','64179284','64202746','64205686',
  '64209868','64211288','64218438','64229772','64232508','64238630','64239261','64242923','64243447','64249603',
  '64257891','64258132','64260739','64262992','64272232','64272829','64274262','64281196','64282810','64286407',
  '64294088','64320519','64328615','64335278','64337301','64337482','64347321','64350674','64355370','64362123',
  '64365446','64370764','64375611','64379727','64379803','64390177','64391894','64392158','64400102','64400439',
  '64400466','64402342','64402924','64406121','64406703','64407256','64415930','64416642','64423532','64439714',
  '64450431','64451598','64453184','64455001','64458656','64464780','64466114','64466450','64469073','64487685',
  '64488339','64493767','64496907','64501995','64506624','64510889','64547274','64559976','64564745','64565004',
  '64566582','64573037','64582444','64601481','64601503','64624371','64635653','64642566','64645604','64646752',
  '64650697','64656338','64674991','64675837','64681710','64702677','64715791','64724027','64734711','64740493',
  '64757023','64763335','64766293','64767785','64768399','64775447','64781178','64787853','64792280','64793853',
  '64802956','64812188','64825716','64829846','64831327','64837837','64844355','64855144','64858729','64859773',
  '64865476','64866403','64868207','64873104','64873901','64874510','64876256','64880086','64886204','64888554',
  '64891434','64894490','64901129','64901413','64906871','64908451','64912274','64916890','64919062','64919937',
  '64926545','64928111','64929448','64938575','64939743','64939771','64944741','64945254','64957961','64995229',
  '64995425','64997202','65002421','65007680','65015039','65015622','65016456','65018326','65027915','65029331',
  '65032269','65034337','65034531','65038107','65038409','65041890','65050465','65064035','65073851','65080260',
  '65081663','65082559','65082622','65082901','65088756','65092750','65104345','65112237','65112558','65115840',
  '65120713','65123731','65125210','65130488','65144476','65160257','65163372','65166134','65166177','65177361',
  '65194781','65207729','65214653','65214987','65221727','65225693','65240171','65244710','65245333','65250984',
  '65253595','65260095','65261809','65266497','65267908','65271573','65279823','65280738','65285067','65287420',
  '65298366','65310247','65312682','65314193','65325034','65328509','65337157','65341825','65349143','65359299',
  '65370849','65376964','65385557','65386941','65390650','65394335','65396047','65402671','65403320','65410009',
  '65410867','65411357','65414818','65418424','65423956','65424649','65431544','65446933','65449584','65449888',
  '65452004','65457205','65463847','65474041','65478709','65481770','65481802','65484419','65487002','65491147',
  '65502832','65512503','65514049','65514605','65531766','65532441','65542471','65549662','65551285','65552080',
  '65567073','65572609','65573618','65579429','65584462','65586439','65587235','65588846','65592039','65603326',
  '65609049','65615740','65615851','65618917','65656860','65662998','65667984','65670944','65672740','65673005',
  '65680299','65683577','65683773','65686978','65693024','65693456','65698010','65703328','65706775','65714804',
  '65720005','65726149','65737138','65739655','65740403','65752836','65757475','65764515','65765419','65765597',
  '65766146','65767474','65770116','65775123','65777030','65783342','65784455','65793344','65798623','65804389',
  '65807851','65819144','65819489','65820952','65822513','65822616','65823592','65824783','65825133','65840513',
  '65846075','65847434','65853032','65860390','65860841','65872557','65881889','65884067','65885589','65890253',
  '65904854','65905194','65906267','65907285','65910368','65913389','65925874','65937524','65940155','65940838',
  '65941556','65949787','65953732','65955115','65960631','65968020','65970706','65977603','65986514','65992817',
  '65993959','66003825','66007721','66017587','66019866','66023276','66036693','66041208','66045348','66047242',
  '66067226','66071341','66071926','66083130','66088807','66089430','66089809','66091010','66095103','66096925',
  '66100345','66101268','66105103','66114004','66120223','66122107','66130818','66131408','66131614','66153701',
  '66163778','66164134','66165475','66169494','66171244','66178174','66178792','66186785','66188019','66190865',
  '66192468','66193202','66193658','66194205','66199440','66203845','66210221','66216908','66223487','66227109',
  '66228067','66231342','66232708','66232788','66234148','66237733','66254471','66267357','66267980','66268930',
  '66269365','66277953','66282298','66300709','66303233','66306142','66311272','66312592','66312820','66316050',
  '66321663','66324366','66326864','66329156','66335387','66339786','66340111','66344335','66344994','66346079',
  '66348683','66352288','66358755','66361390','66364610','66368772','66374936','66412019','66416361','66418938',
  '66422138','66423559','66431862','66440253','66442047','66443231','66453068','66454422','66462422','66464207',
  '66475787','66476590','66484754','66486192','66489593','66498174','66499755','66509239','66510382','66514822',
  '66518308','66521830','66524352','66526029','66538410','66549036','66553181','66557437','66559531','66561615',
  '66565167','66572105','66574339','66582951','66585128','66596411','66605037','66615226','66621235','66625745',
  '66625766','66627453','66628569','66630075','66633629','66640341','66644436','66645793','66647467','66655965',
  '66664023','66667320','66670395','66692440','66701890','66720802','66721118','66726701','66731983','66733585',
  '66733993','66742357','66755035','66755955','66761375','66779948','66798271','66802550','66808673','66811405',
  '66812321','66824346','66826941','66828212','66834772','66837682','66841250','66844782','66846286','66854796',
  '66854966','66856628','66859213','66861875','66869881','66880356','66885303','66893555','66900578','66907383',
  '66920655','66923921','66924583','66930998','66935572','66941054','66949827','66953678','66953721','66959191',
  '66971114','66973340','66991152','67001553','67001892','67005194','67007808','67009226','67017905','67019845',
  '67021146','67022394','67031269','67048058','67055897','67057206','67060716','67064418','67064891','67071313',
  '67083667','67084641','67087833','67089469','67089595','67095219','67122813','67140073','67142538','67142880',
  '67144812','67145374','67169090','67172504','67186512','67200447','67201240','67202564','67211142','67214204',
  '67214335','67215965','67248397','67255699','67256427','67257245','67262731','67267076','67272666','67273419',
  '67279121','67286767','67288336','67291633','67292112','67294392','67294922','67301549','67303758','67309414',
  '67309444','67323091','67324591','67332801','67335723','67349886','67350328','67353351','67357536','67359554',
  '67361913','67373985','67377557','67377831','67400957','67403611','67419864','67423958','67428897','67431794',
  '67433360','67434771','67435061','67437849','67437865','67437892','67439581','67448411','67456364','67472964',
  '67480202','67491139','67494700','67516162','67517911','67519114','67526564','67527953','67545515','67546434',
  '67552010','67562474','67562638','67566080','67568114','67568375','67569117','67572260','67581186','67595019',
  '67604149','67605225','67613657','67618839','67619182','67623350','67631172','67632428','67638136','67639996',
  '67641981','67644577','67646301','67657194','67665560','67667073','67687544','67689218','67689346','67690859',
  '67698261','67701016','67710889','67711373','67718404','67721686','67722748','67722912','67729835','67731159',
  '67743825','67746550','67747581','67754037','67761828','67763292','67771948','67780601','67791045','67794236',
  '67799446','67808753','67817148','67817857','67818292','67819058','67822967','67823641','67827249','67828961',
  '67840179','67850605','67853233','67860576','67864188','67875126','67878808','67879102','67885205','67893604',
  '67898109','67902544','67903020','67904309','67912821','67918408','67925672','67930256','67932892','67933159',
  '67937494','67942916','67947616','67949133','67959040','67959461','67959581','67960469','67961653','67964003',
  '67964579','67965395','67971423','67974542','67987988','68004352','68016358','68017065','68021335','68029664',
  '68039881','68040189','68042890','68044607','68056939','68067753','68073519','68098682','68101259','68115467',
  '68123643','68126119','68128487','68131765','68134060','68134601','68139346','68146060','68146836','68154985',
  '68157087','68157400','68165238','68168314','68169865','68170962','68172696','68172823','68194014','68194185',
  '68198790','68202753','68227413','68235850','68246366','68259951','68265237','68270702','68270769','68279212',
  '68283093','68285648','68302743','68304168','68315016','68326000','68333007','68344589','68352179','68357441',
  '68357460','68364312','68366881','68372081','68373517','68374132','68377688','68384383','68388724','68389561',
  '68399544','68400296','68414865','68417187','68418864','68420524','68421686','68428584','68430581','68431971',
  '68436936','68446329','68448419','68451898','68468196','68468812','68482550','68483510','68489802','68493408',
  '68493836','68494374','68503902','68506536','68508369','68511513','68512687','68514368','68516162','68519638',
  '68531594','68531666','68534626','68542127','68551811','68557115','68561057','68564510','68564758','68567693',
  '68580149','68580984','68596615','68602008','68603522','68603568','68622667','68624095','68626687','68627943',
  '68628526','68628912','68631154','68631404','68639363','68639790','68642274','68647968','68648551','68653085',
  '68656790','68684206','68690573','68691615','68692536','68695271','68703714','68707494','68716521','68719237',
  '68723423','68726048','68729564','68730707','68731915','68744468','68750149','68751799','68757836','68765895',
  '68766753','68778961','68792739','68796156','68797147','68799578','68808453','68808679','68809202','68811568',
  '68817908','68823603','68826109','68838486','68846595','68848030','68857439','68858776','68870224','68872069',
  '68875822','68879141','68879510','68881728','68886678','68891257','68898319','68901431','68902279','68903463',
  '68912313','68930834','68933354','68936185','68938514','68939030','68942482','68942735','68951122','68954809',
  '68956496','68957266','68971081','68977014','68977370','68985208','68987870','68989640','68990698','68991361',
  '68997124','69005212','69015300','69020300','69021434','69024387','69027220','69040271','69047165','69076393',
  '69077115','69083324','69086818','69099194','69104922','69106714','69107784','69107899','69117711','69124528',
  '69125123','69132444','69135507','69135812','69138658','69141699','69150002','69151039','69154914','69159120',
  '69162248','69167127','69174618','69188369','69188690','69199263','69204792','69217811','69219871','69220368',
  '69232006','69232750','69250157','69252983','69254343','69254577','69256035','69259060','69264178','69265590',
  '69277080','69277544','69287968','69289042','69289719','69293352','69300784','69304008','69311120','69318479',
  '69326901','69333512','69334654','69334955','69336897','69338362','69343305','69348320','69348680','69354882',
  '69356503','69357782','69361840','69363732','69369374','69369751','69373109','69375578','69376019','69379279',
  '69382818','69386413','69393130','69394486','69399328','69421234','69424077','69427016','69448178','69450893',
  '69460873','69463071','69466996','69481063','69483104','69491907','69506484','69514951','69519919','69523596',
  '69537583','69540726','69545944','69546753','69557900','69558393','69564965','69569567','69573715','69579231',
  '69587622','69588673','69589708','69590062','69595161','69595911','69596316','69598687','69604763','69608245',
  '69609833','69640508','69646459','69652670','69666734','69677457','69678118','69679804','69682829','69683456',
  '69683960','69690505','69691875','69692161','69693578','69699808','69720859','69724985','69727633','69728256',
  '69729776','69730836','69742379','69749380','69752056','69752535','69753302','69755024','69757892','69759190',
  '69780943','69781688','69785793','69786007','69806603','69807133','69807596','69808335','69809788','69813876',
  '69813949','69818349','69827470','69833843','69835582','69838139','69844018','69847804','69853391','69886212',
  '69898735','69907318','69910642','69914770','69925614','69929170','69929320','69945135','69950079','69954807',
  '69957396','69964295','69969488','69970801','69971343','69974175','69974865','69990523','69999899','70000949',
  '70003553','70009664','70009943','70010768','70022712','70024787','70025207','70025466','70025693','70026269',
  '70026711','70031273','70036421','70052336','70052487','70057274','70057337','70060300','70066342','70084085',
  '70089727','70091713','70093419','70100944','70103226','70105337','70115242','70120990','70127358','70130025',
  '70130662','70140394','70142848','70146984','70147967','70152047','70153714','70173042','70175902','70180359',
  '70180583','70184827','70188557','70189094','70199285','70205649','70209820','70210867','70214504','70239430',
  '70239613','70241471','70241622','70246404','70258106','70262688','70269662','70279526','70282996','70285148',
  '70285206','70285445','70296882','70304422','70312182','70314572','70322010','70325136','70354114','70358178',
  '70362614','70362635','70369299','70387460','70394281','70395912','70405519','70405581','70409596','70410005',
  '70413559','70416527','70417240','70422384','70424630','70425016','70428520','70436508','70440352','70441620',
  '70448282','70448796','70450258','70451145','70459333','70461823','70462995','70470611','70473009','70475203',
  '70478381','70481721','70486722','70488894','70499975','70500328','70512414','70515309','70519685','70526281',
  '70542585','70545487','70552342','70558222','70562894','70567933','70573410','70597961','70599980','70611901',
  '70618207','70620953','70630674','70637362','70638229','70640687','70658219','70659037','70659042','70669818',
  '70671937','70685361','70685411','70690506','70691662','70693061','70695516','70695650','70701626','70702216',
  '70703700','70709254','70715579','70722537','70722944','70728967','70729074','70741392','70742705','70749499',
  '70762440','70774410','70783656','70785889','70786852','70786869','70820904','70826534','70834637','70835865',
  '70846562','70863442','70867361','70869254','70880140','70882846','70884407','70891300','70892314','70892647',
  '70893584','70895157','70896192','70901145','70902898','70908611','70911486','70911982','70915243','70917646',
  '70936365','70942519','70963983','70969675','70979437','70984588','70988997','71002588','71007790','71008785',
  '71010761','71021379','71023424','71028451','71028659','71038133','71039964','71052925','71063824','71071977',
  '71083208','71083315','71084258','71087931','71103026','71103548','71106088','71117590','71123234','71128867',
  '71129793','71131688','71138168','71138492','71139518','71144322','71145027','71146587','71148237','71149414',
  '71154415','71157774','71162778','71169087','71173615','71179507','71181547','71201417','71201512','71203267',
  '71203477','71205407','71205710','71206599','71207941','71209142','71213235','71220476','71224259','71234025',
  '71234658','71237698','71242453','71244378','71249225','71251650','71252596','71254120','71260788','71261895',
  '71268686','71269597','71277954','71279297','71279892','71281917','71283465','71288418','71290037','71290484',
  '71299810','71305438','71310640','71313020','71317007','71317479','71322297','71323132','71336092','71337147',
  '71341420','71343507','71347854','71353815','71355300','71355633','71366122','71367928','71379470','71381745',
  '71385692','71398164','71399154','71400507','71402148','71409089','71409708','71410379','71419730','71430429',
  '71434419','71435474','71437778','71460666','71467846','71470762','71487077','71489980','71490232','71495905',
  '71504765','71510029','71512281','71513080','71515634','71521104','71529280','71530382','71533386','71535663',
  '71542669','71543791','71547031','71548127','71548279','71548473','71553571','71557417','71558125','71558812',
  '71560011','71561298','71568901','71588107','71590336','71599938','71608282','71611930','71613828','71615437',
  '71617603','71621737','71622342','71625524','71626510','71627016','71641151','71641494','71644743','71648004',
  '71650376','71656656','71662841','71664567','71667645','71671459','71673982','71674451','71679804','71682226',
  '71684930','71687027','71688770','71697389','71724704','71726659','71727966','71731088','71735402','71745271',
  '71747993','71751994','71757722','71766864','71769233','71784423','71786366','71790218','71792709','71798991',
  '71803389','71803508','71806511','71819510','71822314','71824422','71826309','71829489','71834800','71835186',
  '71839179','71852083','71854352','71858821','71865931','71869000','71869391','71879587','71886952','71890476',
  '71898915','71900578','71908245','71911512','71930442','71943806','71947495','71950076','71952337','71954025',
  '71955552','71963888','71963960','71966978','71973712','72002150','72006137','72006838','72007217','72009254',
  '72027671','72034967','72035145','72042309','72042872','72046725','72049282','72049364','72050999','72052435',
  '72060367','72071832','72086851','72088352','72088757','72089926','72102947','72108108','72108430','72111471',
  '72114822','72115363','72116552','72119076','72119821','72121847','72125290','72126872','72127276','72133728',
  '72140271','72144629','72147336','72150508','72155816','72163630','72165396','72170163','72175839','72193851',
  '72198526','72199492','72204406','72206064','72210772','72212708','72214985','72215284','72217598','72225110',
  '72226270','72227638','72228311','72228682','72230443','72238904','72239970','72260605','72261475','72263501',
  '72265874','72269166','72269188','72278047','72285359','72285847','72290753','72292126','72292171','72297637',
  '72297866','72299348','72305942','72306434','72313152','72327418','72340774','72343028','72351568','72364611',
  '72366311','72367942','72368584','72369239','72373315','72388153','72389247','72404088','72404337','72404710',
  '72414724','72419106','72426770','72429796','72439301','72442961','72443100','72448280','72448393','72450867',
  '72463980','72468128','72470117','72478335','72484656','72495751','72499187','72505318','72514165','72514470',
  '72529407','72531257','72533988','72535807','72548753','72555306','72558496','72571581','72595355','72598259',
  '72605729','72610175','72610350','72610671','72621472','72639188','72640615','72644761','72647908','72653668',
  '72659985','72677813','72678492','72679925','72682106','72688814','72690812','72706084','72706562','72718347',
  '72731352','72731467','72746866','72748897','72750476','72756442','72757646','72758080','72764716','72769714',
  '72770470','72770589','72775046','72780616','72781688','72784297','72786369','72798524','72803488','72805795',
  '72816588','72820565','72821634','72830011','72836376','72837066','72845405','72853669','72877747','72878017',
  '72879125','72881865','72884774','72888669','72895935','72896478','72897588','72905224','72906433','72913899',
  '72924110','72930912','72934095','72934775','72934899','72934900','72935451','72949091','72952358','72958511',
  '72970964','72975474','72981705','72983924','72991025','72995054','73029777','73033218','73035205','73039805',
  '73039832','73051966','73060317','73072474','73073502','73083134','73085339','73092252','73095297','73103470',
  '73107096','73110452','73111068','73111169','73111727','73118832','73119232','73128201','73130063','73130635',
  '73133280','73143682','73150114','73151497','73157027','73157274','73166044','73177350','73183213','73188639',
  '73189336','73203299','73203602','73218530','73231210','73252092','73255296','73264425','73278839','73284943',
  '73286939','73296285','73299353','73306932','73318344','73318347','73332551','73334755','73342423','73352741',
  '73355475','73364779','73367577','73368709','73375111','73381660','73382082','73383060','73385819','73385927',
  '73391470','73403046','73404280','73404295','73405822','73411080','73414640','73416613','73419524','73423909',
  '73432743','73439923','73446388','73448120','73453194','73455317','73467805','73474532','73478636','73483230',
  '73484217','73489709','73495064','73499359','73519048','73529122','73543255','73551544','73559255','73566144',
  '73572715','73574183','73589420','73594355','73594567','73603317','73603740','73610060','73631034','73635203',
  '73649595','73654821','73657515','73658032','73659117','73677064','73696175','73697522','73703976','73705778',
  '73719161','73728305','73736811','73751980','73752736','73761360','73762972','73766829','73773531','73776497',
  '73782238','73785472','73787076','73792936','73798569','73800530','73803193','73803949','73804893','73807982',
  '73809854','73820540','73825093','73837603','73841581','73851999','73868112','73877882','73894621','73894776',
  '73897425','73899688','73901932','73904618','73905639','73909245','73909412','73910541','73920348','73922856',
  '73943216','73949549','73973199','73977483','73981575','73984806','73986238','73989933','74001509','74004560',
  '74010065','74019584','74025500','74042354','74043355','74045477','74047111','74066352','74077370','74078137',
  '74113832','74129118','74136282','74140618','74146418','74148265','74153602','74158364','74161913','74164213',
  '74168504','74172143','74173280','74180332','74183858','74194027','74202323','74205425','74215371','74216070',
  '74219029','74219323','74221494','74222535','74225205','74228927','74234875','74239640','74239902','74241132',
  '74241768','74241855','74243118','74247937','74248173','74251259','74255520','74258047','74258669','74261371',
  '74276206','74277584','74286324','74290988','74299987','74302556','74307357','74310997','74314738','74315049',
  '74320572','74338502','74338831','74341590','74349702','74350503','74356211','74362715','74371951','74377536',
  '74379266','74384873','74396024','74402204','74410019','74411008','74416018','74428349','74436910','74439202',
  '74445283','74448325','74454460','74456160','74461961','74477640','74484426','74485816','74489484','74493366',
  '74493397','74493755','74495195','74497191','74498405','74498694','74507577','74513377','74519862','74523604',
  '74524602','74531186','74554602','74555280','74560809','74561156','74565347','74567319','74572084','74575091',
  '74575853','74583958','74584450','74594983','74595113','74597860','74606505','74613333','74613691','74616353',
  '74622495','74635642','74637056','74637905','74644807','74652178','74652296','74652699','74670255','74673511',
  '74673547','74684752','74690713','74691282','74692356','74698350','74701995','74706956','74707601','74709117',
  '74715783','74717749','74722281','74737412','74737448','74744903','74752007','74757573','74765367','74768461',
  '74774823','74783830','74787843','74789431','74793341','74800849','74804102','74813464','74816176','74822541',
  '74823017','74829095','74830136','74837711','74848364','74853167','74864592','74865287','74866853','74870711',
  '74873913','74874711','74876393','74877795','74881906','74890462','74897667','74899992','74906256','74906529',
  '74912719','74919564','74925716','74927418','74934101','74941616','74943982','74944303','74944977','74946540',
  '74950452','74959602','74960710','74960972','74962846','74966722','74968495','74970383','74971416','74975646',
  '74981097','75001387','75005200','75006162','75021213','75024659','75029242','75034231','75034429','75034807',
  '75035099','75037095','75045935','75051842','75056464','75061136','75072291','75078901','75079941','75083856',
  '75084185','75084568','75088157','75088561','75094557','75096058','75097121','75101721','75102174','75104501',
  '75112019','75120310','75120563','75121760','75123197','75125661','75126353','75128194','75131883','75133326',
  '75137163','75138643','75143090','75151520','75156357','75166935','75168743','75169618','75173866','75175060',
  '75175274','75176233','75192921','75193375','75205170','75209949','75211997','75214666','75223257','75227394',
  '75235098','75237238','75237675','75242269','75253938','75260212','75261760','75264134','75278284','75281372',
  '75283159','75286017','75290849','75294071','75308413','75315950','75319962','75323061','75328657','75339994',
  '75350263','75350466','75351202','75351893','75358681','75362564','75362813','75379661','75393295','75393740',
  '75394654','75400748','75406026','75408811','75420786','75431008','75439082','75445095','75446729','75448393',
  '75451262','75455840','75465835','75483322','75490948','75490998','75492187','75495889','75500500','75504069',
  '75508389','75513330','75517937','75519663','75520817','75522633','75529313','75532593','75533667','75536732',
  '75538020','75543972','75555923','75556773','75557867','75560501','75568930','75577344','75589279','75591432',
  '75595847','75597746','75618128','75628493','75629226','75633912','75636683','75648948','75666614','75670503',
  '75683734','75691947','75691959','75702163','75706183','75706729','75707970','75713780','75716569','75716839',
  '75718815','75719018','75719024','75722988','75730436','75736373','75736573','75741811','75743783','75744213',
  '75744687','75747793','75755586','75761199','75764704','75765999','75774550','75789413','75797043','75799306',
  '75799390','75812593','75815951','75820554','75834344','75834579','75838359','75844243','75852691','75867573',
  '75883957','75884010','75885245','75886223','75886561','75891222','75895660','75900517','75907719','75915167',
  '75921086','75922758','75925908','75929559','75939437','75943529','75944576','75948216','75949038','75952482',
  '75957841','75958109','75973373','75974058','75977272','75985756','75988926','75997172','76014627','76015705',
  '76016533','76034218','76039821','76047921','76052200','76054644','76058980','76062518','76065562','76067628',
  '76070477','76070981','76075977','76077597','76078305','76081521','76084736','76088143','76090569','76101485',
  '76103692','76106111','76107320','76107961','76119532','76119792','76121788','76125256','76127525','76142825',
  '76151900','76157262','76158370','76158701','76160821','76162601','76166379','76172979','76178130','76178231',
  '76180996','76196416','76197210','76198471','76201127','76214361','76216149','76234166','76236065','76239018',
  '76239731','76240044','76244913','76249664','76255764','76256723','76263031','76269071','76274153','76275087',
  '76278351','76280759','76299656','76307497','76313068','76313376','76317607','76320203','76326847','76328247',
  '76331001','76334903','76337216','76341463','76346879','76355868','76360862','76364858','76364896','76365059',
  '76365880','76373988','76386486','76396623','76402100','76406277','76414886','76423165','76423736','76427927',
  '76429493','76431010','76436895','76457502','76471874','76476617','76477431','76498156','76498800','76507302',
  '76514200','76519140','76519594','76522457','76524507','76537990','76543672','76563600','76564861','76567989',
  '76568817','76570441','76572382','76572558','76573761','76575124','76575211','76575690','76582563','76585597',
  '76596829','76597196','76599423','76603506','76606107','76619694','76619705','76625736','76625961','76628013',
  '76636668','76636765','76638980','76639092','76639513','76641006','76644830','76651781','76655232','76657718',
  '76665174','76671012','76671376','76674766','76676086','76689011','76693476','76698440','76704723','76711855',
  '76726191','76733288','76749151','76750404','76757944','76758948','76760539','76764475','76767021','76768167',
  '76772821','76775393','76780232','76786920','76790215','76790225','76790403','76794141','76796486','76797375',
  '76810009','76811183','76811900','76814560','76822098','76822538','76825601','76825895','76830824','76834911',
  '76836621','76843053','76849963','76855433','76855514','76857726','76857998','76861726','76870712','76871033',
  '76871722','76877801','76878841','76881724','76882059','76883567','76885990','76892678','76900738','76903246',
  '76907299','76908520','76916750','76918965','76920546','76920641','76924566','76932230','76935427','76937406',
  '76938204','76943203','76945347','76947477','76963554','76964411','76967030','76970396','76971372','76979744',
  '76988400','76990718','76991073','76992754','77002850','77015139','77020275','77025823','77031374','77036266',
  '77052262','77054030','77055033','77057490','77067655','77068038','77075117','77077059','77098685','77117227',
  '77128275','77134869','77139472','77140940','77143913','77147308','77147633','77148064','77152712','77157011',
  '77158175','77158857','77159397','77165521','77167071','77168616','77169626','77172984','77183767','77186088',
  '77190055','77200531','77202752','77211042','77212560','77219105','77220784','77221293','77224517','77231901',
  '77235828','77242040','77244890','77249349','77263576','77264766','77274451','77279416','77280586','77280747',
  '77286261','77288853','77290394','77293599','77294646','77316169','77324653','77325673','77334189','77339047',
  '77346088','77348503','77348766','77349248','77358401','77373384','77375586','77375631','77396334','77398040',
  '77402891','77405172','77422636','77428570','77429748','77432296','77441362','77444928','77451970','77459716',
  '77460402','77475028','77476179','77478319','77486407','77487624','77494077','77495267','77501311','77502271',
  '77506101','77513862','77524577','77526595','77529739','77542368','77542979','77547295','77550026','77552623',
  '77557690','77562670','77568631','77573070','77585182','77587167','77591190','77593284','77606585','77607929',
  '77613622','77615539','77615818','77619080','77626886','77630071','77637959','77638754','77642682','77642751',
  '77652198','77659004','77662975','77672015','77675536','77675746','77683681','77683742','77685122','77687481',
  '77699640','77730922','77731467','77737038','77747989','77752496','77753572','77765658','77766690','77769986',
  '77784158','77790606','77795672','77800214','77800758','77806576','77808941','77812745','77820719','77822731',
  '77827879','77828969','77838347','77848161','77848306','77848872','77855886','77860455','77873090','77886226',
  '77886888','77890045','77901202','77904901','77908291','77919731','77921304','77923687','77935392','77941313',
  '77945533','77952487','77962223','77963985','77965012','77968328','77969571','77971375','77972117','77977474',
  '77978273','77990945','77994785','77997817','78009294','78020824','78032920','78035184','78035959','78038177',
  '78040654','78046959','78051904','78056064','78063157','78069706','78073239','78074758','78076521','78080088',
  '78080320','78081838','78082028','78085802','78090871','78097712','78107769','78109001','78118167','78128163',
  '78132420','78134423','78138729','78145333','78146330','78157550','78161167','78163781','78167845','78169670',
  '78171032','78172197','78175071','78179506','78180166','78182812','78183609','78190834','78192511','78192602',
  '78224678','78225939','78226783','78231895','78233414','78238835','78251241','78256446','78269986','78275580',
  '78280047','78285520','78287999','78293098','78293986','78299516','78302076','78306987','78316699','78321602',
  '78325060','78326987','78328509','78346975','78356209','78357758','78365468','78366529','78380956','78385011',
  '78389318','78394753','78397525','78406715','78408636','78416516','78420898','78427156','78429522','78429772',
  '78433572','78444716','78451425','78453460','78460133','78467884','78471244','78472817','78473216','78475334',
  '78475881','78486142','78486278','78490834','78494164','78494169','78495686','78501036','78505344','78507177',
  '78513010','78513381','78514940','78515702','78516194','78520140','78528498','78533626','78534082','78538934',
  '78539333','78541386','78542730','78544021','78546070','78547152','78548317','78548415','78550674','78552047',
  '78552829','78563737','78563885','78567341','78568756','78570626','78571751','78584013','78584960','78587645',
  '78592160','78592534','78595601','78599267','78602035','78617717','78618484','78625067','78625883','78630997',
  '78631310','78631613','78634252','78635871','78637865','78651122','78651838','78655932','78662126','78670098',
  '78670140','78693380','78698796','78698802','78707626','78708406','78719484','78721173','78721837','78724734',
  '78730999','78733113','78736597','78740615','78741356','78744097','78747054','78749566','78755247','78763313',
  '78772494','78773494','78804407','78808159','78809001','78810275','78816423','78825991','78827111','78842324',
  '78845781','78846214','78849921','78850847','78853202','78853757','78853909','78855808','78860108','78867981',
  '78882540','78883773','78889992','78900852','78909856','78913278','78916140','78917750','78918103','78918750',
  '78920809','78926780','78933508','78934034','78939256','78941205','78945855','78952300','78954698','78963008',
  '78984855','78989076','78995638','78999776','79001207','79008852','79016604','79019676','79021734','79028125',
  '79028216','79029718','79033109','79034318','79036208','79040188','79042494','79045405','79050853','79051184',
  '79053727','79068686','79075441','79078744','79095434','79097642','79119389','79124724','79144198','79147862',
  '79157730','79165577','79167647','79169933','79170914','79177163','79181312','79181479','79181662','79184131',
  '79199951','79200221','79202214','79204386','79206500','79207137','79211680','79217004','79217590','79221228',
  '79223361','79226738','79236202','79239419','79250828','79255773','79259342','79263089','79265001','79273873',
  '79288879','79297866','79305737','79311032','79317816','79319974','79329517','79337630','79346995','79351856',
  '79355003','79359896','79378294','79378870','79386536','79387886','79389808','79393161','79394365','79400296',
  '79401887','79402393','79403242','79406200','79410705','79419726','79419889','79423321','79424808','79428220',
  '79433880','79439144','79453240','79454642','79455102','79458123','79458424','79469054','79478657','79480463',
  '79505563','79518649','79523913','79539775','79543502','79546436','79547763','79548055','79555201','79555862',
  '79561237','79562485','79564298','79572333','79576676','79590499','79600903','79605693','79607282','79608727',
  '79609863','79624481','79625709','79625748','79631847','79639003','79640609','79641444','79653118','79660331',
  '79669118','79678971','79680163','79683157','79685070','79686105','79697660','79698334','79703397','79717846',
  '79719170','79720144','79720787','79727907','79735844','79742222','79742763','79747771','79748591','79755113',
  '79759057','79760876','79763046','79776630','79777042','79779138','79788255','79790707','79792899','79807376',
  '79810433','79813112','79823295','79834643','79835329','79836129','79837490','79845936','79846607','79847877',
  '79851439','79857048','79857461','79859228','79863018','79863433','79867046','79877660','79880785','79885180',
  '79893912','79896191','79897952','79901542','79912702','79915267','79919298','79919912','79920098','79928091',
  '79930457','79931823','79940423','79941911','79948179','79948312','79950996','79951849','79963534','79964887',
  '79965312','79967425','79968653','79971128','79978174','79978846','79982286','79986770','79994972','79995314',
  '79998556','79998873','80008544','80018201','80022876','80028587','80034181','80040066','80046339','80046593',
  '80047729','80050282','80057817','80060670','80060808','80063766','80064276','80067540','80071723','80074054',
  '80077867','80087575','80089343','80091825','80093939','80095429','80099207','80099336','80101434','80107016',
  '80107336','80128948','80134314','80139957','80141784','80154624','80157674','80157758','80160468','80163034',
  '80163592','80166731','80167954','80171538','80176860','80178427','80186129','80186634','80191621','80192381',
  '80193495','80197310','80200219','80200740','80202541','80220611','80220887','80226568','80231046','80246444',
  '80246763','80248310','80262369','80268733','80272497','80287431','80297832','80302299','80304113','80305493',
  '80307874','80309046','80315438','80317408','80336441','80338706','80344582','80355544','80356972','80358412',
  '80362045','80371638','80379924','80380657','80385165','80387445','80393440','80394126','80395424','80399344',
  '80401565','80404646','80406288','80406898','80409834','80413617','80427858','80427869','80435238','80436473',
  '80439081','80439257','80440862','80443956','80447114','80448473','80449084','80453227','80456158','80459615',
  '80459734','80461514','80478123','80478657','80486213','80488525','80498501','80498770','80503497','80508471',
  '80522187','80535003','80543091','80549513','80553775','80555151','80556538','80565456','80574754','80577388',
  '80581670','80583560','80589262','80597224','80598719','80603391','80615017','80616930','80620962','80630292',
  '80646578','80646862','80647086','80648469','80653745','80655722','80657735','80664427','80665028','80670222',
  '80670768','80675814','80678653','80678787','80683775','80688296','80692023','80695965','80702850','80703300',
  '80705035','80717124','80720572','80720694','80726233','80732114','80737593','80749979','80750708','80755002',
  '80767004','80769813','80770608','80782321','80794359','80805868','80809150','80809961','80811834','80815684',
  '80819463','80821677','80824719','80827557','80831405','80834619','80840560','80842205','80847428','80866390',
  '80874462','80877512','80884362','80885152','80892366','80895351','80897018','80905725','80908426','80909073',
  '80913846','80939805','80941384','80944322','80947392','80952731','80952925','80958784','80964345','80968294',
  '80976350','80979075','80980485','80981647','80983148','80986759','81002713','81005537','81005676','81007194',
  '81010798','81019590','81028310','81031604','81042439','81047669','81055094','81063171','81066021','81067768',
  '81070759','81084804','81086031','81086231','81090907','81095194','81096497','81098123','81100571','81116830',
  '81124708','81129652','81143450','81153120','81157485','81159052','81166606','81168627','81168964','81171345',
  '81176580','81185746','81186342','81189355','81189992','81200657','81214193','81221818','81234074','81250723',
  '81251988','81252817','81261598','81276849','81277558','81280080','81281164','81284267','81285360','81285815',
  '81289513','81291859','81291990','81299893','81303221','81310643','81319012','81322872','81324697','81326188',
  '81327650','81329534','81334360','81337775','81340541','81347334','81348492','81353740','81356736','81359346',
  '81359979','81360253','81384826','81394673','81396163','81399239','81399691','81409769','81410759','81417134',
  '81419305','81444244','81445645','81450773','81451925','81451991','81453441','81453621','81470449','81472230',
  '81476991','81490167','81491331','81495904','81501937','81519577','81529410','81530095','81531759','81535013',
  '81544244','81545782','81548714','81553682','81561460','81566664','81570878','81580954','81584114','81586296',
  '81588133','81590111','81591545','81612793','81613865','81615739','81616457','81628874','81631071','81631184',
  '81639598','81644136','81645133','81649302','81652029','81654630','81660129','81661612','81665512','81666500',
  '81678012','81685472','81685474','81688018','81693888','81698161','81699114','81701669','81712123','81717996',
  '81730270','81731150','81736633','81753366','81754985','81755006','81771221','81776978','81779142','81779165',
  '81782838','81786994','81796077','81796132','81804715','81808272','81810111','81812071','81825863','81832639',
  '81842046','81846424','81849253','81852556','81853881','81871726','81877258','81896852','81905216','81916308',
  '81918683','81919128','81924437','81925482','81930691','81932986','81934350','81934717','81940528','81950838',
  '81962266','81965776','81965811','81969547','81986130','81986850','81988957','81994155','81999449','82003905',
  '82004679','82009734','82014526','82015843','82019491','82023502','82030675','82049741','82050504','82050757',
  '82052937','82053971','82057219','82058025','82066801','82076850','82080563','82086367','82088884','82093486',
  '82093681','82107822','82112834','82117990','82121350','82121694','82133598','82133835','82155201','82165467',
  '82166883','82167567','82169594','82169800','82178469','82183919','82184309','82193913','82194435','82195225',
  '82200671','82205713','82207439','82212278','82216170','82218158','82218547','82225423','82229022','82232223',
  '82245430','82253590','82261866','82283943','82285743','82291028','82293974','82309840','82310167','82313989',
  '82320813','82324055','82334687','82341986','82345232','82345701','82346137','82348274','82355297','82355436',
  '82362550','82365241','82369223','82376806','82379670','82394898','82397511','82406251','82406642','82407097',
  '82408995','82409825','82410633','82411644','82421480','82421592','82426706','82427138','82428423','82430044',
  '82432567','82434562','82439356','82443376','82443885','82452575','82454977','82469283','82470066','82477666',
  '82483612','82484077','82493224','82494349','82499027','82499191','82500614','82502685','82503289','82504170',
  '82510923','82513503','82523836','82524241','82530401','82533008','82544428','82547185','82554618','82559653',
  '82568935','82570281','82571255','82576207','82591606','82592987','82594135','82598700','82608112','82610419',
  '82612972','82622497','82642097','82642529','82644364','82648025','82655988','82663019','82663795','82666746',
  '82672932','82673588','82674191','82676109','82677203','82678610','82680569','82684758','82686833','82695854',
  '82696736','82701392','82703864','82705953','82706090','82708375','82711768','82714838','82715382','82715632',
  '82719051','82721725','82726218','82731486','82733300','82736513','82737356','82739481','82739976','82741069',
  '82743653','82745341','82748961','82752743','82754412','82761949','82765401','82766235','82770398','82772100',
  '82773227','82774133','82795756','82798557','82804710','82807170','82810771','82814427','82826849','82830719',
  '82835264','82837280','82839150','82839262','82840878','82845667','82848833','82858591','82863337','82865257',
  '82865873','82867082','82868792','82880126','82880731','82883434','82893006','82897078','82907326','82907627',
  '82908731','82910477','82911506','82915334','82917127','82928124','82934290','82937481','82941897','82942374',
  '82945401','82948551','82952356','82964349','82968903','82983180','82987535','83003637','83006281','83007367',
  '83013260','83013898','83018519','83030460','83047149','83050732','83055406','83067584','83069047','83077882',
  '83079795','83085061','83096479','83098914','83111052','83120172','83124060','83126567','83130791','83132754',
  '83146170','83146419','83150539','83157712','83160821','83161654','83170231','83170394','83171650','83177486',
  '83180005','83181671','83188046','83190783','83190928','83194060','83197031','83201686','83205460','83210041',
  '83220013','83238092','83239566','83241227','83241949','83247854','83261214','83272447','83282876','83286658',
  '83290414','83308905','83310007','83319689','83322919','83323341','83325912','83332605','83338715','83343152',
  '83348846','83349778','83349962','83350348','83363226','83375351','83378035','83378774','83391130','83396589',
  '83404291','83406030','83406602','83412607','83416618','83422168','83423059','83423190','83425469','83428449',
  '83431535','83440523','83444383','83446275','83466385','83469462','83470601','83479179','83480116','83485764',
  '83503403','83507503','83511234','83513110','83518204','83520252','83524798','83525816','83526070','83532691',
  '83557658','83558005','83559470','83560110','83560889','83564643','83569592','83574267','83582797','83583629',
  '83590504','83590941','83597199','83603882','83608155','83623120','83624309','83636253','83655555','83660086',
  '83668936','83671870','83677107','83678512','83680833','83691029','83691305','83693400','83695795','83704654',
  '83708696','83709480','83721412','83724749','83726071','83730985','83751879','83775093','83781002','83782811',
  '83790473','83793196','83794236','83804894','83805060','83815824','83817250','83822464','83826423','83851594',
  '83860069','83860814','83872979','83878116','83879687','83897087','83901123','83903564','83906871','83909701',
  '83921059','83925507','83927909','83937921','83939484','83942477','83950691','83959820','83982625','83987702',
  '83989883','83990589','83990952','84003670','84005175','84039947','84047979','84048458','84050639','84052516',
  '84054140','84054288','84061878','84072806','84086924','84091473','84094295','84109099','84114892','84116087',
  '84126650','84128155','84128634','84156524','84160475','84173330','84176337','84180674','84181899','84182922',
  '84183082','84191447','84195104','84197398','84198762','84198910','84199938','84208242','84210491','84212815',
  '84217114','84221232','84223074','84225808','84226968','84238159','84246461','84250958','84255206','84262112',
  '84265241','84270148','84270526','84277546','84278048','84279912','84287404','84290940','84292575','84301945',
  '84313347','84317048','84318602','84320524','84320782','84324020','84330551','84332998','84333388','84347320',
  '84347767','84349627','84363480','84364865','84369148','84372914','84376751','84377865','84378051','84388797',
  '84390586','84402503','84402505','84405080','84409660','84419572','84422503','84424658','84425268','84426812',
  '84441366','84441749','84445782','84447571','84453999','84468127','84476533','84477533','84479006','84485229',
  '84490404','84492115','84494740','84498155','84501685','84512157','84513160','84518555','84523021','84526323',
  '84527282','84527463','84537148','84545601','84551234','84569729','84571051','84577139','84578804','84582700',
  '84586717','84588632','84590410','84595520','84597999','84606083','84611643','84617935','84619942','84621139',
  '84622640','84626972','84627314','84631591','84639501','84655792','84663785','84673660','84679059','84680903',
  '84685660','84685972','84686180','84699653','84707753','84708624','84712268','84715600','84726338','84728991',
  '84730043','84732647','84748258','84754003','84756617','84766922','84776681','84778739','84784579','84787191',
  '84801546','84815425','84819230','84824140','84837123','84839937','84843580','84847625','84859394','84876249',
  '84880691','84883470','84898665','84899588','84907413','84909534','84919164','84925386','84926664','84927838',
  '84929010','84929976','84932022','84935231','84938203','84950043','84950711','84954975','84955253','84955482',
  '84959826','84961442','84965674','84979614','84983602','84984552','84991137','84991169','84998125','84999529',
  '85008671','85011247','85012554','85014380','85017994','85043344','85046479','85061926','85065004','85065217',
  '85072755','85072808','85087375','85088210','85095757','85102234','85116347','85120340','85124522','85127539',
  '85129707','85144268','85150847','85151525','85152940','85163201','85163234','85166931','85170362','85171174',
  '85181206','85181709','85182641','85184253','85184726','85187694','85194079','85195408','85197469','85197786',
  '85201424','85202272','85211132','85215288','85218672','85219393','85220038','85225296','85236538','85242771',
  '85244364','85245053','85252272','85256625','85260951','85266813','85266828','85267382','85271340','85285148',
  '85287708','85293206','85293479','85294888','85302194','85314163','85315848','85319861','85326762','85339173',
  '85343854','85344391','85360945','85370804','85382735','85383361','85389220','85404457','85412032','85423645',
  '85424721','85427438','85427585','85434926','85435510','85439394','85446393','85447194','85457314','85462601',
  '85468206','85473168','85473230','85476903','85477346','85477491','85489173','85489233','85491233','85500930',
  '85505549','85511682','85513553','85513838','85514345','85522263','85522473','85530103','85531285','85535866',
  '85536756','85537742','85569816','85581693','85587993','85592535','85595627','85599174','85601539','85607564',
  '85608008','85610669','85611511','85617355','85620327','85624278','85637174','85638394','85638429','85638736',
  '85645507','85645878','85653108','85655345','85656137','85674649','85685403','85702390','85704556','85707052',
  '85709524','85710815','85713408','85714177','85714648','85716556','85721216','85722247','85730052','85733003',
  '85736624','85739174','85745201','85756583','85759918','85761983','85780650','85781157','85787120','85791143',
  '85804773','85805159','85813398','85816079','85818154','85818966','85821230','85826037','85827811','85828123',
  '85831772','85832977','85835006','85855447','85868316','85872854','85876645','85878648','85883371','85887551',
  '85888837','85893860','85894326','85895884','85898664','85900956','85902132','85902606','85912513','85919382',
  '85921346','85921894','85932389','85933164','85933716','85945093','85947727','85954474','85956897','85958821',
  '85965194','85967651','85971458','85975959','85976688','85987888','85991055','85992690','86002488','86004173',
  '86007553','86029280','86043748','86044258','86045000','86049088','86059314','86061082','86062377','86068146',
  '86070455','86072148','86074541','86076479','86077520','86077677','86077777','86083471','86087270','86101172',
  '86102312','86105952','86110659','86114817','86118477','86146793','86152562','86167229','86173058','86174518',
  '86196804','86198241','86203112','86205919','86216940','86217142','86223517','86227400','86227955','86228880',
  '86230586','86231661','86236295','86239568','86239766','86241144','86241858','86249020','86250122','86253652',
  '86253783','86271566','86274119','86279087','86281541','86293236','86304760','86306128','86307387','86307850',
  '86314570','86314961','86315664','86335143','86342730','86349486','86351263','86355152','86358512','86365034',
  '86366879','86380882','86383520','86389990','86394516','86396738','86399873','86405750','86407692','86408933',
  '86409168','86410906','86420736','86421557','86422122','86427558','86429648','86430695','86432300','86438052',
  '86442039','86459921','86466464','86467592','86474478','86484303','86488160','86488353','86490384','86493071',
  '86497236','86503894','86506689','86510272','86511356','86512038','86515735','86519618','86521406','86521447',
  '86531500','86542748','86551399','86554372','86554882','86571064','86571639','86575623','86580499','86593664',
  '86606338','86610262','86626134','86637485','86641053','86650394','86654060','86659926','86663371','86671209',
  '86680720','86689002','86693940','86695581','86697397','86704148','86704732','86705807','86706077','86710221',
  '86712947','86713775','86725830','86727245','86730463','86739316','86740110','86748743','86753631','86768426',
  '86784072','86784766','86787408','86791886','86798955','86802885','86807554','86807935','86809284','86813574',
  '86814167','86815179','86815384','86831999','86834552','86836841','86838295','86838697','86846322','86847259',
  '86854919','86855336','86861418','86872211','86879540','86880523','86886649','86896373','86913202','86914573',
  '86916429','86920936','86922720','86923333','86924967','86935723','86935877','86937173','86938272','86946470',
  '86947130','86949829','86953437','86978171','86982184','86982526','86994322','87000820','87002351','87007604',
  '87012330','87012785','87016834','87020433','87023949','87027908','87031416','87043606','87044332','87054653',
  '87055222','87061035','87074284','87075627','87079122','87086246','87086502','87087157','87091745','87098353',
  '87101523','87102973','87115943','87116574','87120819','87122596','87128229','87128331','87133024','87133312',
  '87144145','87148210','87148375','87159765','87176293','87177199','87187962','87190143','87195156','87195204',
  '87200204','87232487','87232905','87235854','87240356','87241911','87242325','87250164','87255905','87285602',
  '87286729','87296748','87304174','87311358','87335548','87371276','87381908','87382327','87388867','87389572',
  '87395300','87399066','87413402','87415193','87418521','87423615','87428961','87433519','87437700','87443110',
  '87445210','87445852','87455948','87457959','87459461','87459981','87481475','87488098','87490658','87493753',
  '87498366','87500884','87502288','87505858','87513898','87522973','87525984','87532250','87542682','87546152',
  '87548096','87554208','87565889','87582654','87586446','87594807','87597007','87597494','87598398','87607836',
  '87615688','87617303','87623035','87624781','87629247','87629957','87632823','87633635','87634330','87645485',
  '87645493','87649167','87661434','87665599','87667220','87671725','87673993','87682303','87687705','87691806',
  '87696380','87696883','87696887','87698446','87714305','87714421','87723469','87725172','87725312','87728960',
  '87729746','87732235','87745960','87750106','87757910','87758286','87758288','87763630','87779597','87795979',
  '87797457','87797962','87803318','87817167','87817950','87823355','87828197','87836021','87837434','87839528',
  '87840270','87852536','87870032','87872060','87876848','87877201','87877226','87880814','87881929','87884105',
  '87887540','87897141','87911338','87920117','87921890','87923350','87930843','87937486','87939844','87941262',
  '87943398','87944236','87956326','87970603','87974909','87988250','87993899','87996863','88005858','88006457',
  '88010345','88011259','88029233','88034684','88037032','88052422','88060807','88065679','88068833','88071548',
  '88084729','88087677','88097516','88102928','88106707','88109158','88110997','88118806','88125653','88131520',
  '88151410','88154343','88155268','88169503','88184824','88186284','88187710','88194662','88205467','88214024',
  '88222916','88223882','88224588','88226156','88226198','88229078','88238074','88240667','88248078','88249508',
  '88255229','88267507','88272776','88274914','88292776','88296428','88314966','88316380','88316990','88318171',
  '88325315','88335335','88337762','88345656','88349821','88353106','88354367','88363724','88368230','88371459',
  '88383986','88388603','88390970','88394891','88398706','88399448','88413023','88414822','88427717','88431566',
  '88432226','88440691','88441071','88443442','88444247','88449001','88449283','88449433','88463710','88469826',
  '88471259','88471804','88472804','88480392','88483511','88494442','88502473','88502579','88507098','88515346',
  '88517288','88518230','88534168','88544654','88550564','88552636','88556660','88560130','88569354','88571875',
  '88572382','88576552','88581610','88584939','88589656','88591569','88621894','88625640','88629507','88639053',
  '88644494','88652231','88670368','88678319','88679029','88680208','88723826','88725834','88726703','88730491',
  '88742556','88750313','88754029','88754099','88757497','88757965','88767010','88768628','88778720','88785169',
  '88789057','88790009','88794525','88804426','88806323','88808651','88812271','88816693','88823461','88834615',
  '88839906','88840808','88841717','88841753','88842554','88851048','88856794','88858345','88866513','88868523',
  '88869495','88872357','88873535','88874433','88880831','88881096','88898272','88904816','88905440','88909974',
  '88929546','88942560','88942890','88953755','88965333','88978960','88983111','88984094','88986034','88990076',
  '89005053','89005676','89007658','89021131','89022264','89027448','89027513','89028366','89038880','89042052',
  '89048188','89049630','89053478','89057387','89059311','89064138','89064372','89066797','89072056','89072930',
  '89086421','89087495','89094706','89104840','89107276','89114776','89119227','89125960','89126676','89129476',
  '89140186','89140404','89144674','89146537','89151230','89152625','89156810','89163621','89165084','89175783',
  '89201804','89212590','89213921','89214343','89219282','89222209','89227100','89227583','89230094','89233521',
  '89247497','89256309','89260165','89262493','89268009','89270516','89298803','89300173','89302620','89303562',
  '89305028','89312937','89319388','89324363','89329547','89344391','89356378','89360719','89369877','89372661',
  '89372843','89373596','89384964','89395681','89396208','89397422','89402192','89402398','89407127','89409016',
  '89410120','89415642','89423866','89426657','89427251','89427927','89429444','89438975','89440033','89445526',
  '89452174','89457865','89460939','89468824','89474429','89480564','89481197','89481880','89484760','89486760',
  '89491587','89511304','89512957','89514200','89515577','89525031','89526642','89528157','89535318','89538614',
  '89545638','89552277','89552891','89556032','89556867','89575408','89575425','89576314','89581269','89581693',
  '89582553','89589211','89594251','89595923','89602811','89607724','89610359','89633059','89640231','89640421',
  '89645040','89645334','89658567','89672398','89673016','89683415','89684394','89699780','89700964','89705462',
  '89711749','89730918','89734492','89735791','89744813','89747031','89748260','89754850','89761599','89762352',
  '89762370','89769570','89777648','89779214','89798990','89805043','89818170','89818991','89820572','89834868',
  '89836439','89837813','89839866','89842604','89846316','89867470','89873074','89877108','89906225','89915992',
  '89916046','89917576','89919398','89932785','89937237','89949273','89949416','89960894','89961034','89964064',
  '89968393','89983794','89995250','90004422','90019464','90023594','90024121','90030189','90030480','90031626',
  '90033864','90034431','90037249','90046287','90047909','90047915','90054434','90059262','90076423','90084273',
  '90086499','90103183','90105730','90106158','90106954','90107259','90111343','90117190','90118258','90129178',
  '90129915','90132949','90134106','90155387','90157303','90168104','90180526','90185631','90187596','90189108',
  '90190062','90192465','90192655','90202462','90204572','90208969','90214387','90219886','90221395','90233253',
  '90240749','90242569','90252294','90255338','90260329','90275721','90278021','90287926','90301926','90307043',
  '90312077','90336417','90339471','90340785','90342787','90348269','90353639','90357427','90357472','90369996',
  '90375279','90382838','90384340','90387985','90391170','90395552','90395713','90399635','90406234','90407948',
  '90411971','90416903','90421790','90427677','90428802','90431564','90434424','90435518','90446958','90448297',
  '90463451','90465046','90472289','90472493','90474489','90475591','90476770','90479968','90484521','90490574',
  '90491830','90492088','90496467','90501434','90501918','90508696','90521042','90521794','90522879','90522997',
  '90525489','90539271','90552690','90557142','90562506','90565900','90571389','90571702','90572579','90577339',
  '90594814','90607388','90608051','90612329','90612735','90617146','90623283','90637451','90643638','90649031',
  '90655970','90664294','90664911','90674246','90675018','90675056','90680095','90690498','90693675','90694735',
  '90695511','90701130','90704233','90712741','90720444','90724154','90732760','90735510','90736964','90743951',
  '90750691','90754380','90756231','90756471','90758358','90758510','90770996','90774953','90776357','90784548',
  '90794061','90796001','90801157','90810667','90812955','90813741','90820490','90827770','90833642','90839817',
  '90841885','90844154','90861296','90869676','90870005','90873580','90873828','90875946','90881830','90890826',
  '90900599','90917175','90918632','90918993','90923091','90924287','90929406','90929647','90950448','90953211',
  '90953430','90963299','90969397','90985153','90989859','90992064','91002722','91019613','91040217','91046978',
  '91048646','91049631','91051568','91051662','91064378','91070762','91079333','91079472','91081990','91084360',
  '91089552','91089782','91114403','91119763','91121314','91127604','91133259','91144326','91147089','91151421',
  '91151890','91157846','91169779','91170310','91173680','91182542','91186634','91193348','91193837','91194150',
  '91201556','91206474','91207845','91209728','91216236','91225796','91231723','91239504','91243621','91246265',
  '91247469','91250245','91251986','91265586','91270402','91283518','91298841','91299090','91305954','91306246',
  '91320717','91322320','91322651','91324953','91343414','91344049','91345994','91346273','91346425','91349914',
  '91351878','91353255','91356572','91362146','91369843','91370584','91374421','91388577','91390386','91398727',
  '91400704','91401917','91404417','91405176','91407626','91415773','91420907','91421927','91423666','91425531',
  '91444223','91450320','91464314','91469086','91474147','91476239','91477604','91480243','91482163','91488530',
  '91489328','91490619','91494859','91502199','91505972','91519264','91521873','91525554','91536968','91541089',
  '91543069','91558420','91567740','91570457','91573405','91613360','91614958','91622259','91625429','91639472',
  '91641666','91646866','91647847','91648956','91651850','91657759','91666983','91667575','91671775','91674141',
  '91680949','91688742','91689681','91700099','91701816','91703062','91707677','91711905','91712976','91715531',
  '91718226','91726652','91727013','91738820','91750211','91750765','91752755','91756690','91756999','91761573',
  '91763040','91764960','91765819','91773261','91787426','91789733','91794796','91800175','91806374','91808120',
  '91809055','91809780','91810720','91817214','91818695','91819352','91826601','91832042','91833025','91833920',
  '91834115','91840761','91845376','91845790','91854583','91857528','91880188','91884708','91888128','91890966',
  '91891387','91891595','91895136','91898393','91902129','91906918','91912676','91924730','91937330','91938090',
  '91938718','91943236','91946406','91946839','91959072','91959946','91963916','91969345','91970063','91975959',
  '91977735','91980030','91982913','91988743','91989464','91995264','91995681','91999542','92000324','92003917',
  '92006888','92018712','92027048','92037048','92038036','92038053','92041909','92048348','92050973','92060302',
  '92073153','92074046','92076905','92077475','92081386','92082934','92087593','92088101','92093727','92096277',
  '92106746','92108144','92111054','92113531','92114783','92118034','92136464','92137640','92139357','92144884',
  '92156487','92160212','92170684','92173672','92174777','92176164','92205843','92218035','92219407','92219982',
  '92226954','92227422','92228125','92229422','92229458','92239261','92248096','92250237','92262866','92263082',
  '92266407','92272162','92273785','92281198','92285323','92286151','92292671','92306378','92308014','92308263',
  '92311011','92312180','92315136','92316494','92321910','92322116','92326436','92327736','92329194','92332926',
  '92335489','92340307','92346720','92358109','92358825','92363181','92377879','92382129','92385368','92388968',
  '92389948','92390957','92398744','92399816','92400758','92403178','92403206','92409176','92412792','92415464',
  '92415981','92416928','92432246','92446421','92448443','92466597','92474687','92479183','92481432','92490597',
  '92493742','92496104','92497833','92503283','92512473','92524524','92526002','92536341','92546494','92548174',
  '92562560','92565800','92570449','92577912','92582508','92588981','92592915','92593435','92596902','92603772',
  '92604839','92606816','92609717','92618014','92619023','92625608','92625967','92627646','92628042','92630571',
  '92634566','92641906','92648244','92669866','92673900','92674406','92679869','92683395','92687349','92692482',
  '92698851','92705312','92714802','92716343','92718089','92725893','92726724','92729676','92734593','92740472',
  '92749008','92753342','92765177','92765716','92781151','92782494','92783515','92784478','92788425','92792235',
  '92796569','92815037','92823338','92826004','92827645','92840460','92844719','92851594','92854142','92854454',
  '92856674','92873643','92875139','92876377','92878373','92886212','92887746','92892759','92894678','92897701',
  '92898120','92907282','92913611','92914393','92918898','92924029','92930823','92934758','92937038','92941997',
  '92942729','92943885','92946458','92957440','92972993','92973381','92973401','92978160','92991089','92991861',
  '92992792','92995972','92998534','93001385','93013293','93027951','93041245','93041392','93047256','93048243',
  '93049966','93050797','93052836','93058576','93060087','93060255','93062726','93063882','93067674','93073849',
  '93097083','93100896','93101563','93102442','93102586','93109749','93111414','93114107','93115146','93117313',
  '93126368','93127002','93129078','93136862','93137057','93138139','93139064','93143172','93153020','93160252',
  '93162833','93167582','93172378','93178717','93183156','93190126','93198973','93202580','93213304','93219552',
  '93222161','93222412','93239459','93245244','93253956','93262959','93263335','93268710','93273702','93275417',
  '93275854','93282404','93282757','93284460','93291462','93291869','93297065','93303789','93307850','93310707',
  '93318739','93324832','93336591','93336623','93339556','93342263','93349532','93350902','93355199','93361521',
  '93365243','93376414','93378753','93380235','93383638','93385257','93390299','93400427','93400600','93406862',
  '93416350','93423092','93429695','93435220','93437957','93439661','93449680','93450584','93451050','93452337',
  '93469342','93476640','93477114','93489942','93490273','93490895','93502713','93510871','93516845','93517588',
  '93518434','93521363','93521759','93521786','93525468','93529831','93530186','93551534','93553921','93554448',
  '93556055','93559437','93563959','93566281','93571212','93571658','93574457','93588323','93590459','93590759',
  '93595115','93597018','93598711','93615445','93626591','93632577','93636070','93646799','93658147','93661308',
  '93663375','93683180','93685985','93686485','93692864','93696336','93699044','93700543','93704137','93715490',
  '93715553','93718023','93722234','93722704','93725822','93733031','93734693','93739740','93752822','93756407',
  '93760260','93763503','93766287','93766787','93773633','93780179','93785012','93789378','93795102','93796283',
  '93796874','93798834','93805715','93806928','93813871','93814607','93819862','93821061','93822392','93825060',
  '93827197','93828343','93830275','93838290','93840746','93844930','93847901','93853624','93858017','93858389',
  '93862143','93867950','93876120','93878079','93881107','93885269','93891410','93894897','93897777','93899551',
  '93901260','93910457','93910494','93912549','93917239','93923086','93928240','93929433','93940787','93943035',
  '93947930','93948605','93950883','93955691','93962880','93966356','93981538','93989083','93989513','93991039',
  '94009973','94022633','94025035','94035944','94041104','94043587','94049088','94051892','94060437','94064990',
  '94069704','94074920','94075341','94076879','94081144','94085515','94098378','94108319','94112104','94116008',
  '94118087','94126166','94130755','94140940','94143127','94146681','94151657','94155565','94164844','94165182',
  '94169395','94169616','94173840','94175749','94180107','94182185','94185852','94186558','94188774','94191920',
  '94194350','94194641','94200931','94204095','94204908','94207594','94222677','94225619','94241065','94250836',
  '94251380','94253052','94262114','94265591','94266380','94289008','94289488','94291049','94294324','94301122',
  '94303985','94307142','94311647','94322904','94323565','94326935','94330768','94336642','94339205','94354066',
  '94358449','94358612','94361509','94364950','94371486','94388050','94390048','94395525','94405739','94408968',
  '94411759','94416233','94419326','94419447','94421914','94422283','94425313','94432607','94450434','94467025',
  '94486780','94494315','94496436','94498431','94501128','94509466','94518346','94520892','94525035','94539555',
  '94545465','94545882','94547857','94559041','94569549','94570276','94571148','94573381','94584129','94595048',
  '94599674','94608569','94612756','94615117','94615685','94621400','94635357','94643980','94659879','94665988',
  '94673868','94674262','94690145','94697377','94709303','94713962','94719046','94720224','94723028','94730286',
  '94730451','94730740','94738463','94740079','94746033','94748824','94751250','94761082','94763945','94764085',
  '94765574','94768404','94778295','94780211','94790630','94790765','94798065','94800057','94802087','94802802',
  '94804385','94810082','94811312','94816872','94822888','94825147','94825399','94827109','94829939','94832619',
  '94836029','94854678','94859309','94861897','94868558','94874909','94879452','94879608','94884682','94889769',
  '94889926','94891727','94892317','94893418','94894023','94894592','94900194','94902081','94903234','94903573',
  '94907600','94917397','94918968','94922492','94926179','94929922','94932271','94935577','94949918','94970598',
  '94973887','94975182','94982231','94985507','94991699','94996296','94997853','94998632','95001788','95002431',
  '95007812','95008922','95011767','95013582','95020869','95027035','95027481','95029538','95042917','95052026',
  '95066602','95068387','95073617','95080573','95092033','95093647','95093782','95094973','95109793','95121577',
  '95137497','95144654','95157408','95159968','95164691','95165222','95165677','95171368','95188266','95189350',
  '95200996','95205793','95226490','95232084','95238191','95242037','95246831','95260709','95274557','95277057',
  '95278856','95286198','95289491','95295020','95305762','95324871','95332236','95333713','95333773','95336233',
  '95341605','95347911','95356722','95358177','95358646','95363392','95365980','95367198','95369647','95371872',
  '95373690','95380132','95380583','95381157','95389140','95401927','95402329','95408721','95409419','95410429',
  '95418814','95420366','95421214','95424280','95426663','95437898','95438997','95445461','95449676','95450329',
  '95452141','95452488','95452990','95464054','95472231','95473191','95478995','95479013','95480922','95483562',
  '95484598','95490160','95492912','95505193','95505445','95512345','95512958','95514110','95529644','95537532',
  '95546769','95575436','95577577','95584526','95591526','95595300','95602770','95616448','95616910','95617797',
  '95621759','95629937','95630255','95632391','95639453','95650252','95655312','95656385','95657311','95659921',
  '95697813','95701941','95704180','95706824','95718048','95727384','95731850','95738852','95740183','95743710',
  '95753543','95754867','95775521','95778682','95779267','95779960','95785174','95787329','95791208','95802412',
  '95818523','95820685','95823185','95825850','95827700','95829787','95830985','95833858','95834686','95837233',
  '95857409','95865931','95869505','95870727','95877332','95878393','95882890','95891970','95896416','95897909',
  '95903618','95906512','95911840','95912822','95914083','95914705','95917500','95918348','95923144','95930906',
  '95945442','95953523','95955776','95964761','95968145','95975148','95977679','95979783','95980139','95995228',
  '95997365','96003106','96009120','96018916','96021708','96023802','96027910','96029577','96031368','96035805',
  '96043617','96044482','96047302','96048450','96053085','96062908','96068662','96078633','96080071','96080898',
  '96085346','96086640','96086742','96096810','96098416','96099761','96109904','96114374','96121395','96132727',
  '96142393','96160932','96161822','96167579','96176661','96183914','96185314','96185328','96187009','96192942',
  '96196659','96198664','96201524','96203090','96211411','96215603','96216206','96217875','96225554','96236340',
  '96244241','96252665','96253933','96257658','96263520','96276759','96287107','96310848','96324079','96327712',
  '96335293','96339169','96341825','96342131','96344218','96361928','96364447','96375202','96377708','96379281',
  '96383956','96386961','96390422','96393236','96395376','96398846','96403554','96414200','96418994','96422157',
  '96426832','96430982','96431699','96438768','96446965','96447516','96447919','96448152','96449847','96452224',
  '96454969','96461186','96463127','96465291','96470636','96480891','96482756','96484385','96486302','96491270',
  '96491634','96493904','96494210','96501126','96513213','96514567','96516988','96519282','96521289','96523675',
  '96531364','96532036','96540798','96548820','96564077','96575818','96601892','96604392','96604959','96607275',
  '96608879','96614891','96618345','96622275','96622670','96625816','96626493','96646896','96648352','96649802',
  '96650707','96672557','96678051','96678176','96689478','96690878','96694864','96702642','96702943','96713543',
  '96714678','96716590','96719227','96720658','96722125','96724871','96727833','96731758','96750695','96763312',
  '96765968','96767482','96773090','96774616','96774883','96778868','96783142','96799848','96802607','96802704',
  '96802761','96807437','96809127','96812602','96814916','96820316','96820849','96821014','96824216','96824588',
  '96827137','96829477','96831631','96833937','96840194','96844590','96846372','96851544','96853898','96867478',
  '96867837','96873833','96875647','96882952','96889875','96891593','96892078','96892759','96896660','96902957',
  '96903686','96913491','96913548','96914588','96918707','96935594','96938709','96941230','96949327','96954955',
  '96958201','96960653','96968849','96970342','96972027','96979941','96980141','96983553','96988419','96993646',
  '96994952','96998593','97028872','97034549','97038694','97051978','97052267','97052373','97054214','97054713',
  '97054730','97059373','97065705','97065884','97066769','97066880','97069494','97086496','97089037','97098458',
  '97098736','97099793','97100499','97103253','97116267','97118721','97120380','97132968','97134261','97145443',
  '97146181','97147213','97150965','97154737','97157474','97159495','97161604','97166520','97173489','97173845',
  '97174644','97174814','97175295','97175507','97189155','97193552','97203299','97209281','97211812','97212642',
  '97232229','97245184','97249870','97253040','97268429','97275854','97282057','97282510','97297523','97303130',
  '97305828','97307055','97316165','97317023','97325666','97333261','97342939','97360297','97362909','97364128',
  '97370168','97378812','97380472','97382084','97385485','97385787','97387332','97389147','97389349','97391793',
  '97392454','97399565','97401692','97406594','97415744','97421427','97434312','97442348','97443214','97449209',
  '97449618','97451704','97455167','97458371','97458430','97460551','97464763','97468236','97472095','97477388',
  '97484259','97496627','97497951','97498214','97503382','97510364','97512144','97516335','97528624','97529382',
  '97552795','97554987','97580941','97582745','97585192','97586695','97588211','97589319','97596466','97606847',
  '97611689','97616046','97622735','97623935','97624945','97626223','97631657','97636948','97648684','97652417',
  '97654936','97659242','97662555','97662724','97665539','97666054','97676736','97679320','97692891','97694393',
  '97698593','97708310','97715629','97717566','97720715','97720812','97725268','97726426','97731120','97735743',
  '97738563','97742612','97745145','97746086','97762479','97763130','97766496','97771129','97781637','97784121',
  '97784380','97784769','97790645','97790817','97791009','97791542','97794360','97795499','97796023','97823591',
  '97827010','97830095','97833827','97835633','97842665','97851452','97852199','97860857','97863109','97871894',
  '97877237','97877905','97885825','97887041','97895600','97908916','97914565','97915831','97923097','97924181',
  '97927757','97929931','97940203','97942113','97943272','97949210','97949232','97960093','97967509','97968210',
  '97979656','97979947','97987261','97997339','97997684','97999442','98002778','98005732','98008708','98013182',
  '98016323','98018189','98023252','98023295','98025641','98026699','98027586','98037569','98042969','98045145',
  '98048344','98050192','98050534','98055553','98057013','98062944','98067619','98068100','98075161','98098748',
  '98098991','98106938','98110846','98116693','98117940','98118114','98129797','98132789','98136041','98136952',
  '98139319','98148828','98149462','98151830','98153928','98154841','98159414','98160391','98161197','98161255',
  '98165869','98171266','98177502','98180064','98188086','98190810','98196524','98204113','98204178','98217101',
  '98217341','98217357','98218662','98221137','98223828','98229475','98231768','98234508','98237866','98239396',
  '98240792','98242340','98243653','98262227','98264632','98268113','98270535','98272022','98277052','98293614',
  '98308745','98309332','98312255','98321918','98329908','98334307','98334762','98335175','98342567','98344889',
  '98345640','98347044','98353325','98354422','98361144','98364882','98365807','98367413','98376393','98387505',
  '98390389','98398051','98402209','98404350','98405732','98415014','98415370','98423394','98425389','98429971',
  '98434164','98438678','98463864','98463985','98466023','98470810','98475026','98475659','98475952','98484098',
  '98484184','98494663','98495277','98499997','98500230','98500560','98500995','98503977','98507586','98509200',
  '98510544','98515428','98529440','98532604','98536673','98537979','98539181','98539670','98554028','98554036',
  '98557934','98560432','98572740','98577179','98583121','98586243','98587872','98592405','98596029','98600085',
  '98603015','98606395','98610060','98626604','98642733','98643508','98643577','98647928','98652127','98669349',
  '98680236','98681632','98685706','98686060','98688495','98692935','98694584','98695111','98702989','98707609',
  '98713284','98713805','98720118','98736766','98740075','98743894','98744265','98745692','98749329','98760769',
  '98770303','98772503','98773508','98784852','98788127','98789115','98790845','98797499','98798767','98809035',
  '98818779','98824161','98824665','98830965','98835236','98842505','98845798','98850136','98852733','98864063',
  '98869525','98870761','98877392','98880429','98883146','98883279','98886430','98891944','98893153','98896875',
  '98904325','98906854','98908653','98910060','98919580','98920671','98924589','98925488','98926438','98929735',
  '98931090','98956162','98957418','98959843','98963401','98963590','98966483','98967237','98972188','98979514',
  '98980908','98981929','98987889','98993149','98997194','99000842','99005116','99007137','99007539','99008543',
  '99016596','99024010','99026143','99030876','99031444','99037334','99039595','99042698','99046347','99057030',
  '99060458','99074695','99083553','99097970','99098542','99101757','99103380','99106118','99119945','99124009',
  '99124321','99132498','99134728','99140712','99145585','99147262','99152284','99154076','99154697','99154733',
  '99159329','99164406','99180780','99202503','99203117','99209635','99219546','99227669','99235167','99238852',
  '99254921','99259613','99261514','99266928','99269447','99271306','99276575','99276978','99280313','99286097',
  '99289597','99290022','99293909','99299298','99304817','99306116','99307521','99313562','99316365','99332063',
  '99335577','99337610','99337697','99338340','99343966','99346325','99348756','99350193','99353164','99354137',
  '99358130','99364218','99370609','99383616','99383888','99386554','99386622','99393132','99398572','99408996',
  '99409173','99411262','99413141','99418979','99434310','99450984','99455547','99461127','99463061','99463777',
  '99465441','99468486','99469261','99473742','99476134','99480854','99487387','99496499','99498033','99502539',
  '99512824','99516542','99521809','99546223','99552739','99553209','99560900','99566230','99568663','99571678',
  '99582071','99588923','99598568','99599296','99604176','99609705','99609848','99622912','99626639','99628126',
  '99645027','99667940','99673226','99677779','99681201','99682618','99688865','99689544','99690556','99693623',
  '99696222','99703724','99710449','99714626','99720155','99720985','99723264','99725302','99731953','99734190',
  '99735916','99744589','99751561','99760530','99768907','99771548','99775703','99780769','99782788','99788677',
  '99792021','99796432','99798191','99799557','99806989','99808295','99818765','99819806','99834161','99835407',
  '99841908','99843835','99845291','99845833','99855737','99863598','99866496','99869281','99877606','99886497',
  '99890693','99893192','99894295','99894999','99896077','99916357','99916730','99923798','99926842','99927356',
  '99935281','99937780','99939108','99946100','99951627','99956549','99959728','99966007','99970920','99993822',
];
const LICENSE_POOL_SET = (function() { const s = {}; for (var i = 0; i < LICENSE_POOL.length; i++) { s[LICENSE_POOL[i]] = true; } return s; })();
